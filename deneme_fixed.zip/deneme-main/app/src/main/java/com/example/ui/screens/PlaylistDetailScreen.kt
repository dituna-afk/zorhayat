package com.example.ui.screens

import android.graphics.BitmapFactory
import android.os.Environment
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserPlaylist
import com.example.downloader.DownloadProgress
import com.example.downloader.MediaTrackInfo
import com.example.downloader.SavedMediaResult
import com.example.ui.theme.LocalAppTheme
import com.example.ui.theme.TerminalGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Çalma Listesi Detay Ekranı (PlaylistDetailScreen):
 * - Üst alandaki kapak görselinin arkasında kapağın renk tonlarına göre hafif blur'lanmış dinamik Halo efekti.
 * - '184 bekliyor' gibi henüz inmemiş parçalar için 'Tüm Eksikleri Arka Planda İndir' butonu ve
 *   LocalDownloadManager / MultiThreadChunkedDownloader kuyruk entegrasyonu.
 * - Glassmorphic 1.dp gradyan çerçeveli parça satırları.
 */
@Composable
fun PlaylistDetailScreen(
    playlist: UserPlaylist,
    savedTracks: List<SavedMediaResult>,
    isDownloading: Boolean,
    activeDownloadTitle: String?,
    downloadProgress: DownloadProgress?,
    pendingQueueCount: Int,
    onBack: () -> Unit,
    onPlayPlaylist: (List<MediaTrackInfo>, Boolean) -> Unit,
    onPlayTrack: (MediaTrackInfo) -> Unit,
    onDownloadSingleTrack: (MediaTrackInfo) -> Unit,
    onDownloadAllMissing: (List<MediaTrackInfo>) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val theme = LocalAppTheme.current
    val context = LocalContext.current

    val downloadedIds by remember(savedTracks) {
        derivedStateOf {
            savedTracks.map { it.trackInfo.videoId }.toSet()
        }
    }

    val missingTracks by remember(playlist.tracks, downloadedIds) {
        derivedStateOf {
            playlist.tracks.filter { !downloadedIds.contains(it.videoId) }
        }
    }

    val downloadedCount by remember(playlist.tracks, downloadedIds) {
        derivedStateOf {
            playlist.tracks.count { downloadedIds.contains(it.videoId) }
        }
    }

    // Kapak görselinin baskın renk tonunu arka plandaki Halo efekti için çıkar
    var dominantHaloColor by remember(theme) { mutableStateOf(theme.haloPrimary) }
    var secondaryHaloColor by remember(theme) { mutableStateOf(theme.haloSecondary) }

    LaunchedEffect(playlist.coverImagePath, playlist.tracks, theme) {
        withContext(Dispatchers.Default) {
            val targetDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Morphe")
            val candidateFile = when {
                !playlist.isAutoCollage && !playlist.coverImagePath.isNullOrBlank() -> {
                    File(playlist.coverImagePath).takeIf { it.exists() }
                }
                playlist.tracks.isNotEmpty() -> {
                    val firstId = playlist.tracks.first().videoId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                    File(targetDir, "$firstId.jpg").takeIf { it.exists() }
                }
                else -> null
            }

            if (candidateFile != null) {
                try {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
                    val bmp = BitmapFactory.decodeFile(candidateFile.absolutePath, opts)
                    if (bmp != null) {
                        var rSum = 0L
                        var gSum = 0L
                        var bSum = 0L
                        var count = 0L
                        val stepX = (bmp.width / 8).coerceAtLeast(1)
                        val stepY = (bmp.height / 8).coerceAtLeast(1)
                        for (x in 0 until bmp.width step stepX) {
                            for (y in 0 until bmp.height step stepY) {
                                val pixel = bmp.getPixel(x, y)
                                val r = (pixel shr 16) and 0xFF
                                val g = (pixel shr 8) and 0xFF
                                val b = pixel and 0xFF
                                if (r + g + b > 60) {
                                    rSum += r
                                    gSum += g
                                    bSum += b
                                    count++
                                }
                            }
                        }
                        if (count > 0) {
                            val avgR = ((rSum / count).toInt() + 40).coerceAtMost(255)
                            val avgG = ((gSum / count).toInt() + 20).coerceAtMost(255)
                            val avgB = ((bSum / count).toInt() + 40).coerceAtMost(255)
                            dominantHaloColor = Color(avgR, avgG, avgB)
                            secondaryHaloColor = theme.primary
                        }
                    }
                } catch (_: Exception) {
                }
            } else {
                dominantHaloColor = theme.haloPrimary
                secondaryHaloColor = theme.haloSecondary
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "playlist_halo_pulse")
    val haloScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_scale"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(theme.background)
            .testTag("playlist_detail_screen"),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // 1. Üst Alan: Kapak Görseli + Dinamik Blur Halo Efekti + Başlık & İstatistikler
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        val center = Offset(size.width * 0.5f, size.height * 0.42f)
                        val maxRadius = size.width * 0.72f * haloScale
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    dominantHaloColor.copy(alpha = 0.42f),
                                    secondaryHaloColor.copy(alpha = 0.22f),
                                    Color(0xFFFF2D75).copy(alpha = 0.10f),
                                    Color.Transparent
                                ),
                                center = center,
                                radius = maxRadius
                            ),
                            radius = maxRadius,
                            center = center
                        )
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Üst Gezinme Çubuğu (Geri & Sil)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(theme.surfaceElevated.copy(alpha = 0.75f))
                                .testTag("playlist_detail_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Geri",
                                tint = Color.White
                            )
                        }

                        Text(
                            text = "OYNATMA LİSTESİ DETAYI",
                            style = MaterialTheme.typography.labelSmall,
                            color = theme.textSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )

                        IconButton(
                            onClick = { onDeletePlaylist(playlist.id) },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(theme.surfaceElevated.copy(alpha = 0.75f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Listeyi Sil",
                                tint = Color(0xFFFF6B6B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Dinamik Halo Önündeki 1:1 Kare Kapak Görseli
                    Box(
                        modifier = Modifier
                            .size(176.dp)
                            .graphicsLayer {
                                shadowElevation = 28f
                                shape = RoundedCornerShape(18.dp)
                                clip = true
                            }
                            .border(theme.glassGradientBorder(width = 1.5.dp, isHighlighted = true), RoundedCornerShape(18.dp))
                    ) {
                        PlaylistCoverArtwork(
                            isAutoCollage = playlist.isAutoCollage,
                            coverImagePath = playlist.coverImagePath,
                            tracks = playlist.tracks,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Liste Başlığı ve Açıklaması
                    Text(
                        text = playlist.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = theme.textPrimary,
                        textAlign = TextAlign.Center
                    )

                    if (playlist.description.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = playlist.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Durum Rozeti: Toplam Parça • İndirilen • Bekleyen ('X bekliyor')
                    Surface(
                        color = theme.surfaceElevated.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(20.dp),
                        border = theme.glassGradientBorder()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "${playlist.tracks.size} Şarkı",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = "•", color = theme.textSecondary, fontSize = 11.sp)
                            Text(
                                text = "$downloadedCount İndirildi",
                                color = TerminalGreen,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            if (missingTracks.isNotEmpty()) {
                                Text(text = "•", color = theme.textSecondary, fontSize = 11.sp)
                                Text(
                                    text = "${missingTracks.size} bekliyor",
                                    color = Color(0xFFFBBF24),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Oynat ve Karıştır Aksiyon Butonları
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onPlayPlaylist(playlist.tracks, false) },
                            enabled = playlist.tracks.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                            shape = RoundedCornerShape(24.dp),
                            border = theme.glassGradientBorder(isHighlighted = true),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tümünü Oynat", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = { onPlayPlaylist(playlist.tracks, true) },
                            enabled = playlist.tracks.isNotEmpty(),
                            shape = RoundedCornerShape(24.dp),
                            border = theme.glassGradientBorder(isHighlighted = true),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = theme.surfaceElevated.copy(alpha = 0.7f),
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Shuffle, contentDescription = null, tint = theme.primary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Karıştır", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    // 2. 'Tüm Eksikleri Arka Planda İndir' Butonu (LocalDownloadManager Kuyruğuna Bağlı)
                    if (missingTracks.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = theme.surfaceElevated),
                            shape = RoundedCornerShape(14.dp),
                            border = theme.glassGradientBorder(isHighlighted = true),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(
                                            imageVector = Icons.Default.CloudDownload,
                                            contentDescription = null,
                                            tint = theme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "${missingTracks.size} Parça Çevrimdışı Bekliyor",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = theme.textPrimary
                                            )
                                            Text(
                                                text = if (isDownloading && pendingQueueCount > 0) {
                                                    "Kuyruk aktif ($pendingQueueCount sırada) • İndiriliyor: ${activeDownloadTitle ?: ""}"
                                                } else {
                                                    "4 Parçalı HTTP Range motoru ile tüm eksikleri sırayla indir"
                                                },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = theme.textSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }

                                if (isDownloading && downloadProgress != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    LinearProgressIndicator(
                                        progress = { downloadProgress.progressPercent / 100f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = theme.primary,
                                        trackColor = Color.DarkGray
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = { onDownloadAllMissing(missingTracks) },
                                    colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("download_all_missing_button")
                                ) {
                                    if (isDownloading && pendingQueueCount > 0) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = Color.White,
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Arka Planda İndiriliyor (${missingTracks.size} bekliyor)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Download,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Tüm Eksikleri Arka Planda İndir (${missingTracks.size} bekliyor)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Oynatma Listesi Parçaları
        if (playlist.tracks.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Bu oynatma listesinde henüz şarkı bulunmuyor.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = theme.textSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            itemsIndexed(playlist.tracks, key = { index, t -> "${t.videoId}_$index" }) { index, track ->
                val isDownloaded = downloadedIds.contains(track.videoId)
                Surface(
                    color = theme.surface,
                    shape = RoundedCornerShape(10.dp),
                    border = theme.glassGradientBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clickable { onPlayTrack(track) }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            style = MaterialTheme.typography.labelSmall,
                            color = theme.textSecondary,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(24.dp),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = track.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = theme.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = track.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = theme.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (isDownloaded) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "İndirildi",
                                    tint = TerminalGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Hazır",
                                    color = TerminalGreen,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            IconButton(
                                onClick = { onDownloadSingleTrack(track) }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "İndir",
                                    tint = theme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
