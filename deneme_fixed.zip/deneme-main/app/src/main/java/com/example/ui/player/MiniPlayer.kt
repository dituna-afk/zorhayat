package com.example.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.player.PlayerState
import com.example.ui.theme.LocalAppTheme

/**
 * YouTube Music Tarzı Sabit Mini Oynatıcı.
 * `derivedStateOf` ve lambda-bazlı ilerleme çubuğu ile
 * milisaniye güncellemelerinde yeniden derlenmeyi (recomposition) önler;
 * GPU donanım katmanında pürüzsüz 120 FPS çalışır.
 */
@Composable
fun MiniPlayer(
    playerState: PlayerState,
    onClick: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onPlayNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    val track = playerState.currentTrack ?: return
    val theme = LocalAppTheme.current

    // derivedStateOf ile gereksiz recomposition'ları önle
    val isPlayingState by remember(playerState.isPlaying) {
        derivedStateOf { playerState.isPlaying }
    }

    Surface(
        color = theme.surfaceElevated,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .graphicsLayer {
                // GPU Katman hızlandırması
                clip = true
            }
            .clickable { onClick() }
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    // Yukarı kaydırıldığında tam ekran oynatıcıya açıl
                    if (dragAmount < -15f) {
                        onClick()
                    }
                }
            }
            .testTag("persistent_mini_player")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // 1. Üst Kenarda İnce İlerleme Çubuğu (Doğrudan lambda içinde hesaplanır)
            LinearProgressIndicator(
                progress = {
                    if (playerState.durationMs > 0) {
                        (playerState.currentPositionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
                    } else 0f
                },
                color = theme.primary,
                trackColor = theme.primary.copy(alpha = 0.20f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp)
                    .align(Alignment.TopCenter)
            )

            // 2. Mini Player İçerik Satırı
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Sol: Albüm Kapağı Küçük Resim
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(theme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🎵",
                        fontSize = 20.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Orta: Şarkı Başlığı ve Sanatçı
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = theme.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = theme.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Sağ: Oynat/Duraklat ve Sıradaki Butonları
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnimatedPlayPauseButton(
                        isPlaying = isPlayingState,
                        onClick = onTogglePlayPause,
                        size = 38.dp,
                        iconSize = 22.dp,
                        containerColor = theme.primary.copy(alpha = 0.15f),
                        contentColor = theme.primary,
                        modifier = Modifier.testTag("mini_player_play_pause")
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onPlayNext,
                        modifier = Modifier
                            .size(42.dp)
                            .testTag("mini_player_next")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Sıradaki",
                            tint = theme.textPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }
    }
}
