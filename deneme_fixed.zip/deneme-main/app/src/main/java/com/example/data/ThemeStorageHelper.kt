package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.ui.theme.AppTheme

/**
 * Kullanıcının seçtiği renk paletini ve temasını SharedPreferences içine kalıcı olarak kaydeden
 * ve uygulama her açıldığında buradan geri yükleyen yardımcı sınıf.
 */
class ThemeStorageHelper(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "morphe_theme_preferences"
        private const val KEY_SELECTED_THEME = "pref_selected_theme_id"

        @Volatile
        private var instance: ThemeStorageHelper? = null

        fun getInstance(context: Context): ThemeStorageHelper {
            return instance ?: synchronized(this) {
                instance ?: ThemeStorageHelper(context.applicationContext).also { instance = it }
            }
        }
    }

    fun getSelectedTheme(): AppTheme {
        val id = prefs.getString(KEY_SELECTED_THEME, AppTheme.OLED_BLACK.id)
        return AppTheme.fromId(id)
    }

    fun saveSelectedTheme(theme: AppTheme) {
        prefs.edit().putString(KEY_SELECTED_THEME, theme.id).apply()
    }
}
