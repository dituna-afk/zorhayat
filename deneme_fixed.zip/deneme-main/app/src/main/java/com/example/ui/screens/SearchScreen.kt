package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.downloader.MediaTrackInfo
import com.example.ui.theme.LocalAppTheme
import com.example.ui.theme.TerminalGreen

@Composable
fun SearchScreen(
    searchQuery: String,
    searchResults: List<MediaTrackInfo>,
    resolvedTrack: MediaTrackInfo?,
    resolvedPlaylistId: String? = null,
    resolvedPlaylistTitle: String? = null,
    streamErrorDetail: String? = null,
    isSearching: Boolean,
    isResolving: Boolean,
    selectedFilter: String,
    onSearchQueryChanged: (String) -> Unit,
    onExecuteSearch: (String) -> Unit,
    onFilterSelected: (String) -> Unit,
    onTrackSelected: (MediaTrackInfo) -> Unit,
    onAddToQueue: (MediaTrackInfo) -> Unit,
    onDownloadTriggered: (MediaTrackInfo) -> Unit,
    onDismissError: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val theme = LocalAppTheme.current
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val sampleQueries = listOf(
        "https://music.youtube.com/playlist?list=LM",
        "Daft Punk",
        "The Weeknd",
        "Starboy",
        "Synthwave",
        "Lofi Beats"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(theme.background)
            .padding(top = 16.dp)
    ) {
        // 1. YouTube Music Arama, Video Linki (watch?v=) ve Playlist (playlist?list=) Çubuğu
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChanged,
            placeholder = {
                Text(
                    "Video linki (watch?v=), Playlist (playlist?list=LM) veya şarkı arayın...",
                    color = theme.textSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Ara",
                    tint = theme.textPrimary
                )
            },
            trailingIcon = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Temizle",
                                tint = theme.textSecondary
                            )
                        }
                    } else {
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clipData = clipboard.primaryClip
                                if (clipData != null && clipData.itemCount > 0) {
                                    val text = clipData.getItemAt(0).text?.toString() ?: ""
                                    if (text.isNotBlank()) {
                                        onSearchQueryChanged(text)
                                        onExecuteSearch(text)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = "Yapıştır",
                                tint = theme.textSecondary
                            )
                        }
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(
                onSearch = {
                    keyboardController?.hide()
                    onExecuteSearch(searchQuery)
                }
            ),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = theme.surfaceElevated,
                unfocusedContainerColor = theme.surfaceElevated,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedIndicatorColor = theme.primary,
                unfocusedIndicatorColor = theme.border
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("search_text_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 2. Hızlı Arama & Beğenilenler (LM) Önerileri
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            sampleQueries.forEach { tag ->
                val displayLabel = if (tag.contains("playlist?list=LM")) "❤️ Beğenilenler (LM)" else tag
                FilterChip(
                    selected = searchQuery == tag,
                    onClick = {
                        onSearchQueryChanged(tag)
                        onExecuteSearch(tag)
                    },
                    label = { Text(displayLabel, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = theme.surface,
                        labelColor = theme.textPrimary,
                        selectedContainerColor = theme.primaryContainer,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. Hata Kodu / Tanı Logu Kartı (Varsa çökmeden kullanıcıya detaylı bilgi verir)
        if (!streamErrorDetail.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2D1216)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .testTag("stream_error_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = "Hata Kodu",
                        tint = Color(0xFFFF6B6B),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ÇÖZÜMLEME HATA DETAYI",
                            color = Color(0xFFFF6B6B),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = streamErrorDetail,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    if (onDismissError != null) {
                        IconButton(onClick = onDismissError, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Kapat",
                                tint = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // 4. Oynatma Listesi (Playlist) veya Tekil Video Çözümleme Kartı
        if (isResolving) {
            Card(
                colors = CardDefaults.cardColors(containerColor = theme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = theme.primary,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (resolvedPlaylistId != null) {
                            "Oynatma listesi ($resolvedPlaylistId) InnerTube Browse ile çözümleniyor..."
                        } else {
                            "YouTube video akışı ve meta verileri çözümleniyor..."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = theme.textSecondary
                    )
                }
            }
        } else if (resolvedPlaylistId != null) {
            // Oynatma Listesi (playlist?list=...) Bilgi Başlığı
            Card(
                colors = CardDefaults.cardColors(containerColor = theme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("resolved_playlist_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(theme.primary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QueueMusic,
                                contentDescription = null,
                                tint = theme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = resolvedPlaylistTitle ?: "Oynatma Listesi ($resolvedPlaylistId)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = theme.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "InnerTube Browse (list=$resolvedPlaylistId) • ${searchResults.size} Şarkı",
                                style = MaterialTheme.typography.bodySmall,
                                color = TerminalGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        } else if (resolvedTrack != null) {
            // Tekil Video Bağlantısı (watch?v= veya youtu.be/) Kartı
            Card(
                colors = CardDefaults.cardColors(containerColor = theme.surface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("resolved_video_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(TerminalGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "TEKİL VİDEO BAĞLANTISI DOĞRULANDI",
                                color = TerminalGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = resolvedTrack.videoId,
                            color = theme.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(theme.surfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🎵", fontSize = 24.sp)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = resolvedTrack.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = theme.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = resolvedTrack.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = theme.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onDownloadTriggered(resolvedTrack) },
                            colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("resolved_video_download_button")
                        ) {
                            Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("4 Parça ile İndir", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { onTrackSelected(resolvedTrack) },
                            colors = ButtonDefaults.buttonColors(containerColor = theme.surfaceElevated),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Oynat", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 5. Çözümlenen Playlist Şarkıları veya Arama Sonuçları Listesi
        if (isSearching && searchResults.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = theme.primary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (resolvedPlaylistId != null) {
                            "Oynatma listesindeki şarkılar çözümleniyor..."
                        } else {
                            "YouTube Music'te aranıyor..."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = theme.textSecondary
                    )
                }
            }
        } else if (searchResults.isEmpty() && searchQuery.isNotBlank() && resolvedTrack == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "\"$searchQuery\" için sonuç bulunamadı.\nArama butonuna basabilir, tekil video linki (watch?v=) veya oynatma listesi linki (playlist?list=LM) yapıştırabilirsiniz.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = theme.textSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(searchResults, key = { it.videoId }) { track ->
                    SearchResultRow(
                        track = track,
                        onPlay = { onTrackSelected(track) },
                        onAddToQueue = { onAddToQueue(track) },
                        onDownload = { onDownloadTriggered(track) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchResultRow(
    track: MediaTrackInfo,
    onPlay: () -> Unit,
    onAddToQueue: () -> Unit,
    onDownload: () -> Unit
) {
    val theme = LocalAppTheme.current

    Surface(
        color = theme.surface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() }
            .testTag("search_result_${track.videoId}")
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(theme.surfaceElevated),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎵", fontSize = 22.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = theme.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = track.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = theme.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onAddToQueue) {
                Icon(
                    imageVector = Icons.Default.PlaylistAdd,
                    contentDescription = "Sıraya Ekle",
                    tint = theme.textSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }

            IconButton(
                onClick = onDownload,
                modifier = Modifier.testTag("download_button_${track.videoId}")
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "İndir",
                    tint = theme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
