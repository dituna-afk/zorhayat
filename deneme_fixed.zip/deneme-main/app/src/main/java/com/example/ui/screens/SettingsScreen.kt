package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AppTheme
import com.example.ui.theme.LocalAppTheme

@Composable
fun SettingsScreen(
    downloadDirectoryPath: String,
    currentTheme: AppTheme = AppTheme.OLED_BLACK,
    onThemeSelected: (AppTheme) -> Unit = {},
    isAutoDownloadLiked: Boolean = true,
    isWifiOnlyDownload: Boolean = false,
    onToggleAutoDownloadLiked: (Boolean) -> Unit = {},
    onToggleWifiOnlyDownload: (Boolean) -> Unit = {},
    onOpenCookieInspector: () -> Unit,
    onClearCache: () -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = LocalAppTheme.current
    var selectedChunkCount by remember { mutableIntStateOf(4) }
    var isHighQualityAudio by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(theme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Ayarlar",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = theme.textPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Morphe Oynatıcı, Temalar & İndirme Tercihleri",
                style = MaterialTheme.typography.bodySmall,
                color = theme.textSecondary
            )
        }

        // 1. Görünüm ve Dinamik Tema Seçimi (Settings & Dynamic Themes)
        item {
            SettingSectionCard(title = "GÖRÜNÜM VE TEMA SEÇİMİ") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppTheme.entries.forEach { themeItem ->
                        val isSelected = themeItem == currentTheme
                        ThemeSelectionRow(
                            theme = themeItem,
                            isSelected = isSelected,
                            onSelect = { onThemeSelected(themeItem) }
                        )
                    }
                }
            }
        }

        // 2. Otomatik İndirme Motoru Ayarları
        item {
            SettingSectionCard(title = "OTOMATİK İNDİRME MOTORU") {
                // Beğenilen Şarkıları Otomatik İndir
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Favorite, contentDescription = null, tint = theme.primary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Beğenilenleri Otomatik İndir",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = theme.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Kalp butonuna basıldığında parça 4 parça ile otomatik indirilir",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary
                        )
                    }

                    Switch(
                        checked = isAutoDownloadLiked,
                        onCheckedChange = onToggleAutoDownloadLiked,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = theme.primary
                        ),
                        modifier = Modifier.testTag("auto_download_liked_switch")
                    )
                }

                HorizontalDivider(color = theme.border, thickness = 0.5.dp)

                // Yalnızca Wi-Fi Üzerindeyken İndir
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Wifi, contentDescription = null, tint = theme.primary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Yalnızca Wi-Fi Üzerindeyken İndir",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = theme.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Hücresel veri kullanımını engeller, Wi-Fi ağı beklenir",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary
                        )
                    }

                    Switch(
                        checked = isWifiOnlyDownload,
                        onCheckedChange = onToggleWifiOnlyDownload,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = theme.primary
                        ),
                        modifier = Modifier.testTag("wifi_only_download_switch")
                    )
                }
            }
        }

        // 3. İndirme ve Medya Deposu
        item {
            SettingSectionCard(title = "İNDİRME VE DEPOLAMA") {
                SettingRow(
                    icon = Icons.Default.Folder,
                    title = "Kayıt Dizini",
                    subtitle = downloadDirectoryPath
                )

                HorizontalDivider(color = theme.border, thickness = 0.5.dp)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Parçalı Range Thread Sayısı",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = theme.textPrimary
                        )
                        Text(
                            text = "Aynı anda açılan paralel HTTP bağlantısı",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(2, 4, 8).forEach { count ->
                            FilterChip(
                                selected = selectedChunkCount == count,
                                onClick = { selectedChunkCount = count },
                                label = { Text("$count", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = theme.primary,
                                    selectedLabelColor = Color.White,
                                    containerColor = theme.surfaceElevated,
                                    labelColor = theme.textPrimary
                                )
                            )
                        }
                    }
                }
            }
        }

        // 4. Ses ve Oynatma Kalitesi
        item {
            SettingSectionCard(title = "OYNATMA KALİTESİ") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Yüksek Kalite Ses (M4A 256kbps)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = theme.textPrimary
                        )
                        Text(
                            text = "Kayıpsız dinamik aralık ve stereo ayrımı",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary
                        )
                    }

                    Switch(
                        checked = isHighQualityAudio,
                        onCheckedChange = { isHighQualityAudio = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = theme.primary
                        )
                    )
                }
            }
        }

        // 5. Web Çerezleri & Güvenlik
        item {
            SettingSectionCard(title = "GÜVENLİK VE ÇEREZ YÖNETİMİ") {
                SettingRow(
                    icon = Icons.Default.Lock,
                    title = "Kalıcı Depolama",
                    subtitle = "EncryptedSharedPreferences (AES-256 GCM Şifreli)",
                    badge = "KORUMALI"
                )

                HorizontalDivider(color = theme.border, thickness = 0.5.dp)

                SettingClickableRow(
                    icon = Icons.Default.Cookie,
                    title = "YouTube Music Çerez Yakalayıcı",
                    subtitle = "music.youtube.com tam ekran tarayıcısı ile oturum çerezlerini (SAPISID, LOGIN_INFO) otomatik yakalar",
                    onClick = onOpenCookieInspector
                )

                HorizontalDivider(color = theme.border, thickness = 0.5.dp)

                SettingClickableRow(
                    icon = Icons.Default.DeleteSweep,
                    title = "Geçici Dosyaları ve Önbelleği Temizle",
                    subtitle = "İndirme tamponunu ve log geçmişini sıfırlar",
                    onClick = onClearCache,
                    isDestructive = true
                )
            }
        }
    }
}

@Composable
private fun ThemeSelectionRow(
    theme: AppTheme,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val activeTheme = LocalAppTheme.current

    Surface(
        color = if (isSelected) activeTheme.primary.copy(alpha = 0.14f) else activeTheme.surfaceElevated,
        shape = RoundedCornerShape(10.dp),
        border = activeTheme.glassGradientBorder(
            width = if (isSelected) 1.5.dp else 1.dp,
            isHighlighted = isSelected
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("theme_option_${theme.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Renk Paleti Önizleme Rozeti
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(theme.background)
                        .border(1.dp, theme.border, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(theme.primary)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = theme.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isSelected) activeTheme.primary else activeTheme.textPrimary
                    )
                    Text(
                        text = theme.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = activeTheme.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(activeTheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Seçili",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    val theme = LocalAppTheme.current
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = theme.textSecondary,
            letterSpacing = 1.2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = theme.surface),
            shape = RoundedCornerShape(14.dp),
            border = theme.glassGradientBorder(width = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                content()
            }
        }
    }
}

@Composable
private fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    badge: String? = null
) {
    val theme = LocalAppTheme.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = theme.primary, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = theme.textPrimary
                )
                if (badge != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(theme.primary.copy(alpha = 0.2f))
                            .border(theme.glassGradientBorder(), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badge,
                            color = theme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = theme.textSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SettingClickableRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    isDestructive: Boolean = false
) {
    val theme = LocalAppTheme.current
    Surface(
        color = theme.surfaceElevated.copy(alpha = 0.65f),
        shape = RoundedCornerShape(10.dp),
        border = theme.glassGradientBorder(width = 1.dp, isHighlighted = !isDestructive),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isDestructive) Color(0xFFFF5252) else theme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isDestructive) Color(0xFFFF5252) else theme.textPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = theme.textSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}
