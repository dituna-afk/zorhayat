package com.example.ui.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.downloader.MediaTrackInfo
import com.example.model.LyricLine
import com.example.player.PlayerState
import com.example.player.RepeatMode
import com.example.ui.theme.LocalAppTheme
import com.example.ui.theme.YtDarkBackground
import com.example.ui.theme.YtDarkSurface
import com.example.ui.theme.YtDarkSurfaceElevated
import com.example.ui.theme.YtRedPrimary
import com.example.ui.theme.YtTextPrimary
import com.example.ui.theme.YtTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.absoluteValue

enum class NowPlayingSubTab {
    SONG, LYRICS, QUEUE
}

@Composable
fun NowPlayingScreen(
    playerState: PlayerState,
    lyrics: List<LyricLine> = emptyList(),
    isLyricsLoading: Boolean = false,
    onCollapse: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onPlayNext: () -> Unit,
    onPlayPrevious: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onToggleLike: () -> Unit,
    onVolumeChanged: (Float) -> Unit,
    onBrightnessChanged: (Float) -> Unit,
    onPlayTrackFromQueue: ((MediaTrackInfo) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BackHandler { onCollapse() }

    val theme = LocalAppTheme.current
    val coroutineScope = rememberCoroutineScope()
    val track = playerState.currentTrack
    val title = track?.title ?: "Morphe Parçası"
    val artist = track?.artist ?: "Bilinmeyen Sanatçı"

    var selectedSubTab by remember { mutableStateOf(NowPlayingSubTab.SONG) }

    val playlist = playerState.playlist.ifEmpty {
        listOfNotNull(track)
    }
    val currentIndex = playerState.currentIndex.coerceIn(0, (playlist.size - 1).coerceAtLeast(0))

    // 3D Carousel Pager Durumu
    val pagerState = rememberPagerState(
        initialPage = currentIndex,
        pageCount = { playlist.size.coerceAtLeast(1) }
    )

    LaunchedEffect(playerState.currentIndex) {
        if (playerState.currentIndex in playlist.indices && pagerState.currentPage != playerState.currentIndex) {
            pagerState.animateScrollToPage(playerState.currentIndex)
        }
    }

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { pageIndex ->
            if (pageIndex != playerState.currentIndex && pageIndex in playlist.indices) {
                if (pageIndex > playerState.currentIndex) {
                    onPlayNext()
                } else if (pageIndex < playerState.currentIndex) {
                    onPlayPrevious()
                }
            }
        }
    }

    // Çift Dokunma Hızlı Sarma Durumları (+10s / -10s)
    var showForwardRipple by remember { mutableStateOf(false) }
    var showRewindRipple by remember { mutableStateOf(false) }

    // Kenar Dikey Kaydırma HUD Durumları
    var showVolumeHud by remember { mutableStateOf(false) }
    var showBrightnessHud by remember { mutableStateOf(false) }

    var isUserDraggingSlider by remember { mutableStateOf(false) }
    var sliderTempPosition by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(theme.background)
    ) {
        // 1. Dinamik Ritimli 'Halo Glow' Ortam Işığı
        HaloGlowBackground(
            seedString = "$title $artist",
            isPlaying = playerState.isPlaying
        )

        // 2. Ana Oynatıcı İçeriği
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Üst Bar: Kapatma Oku, Çevrimdışı Başlık, Seçenekler
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onCollapse,
                    modifier = Modifier.testTag("collapse_now_playing_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Küçült",
                        tint = YtTextPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ÇEVRİMDIŞI OYNATILIYOR",
                        style = MaterialTheme.typography.labelSmall,
                        color = YtTextSecondary,
                        letterSpacing = 1.4.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Morphe Müzik Kitaplığı",
                        style = MaterialTheme.typography.bodySmall,
                        color = YtTextPrimary
                    )
                }

                IconButton(onClick = { /* Menü */ }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Seçenekler",
                        tint = YtTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 3. Merkez İçerik: ŞARKI (3D Pager) | ŞARKI SÖZLERİ (Canlı Lyrics) | SIRADAKİ (Queue)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                when (selectedSubTab) {
                    NowPlayingSubTab.SONG -> {
                        // 3D Carousel Pager
                        HorizontalPager(
                            state = pagerState,
                            contentPadding = PaddingValues(horizontal = 32.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                        ) { page ->
                            val pageTrack = playlist.getOrNull(page) ?: track
                            val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).absoluteValue

                            val scale = 1f - (pageOffset * 0.16f).coerceIn(0f, 0.4f)
                            val alpha = 1f - (pageOffset * 0.4f).coerceIn(0f, 0.8f)
                            val rotationY = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction) * -18f

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = scale
                                        scaleY = scale
                                        this.alpha = alpha
                                        this.rotationY = rotationY
                                        cameraDistance = 12 * density
                                    }
                                    .shadow(elevation = 20.dp, shape = RoundedCornerShape(18.dp))
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color(0xFF2E2E2E),
                                                Color(0xFF1C1C1C),
                                                Color(0xFF0F0F0F)
                                            )
                                        )
                                    )
                                    .pointerInput(page) {
                                        detectTapGestures(
                                            onDoubleTap = { offset ->
                                                if (offset.x < size.width / 2f) {
                                                    onSeekTo((playerState.currentPositionMs - 10000L).coerceAtLeast(0L))
                                                    coroutineScope.launch {
                                                        showRewindRipple = true
                                                        delay(650)
                                                        showRewindRipple = false
                                                    }
                                                } else {
                                                    onSeekTo((playerState.currentPositionMs + 10000L).coerceAtMost(playerState.durationMs))
                                                    coroutineScope.launch {
                                                        showForwardRipple = true
                                                        delay(650)
                                                        showForwardRipple = false
                                                    }
                                                }
                                            }
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(20.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(90.dp)
                                            .clip(CircleShape)
                                            .background(theme.primary.copy(alpha = 0.25f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = "🎵", fontSize = 42.sp)
                                    }
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Text(
                                        text = pageTrack?.title ?: title,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        textAlign = TextAlign.Center,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = pageTrack?.artist ?: artist,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = theme.textSecondary,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                androidx.compose.animation.AnimatedVisibility(
                                    visible = showRewindRipple,
                                    enter = fadeIn() + scaleIn(),
                                    exit = fadeOut() + scaleOut(),
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(start = 24.dp)
                                ) {
                                    RippleSeekBubble(label = "-10 sn", isForward = false)
                                }

                                androidx.compose.animation.AnimatedVisibility(
                                    visible = showForwardRipple,
                                    enter = fadeIn() + scaleIn(),
                                    exit = fadeOut() + scaleOut(),
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .padding(end = 24.dp)
                                ) {
                                    RippleSeekBubble(label = "+10 sn", isForward = true)
                                }
                            }
                        }
                    }

                    NowPlayingSubTab.LYRICS -> {
                        // Canlı Senkronize Şarkı Sözleri Paneli
                        LyricsPanel(
                            lyrics = lyrics,
                            currentPositionMs = playerState.currentPositionMs,
                            isLoading = isLyricsLoading,
                            onSeekTo = onSeekTo,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    NowPlayingSubTab.QUEUE -> {
                        // Sıradaki Parçalar Listesi
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            itemsIndexed(playlist) { idx, qTrack ->
                                val isCurrent = idx == playerState.currentIndex
                                Surface(
                                    color = if (isCurrent) theme.surfaceElevated else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onPlayTrackFromQueue?.invoke(qTrack) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${idx + 1}",
                                            color = if (isCurrent) theme.primary else theme.textSecondary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.width(28.dp)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = qTrack.title,
                                                color = if (isCurrent) theme.primary else Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = qTrack.artist,
                                                color = theme.textSecondary,
                                                fontSize = 12.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        if (isCurrent) {
                                            Text(text = "▶", color = theme.primary, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Şarkı Başlığı, Sanatçı ve Beğen Butonu
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = YtTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = YtTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onToggleLike,
                    modifier = Modifier.testTag("like_button")
                ) {
                    Icon(
                        imageVector = if (playerState.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Beğen",
                        tint = if (playerState.isLiked) theme.primary else theme.textPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // 5. Parça İlerleme Çubuğu (Seek Bar) - derivedStateOf ile GPU & recomposition optimizasyonu
            val currentPos by remember(isUserDraggingSlider, sliderTempPosition, playerState.currentPositionMs) {
                derivedStateOf { if (isUserDraggingSlider) sliderTempPosition.toLong() else playerState.currentPositionMs }
            }
            val duration by remember(playerState.durationMs) {
                derivedStateOf { playerState.durationMs.coerceAtLeast(1L) }
            }
            val sliderValue by remember(currentPos, duration) {
                derivedStateOf { (currentPos.toFloat() / duration.toFloat()).coerceIn(0f, 1f) }
            }
            val formattedCurrentTime by remember(currentPos) {
                derivedStateOf { formatTime(currentPos) }
            }
            val formattedDuration by remember(duration) {
                derivedStateOf { formatTime(duration) }
            }

            val trackHeight by animateFloatAsState(
                targetValue = if (isUserDraggingSlider) 8f else 4f,
                animationSpec = spring(stiffness = Spring.StiffnessMedium),
                label = "track_height"
            )

            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = sliderValue,
                    onValueChange = { fraction ->
                        isUserDraggingSlider = true
                        sliderTempPosition = fraction * duration
                    },
                    onValueChangeFinished = {
                        isUserDraggingSlider = false
                        onSeekTo(sliderTempPosition.toLong())
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = theme.primary,
                        activeTrackColor = theme.primary,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(trackHeight.dp)
                        .testTag("now_playing_slider")
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formattedCurrentTime,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = theme.textSecondary
                    )
                    Text(
                        text = formattedDuration,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = theme.textSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 6. Oynatıcı Kontrolleri (Shuffle, Prev, AnimatedPlayPause, Next, Repeat)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onToggleShuffle) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Karıştır",
                        tint = if (playerState.isShuffle) theme.primary else theme.textSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(onClick = onPlayPrevious) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Önceki",
                        tint = theme.textPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                AnimatedPlayPauseButton(
                    isPlaying = playerState.isPlaying,
                    onClick = onTogglePlayPause,
                    size = 68.dp,
                    iconSize = 38.dp,
                    containerColor = theme.primary,
                    contentColor = Color.White
                )

                IconButton(onClick = onPlayNext) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Sıradaki",
                        tint = theme.textPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(onClick = onToggleRepeat) {
                    val repeatIcon = when (playerState.repeatMode) {
                        RepeatMode.ONE -> Icons.Default.RepeatOne
                        else -> Icons.Default.Repeat
                    }
                    val repeatTint = when (playerState.repeatMode) {
                        RepeatMode.OFF -> theme.textSecondary
                        else -> theme.primary
                    }
                    Icon(
                        imageVector = repeatIcon,
                        contentDescription = "Tekrarla",
                        tint = repeatTint,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 7. YouTube Music Tarzı Alt Sekme Seçici: [ŞARKI] | [ŞARKI SÖZLERİ] | [SIRADAKİ]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SubTabButton(
                    title = "ŞARKI",
                    isSelected = selectedSubTab == NowPlayingSubTab.SONG,
                    onClick = { selectedSubTab = NowPlayingSubTab.SONG }
                )
                SubTabButton(
                    title = "ŞARKI SÖZLERİ",
                    isSelected = selectedSubTab == NowPlayingSubTab.LYRICS,
                    onClick = { selectedSubTab = NowPlayingSubTab.LYRICS }
                )
                SubTabButton(
                    title = "SIRADAKİ",
                    isSelected = selectedSubTab == NowPlayingSubTab.QUEUE,
                    onClick = { selectedSubTab = NowPlayingSubTab.QUEUE }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // 8. Sol Kenar Dikey Kaydırma (Parlaklık Jesti)
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight(0.6f)
                .width(48.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { showBrightnessHud = true },
                        onDragEnd = { showBrightnessHud = false },
                        onDragCancel = { showBrightnessHud = false },
                        onVerticalDrag = { _, dragAmount ->
                            val delta = -dragAmount / 380f
                            onBrightnessChanged(playerState.brightness + delta)
                        }
                    )
                }
        )

        // 9. Sağ Kenar Dikey Kaydırma (Ses Seviyesi Jesti)
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight(0.6f)
                .width(48.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { showVolumeHud = true },
                        onDragEnd = { showVolumeHud = false },
                        onDragCancel = { showVolumeHud = false },
                        onVerticalDrag = { _, dragAmount ->
                            val delta = -dragAmount / 380f
                            onVolumeChanged(playerState.volume + delta)
                        }
                    )
                }
        )

        AnimatedVisibility(
            visible = showBrightnessHud,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier.align(Alignment.CenterStart)
        ) {
            GestureHud(
                icon = Icons.Default.BrightnessMedium,
                label = "Parlaklık",
                fraction = playerState.brightness,
                modifier = Modifier.padding(start = 24.dp)
            )
        }

        AnimatedVisibility(
            visible = showVolumeHud,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            GestureHud(
                icon = Icons.Default.VolumeUp,
                label = "Ses",
                fraction = playerState.volume,
                modifier = Modifier.padding(end = 24.dp)
            )
        }
    }
}

@Composable
private fun SubTabButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val theme = LocalAppTheme.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else theme.textSecondary,
            letterSpacing = 1.2.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .width(28.dp)
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(if (isSelected) theme.primary else Color.Transparent)
        )
    }
}

@Composable
private fun RippleSeekBubble(
    label: String,
    isForward: Boolean
) {
    val theme = LocalAppTheme.current
    Surface(
        color = Color.Black.copy(alpha = 0.75f),
        shape = RoundedCornerShape(24.dp),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!isForward) {
                Icon(imageVector = Icons.Default.FastRewind, contentDescription = null, tint = theme.primary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = label,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            if (isForward) {
                Spacer(modifier = Modifier.width(4.dp))
                Icon(imageVector = Icons.Default.FastForward, contentDescription = null, tint = theme.primary, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun GestureHud(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    fraction: Float,
    modifier: Modifier = Modifier
) {
    val theme = LocalAppTheme.current
    Surface(
        color = theme.surfaceElevated.copy(alpha = 0.94f),
        shape = RoundedCornerShape(14.dp),
        shadowElevation = 10.dp,
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(110.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(fraction.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(3.dp))
                        .background(theme.primary)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "%${(fraction * 100).toInt()}",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = Color.White,
                fontSize = 10.sp
            )
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
}
