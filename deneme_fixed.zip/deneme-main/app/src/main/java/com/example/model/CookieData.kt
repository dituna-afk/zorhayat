package com.example.model

data class CookieItem(
    val name: String,
    val value: String,
    val raw: String
)

data class CookieLogEntry(
    val id: Long = System.currentTimeMillis(),
    val timestamp: String,
    val url: String,
    val cookieString: String,
    val count: Int
)

object CookieParser {
    fun parse(rawCookie: String?): List<CookieItem> {
        if (rawCookie.isNullOrBlank()) return emptyList()
        return rawCookie.split(";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { pair ->
                val eqIndex = pair.indexOf('=')
                if (eqIndex != -1) {
                    val name = pair.substring(0, eqIndex).trim()
                    val value = pair.substring(eqIndex + 1).trim()
                    CookieItem(name = name, value = value, raw = pair)
                } else {
                    CookieItem(name = pair, value = "", raw = pair)
                }
            }
    }
}
