package com.example.ui.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LrcParser
import com.example.model.LyricLine
import com.example.ui.theme.LocalAppTheme

@Composable
fun LyricsPanel(
    lyrics: List<LyricLine>,
    currentPositionMs: Long,
    isLoading: Boolean,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = LocalAppTheme.current
    val listState = rememberLazyListState()
    val activeIndex = LrcParser.getActiveIndex(lyrics, currentPositionMs)

    // Şarkı ilerledikçe aktif söz satırını ekranın ortasında tutan pürüzsüz otomatik kaydırma
    LaunchedEffect(activeIndex) {
        if (activeIndex >= 0 && activeIndex < lyrics.size) {
            val centerTarget = (activeIndex - 2).coerceAtLeast(0)
            listState.animateScrollToItem(centerTarget)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("lyrics_panel"),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = theme.primary)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Senkronize sözler yükleniyor...",
                    style = MaterialTheme.typography.bodySmall,
                    color = theme.textSecondary
                )
            }
        } else if (lyrics.isEmpty()) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Bu parça için senkronize söz bulunamadı.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = theme.textSecondary,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 80.dp, bottom = 140.dp, start = 20.dp, end = 20.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                itemsIndexed(lyrics) { index, line ->
                    val isActive = index == activeIndex

                    val textColor by animateColorAsState(
                        targetValue = if (isActive) Color.White else theme.textSecondary.copy(alpha = 0.40f),
                        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                        label = "lyric_color"
                    )

                    val fontSize = if (isActive) 22.sp else 16.sp
                    val fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal

                    Text(
                        text = line.text,
                        color = textColor,
                        fontSize = fontSize,
                        fontWeight = fontWeight,
                        lineHeight = 30.sp,
                        textAlign = TextAlign.Start,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSeekTo(line.timeMs) }
                            .padding(vertical = 4.dp)
                            .testTag("lyric_line_$index")
                    )
                }
            }
        }
    }
}
