package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalAppTheme = staticCompositionLocalOf { AppTheme.OLED_BLACK }

@Composable
fun MyApplicationTheme(
    theme: AppTheme = AppTheme.OLED_BLACK,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = theme.primary,
        onPrimary = Color.White,
        primaryContainer = theme.primaryContainer,
        onPrimaryContainer = Color.White,
        secondary = theme.primary,
        onSecondary = Color.Black,
        secondaryContainer = theme.surfaceElevated,
        onSecondaryContainer = Color.White,
        background = theme.background,
        onBackground = theme.textPrimary,
        surface = theme.surface,
        onSurface = theme.textPrimary,
        surfaceVariant = theme.surfaceVariant,
        onSurfaceVariant = theme.textSecondary,
        outline = theme.border
    )

    CompositionLocalProvider(LocalAppTheme provides theme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
