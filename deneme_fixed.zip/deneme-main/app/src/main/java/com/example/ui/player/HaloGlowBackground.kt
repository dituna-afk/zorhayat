package com.example.ui.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.theme.LocalAppTheme
import kotlin.math.abs

/**
 * GPU Hızlandırmalı YouTube Music 'Halo Glow' Ortam Işığı Arka Planı.
 * Recomposition döngüsünden tamamen arındırılmıştır;
 * Doğrudan `graphicsLayer { ... }` ve `drawBehind { ... }` ile
 * RenderThread / GPU üzerinde 120 FPS pürüzsüzlükte çalışır.
 */
@Composable
fun HaloGlowBackground(
    seedString: String,
    isPlaying: Boolean = true,
    modifier: Modifier = Modifier
) {
    val activeTheme = LocalAppTheme.current
    val (primaryGlow, secondaryGlow) = extractAtmosphericColors(seedString, activeTheme.haloPrimary, activeTheme.haloSecondary)

    val animatedPrimary by animateColorAsState(
        targetValue = primaryGlow,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "halo_primary_color"
    )

    val animatedSecondary by animateColorAsState(
        targetValue = secondaryGlow,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "halo_secondary_color"
    )

    // Ritmik nefes alma (Pulsing Glow) sonsuz geçişi
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_transition")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = if (isPlaying) 1.15f else 0.94f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = if (isPlaying) 0.68f else 0.40f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val bgColor = activeTheme.background

    Box(
        modifier = modifier
            .fillMaxSize()
            // 1. GPU Katmanında Donanımsal Hızlandırma
            .graphicsLayer {
                clip = true
            }
            // 2. Recomposition Olmaksızın Doğrudan RenderThread'de Çizim
            .drawBehind {
                val centerOffset = Offset(size.width / 2f, size.height * 0.34f)
                val dynamicRadius = (size.width * 0.96f) * pulseScale

                // Merkezden yayılan dinamik radyal Halo Glow ışığı
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            animatedPrimary.copy(alpha = pulseAlpha),
                            animatedSecondary.copy(alpha = pulseAlpha * 0.55f),
                            animatedPrimary.copy(alpha = pulseAlpha * 0.20f),
                            bgColor.copy(alpha = 0.85f),
                            bgColor
                        ),
                        center = centerOffset,
                        radius = dynamicRadius
                    )
                )

                // Alt alanlar için pürüzsüz karartma gradyanı
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            bgColor.copy(alpha = 0.55f),
                            bgColor.copy(alpha = 0.95f),
                            bgColor
                        ),
                        startY = size.height * 0.40f,
                        endY = size.height
                    )
                )
            }
    )
}

/**
 * Şarkı başlığı veya aktif tema tonundan atmosferik renk çiftini türetir.
 */
private fun extractAtmosphericColors(
    seed: String,
    themeHaloPrimary: Color,
    themeHaloSecondary: Color
): Pair<Color, Color> {
    if (seed.isBlank()) {
        return Pair(themeHaloPrimary, themeHaloSecondary)
    }

    val hash = abs(seed.hashCode())
    val customPairs = listOf(
        Pair(themeHaloPrimary, themeHaloSecondary),
        Pair(Color(0xFFFF0033), Color(0xFF8B0000)), // Kırmızı
        Pair(Color(0xFFFF2D75), Color(0xFF8B0032)), // Kiraz Pembe
        Pair(Color(0xFFA855F7), Color(0xFF581C87)), // Ametist Mor
        Pair(Color(0xFFFF7597), Color(0xFFD4426F)), // Sakura Gül Kurusu
        Pair(Color(0xFF0070F3), Color(0xFF001B44)), // Gece Mavisi
        Pair(Color(0xFF00B4D8), Color(0xFF0077B6))  // Okyanus Camgöbeği
    )
    return customPairs[hash % customPairs.size]
}
