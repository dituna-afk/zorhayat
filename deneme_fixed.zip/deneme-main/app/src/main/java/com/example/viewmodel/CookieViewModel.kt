package com.example.viewmodel

import android.app.Application
import android.util.Log
import android.webkit.CookieManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CookieStorageHelper
import com.example.downloader.DownloadListener
import com.example.downloader.DownloadProgress
import com.example.downloader.MultiThreadChunkedDownloader
import com.example.model.CookieItem
import com.example.model.CookieLogEntry
import com.example.model.CookieParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CookieUiState(
    val currentUrl: String = "https://httpbin.org/cookies",
    val inputUrl: String = "https://httpbin.org/cookies",
    val pageTitle: String = "Web Sayfası",
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val rawCookies: String? = null,
    val parsedCookies: List<CookieItem> = emptyList(),
    val searchQuery: String = "",
    val lastUpdated: String? = null,
    val logHistory: List<CookieLogEntry> = emptyList(),
    val showClearDialog: Boolean = false,
    val showAddCookieDialog: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val statusMessage: String? = null,
    val isEncryptedStorage: Boolean = true,
    val isRestoredFromStorage: Boolean = false,
    val storageTimestamp: String? = null,

    // Çok Parçalı İndirici (Downloader) Durumu
    val downloadUrl: String = "https://httpbin.org/bytes/524288",
    val downloadChunkCount: Int = 4,
    val downloadProgress: DownloadProgress? = null,
    val downloadStatus: String = "Hazır",
    val isDownloaderActive: Boolean = false,
    val isDownloaderPaused: Boolean = false,
    val downloadedFilePath: String? = null
)

class CookieViewModel(application: Application) : AndroidViewModel(application) {

    private val storageHelper = CookieStorageHelper.getInstance(application)
    private val _uiState = MutableStateFlow(
        CookieUiState(
            isEncryptedStorage = storageHelper.isEncrypted
        )
    )
    val uiState: StateFlow<CookieUiState> = _uiState.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val fullDateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())

    private var activeDownloader: MultiThreadChunkedDownloader? = null

    companion object {
        const val TAG = "CookieManager"
        const val STORAGE_TAG = "CookieStorage"
        const val DOWNLOADER_TAG = "MultiChunkDownloader"
    }

    init {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        loadPersistedCookiesOnStartup()
    }

    private fun loadPersistedCookiesOnStartup() {
        val savedCookies = storageHelper.getLatestCookies()
        val savedUrl = storageHelper.getLatestUrl()
        val timestampMs = storageHelper.getLastSavedTimestamp()

        Log.d(STORAGE_TAG, "==================================================")
        Log.d(STORAGE_TAG, "Uygulama Açıldı: Kalıcı Depolama Kontrol Ediliyor...")
        Log.d(STORAGE_TAG, "Depolama Tipi: ${if (storageHelper.isEncrypted) "EncryptedSharedPreferences (AES-256)" else "Standart SharedPreferences"}")

        if (!savedCookies.isNullOrBlank()) {
            val formattedDate = if (timestampMs > 0) fullDateFormat.format(Date(timestampMs)) else "Önceki Oturum"
            Log.d(STORAGE_TAG, "Kayıtlı Çerez Bulundu ve Yüklendi: $savedCookies")
            Log.d(STORAGE_TAG, "==================================================")

            val parsed = CookieParser.parse(savedCookies)
            val targetUrl = savedUrl ?: _uiState.value.currentUrl

            try {
                CookieManager.getInstance().setCookie(targetUrl, savedCookies)
                CookieManager.getInstance().flush()
            } catch (e: Exception) {
                Log.w(STORAGE_TAG, "CookieManager sync hatası: ${e.message}")
            }

            _uiState.update {
                it.copy(
                    currentUrl = targetUrl,
                    inputUrl = targetUrl,
                    rawCookies = savedCookies,
                    parsedCookies = parsed,
                    isRestoredFromStorage = true,
                    storageTimestamp = formattedDate,
                    lastUpdated = timeFormat.format(Date()),
                    statusMessage = "Önceki oturumdan ${parsed.size} çerez EncryptedSharedPreferences'tan yüklendi."
                )
            }
        }
    }

    fun onUrlInputChanged(newUrl: String) {
        _uiState.update { it.copy(inputUrl = newUrl) }
    }

    fun navigateToUrl(targetUrl: String) {
        var formatted = targetUrl.trim()
        if (!formatted.startsWith("http://") && !formatted.startsWith("https://")) {
            formatted = "https://$formatted"
        }
        _uiState.update { it.copy(currentUrl = formatted, inputUrl = formatted) }
    }

    fun onPageStarted(url: String?) {
        _uiState.update {
            it.copy(
                isLoading = true,
                currentUrl = url ?: it.currentUrl,
                statusMessage = "Sayfa yükleniyor..."
            )
        }
    }

    fun onPageProgress(progress: Int) {
        _uiState.update { it.copy(progress = progress) }
    }

    fun onPageFinished(url: String?, title: String?) {
        val targetUrl = url ?: _uiState.value.currentUrl
        _uiState.update {
            it.copy(
                isLoading = false,
                currentUrl = targetUrl,
                inputUrl = targetUrl,
                pageTitle = if (!title.isNullOrBlank()) title else it.pageTitle
            )
        }
        fetchCookiesFromManager(targetUrl, source = "onPageFinished (Otomatik)")
    }

    fun updateNavigationState(canGoBack: Boolean, canGoForward: Boolean) {
        _uiState.update {
            it.copy(canGoBack = canGoBack, canGoForward = canGoForward)
        }
    }

    fun fetchCookiesFromManager(url: String = _uiState.value.currentUrl, source: String = "Manuel İstek") {
        viewModelScope.launch {
            try {
                val cookieManager = CookieManager.getInstance()
                val cookieString = cookieManager.getCookie(url)

                Log.d(TAG, "==================================================")
                Log.d(TAG, "[$source] URL: $url")
                if (!cookieString.isNullOrEmpty()) {
                    Log.d(TAG, "Alınan Çerezler: $cookieString")
                    storageHelper.saveCookies(url, cookieString)
                    Log.d(STORAGE_TAG, "Çerez EncryptedSharedPreferences içine güvenli olarak yazıldı.")
                } else {
                    Log.d(TAG, "Bu web sitesi için henüz çerez (cookie) bulunamadı.")
                }
                Log.d(TAG, "==================================================")

                val parsed = CookieParser.parse(cookieString)
                val timestamp = timeFormat.format(Date())
                val fullTimestamp = fullDateFormat.format(Date())

                val entry = CookieLogEntry(
                    timestamp = timestamp,
                    url = url,
                    cookieString = cookieString ?: "(Boş)",
                    count = parsed.size
                )

                _uiState.update { state ->
                    val updatedLogs = (listOf(entry) + state.logHistory).take(30)
                    state.copy(
                        rawCookies = cookieString,
                        parsedCookies = parsed,
                        lastUpdated = timestamp,
                        storageTimestamp = if (!cookieString.isNullOrEmpty()) fullTimestamp else state.storageTimestamp,
                        isRestoredFromStorage = false,
                        logHistory = updatedLogs,
                        statusMessage = if (!cookieString.isNullOrEmpty()) {
                            "${parsed.size} çerez Logcat'e yazdırıldı ve SharedPreferences'a kaydedildi."
                        } else {
                            "Henüz çerez bulunamadı ($timestamp)"
                        }
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Çerezler alınırken hata: ${e.message}", e)
                _uiState.update { it.copy(statusMessage = "Hata: ${e.message}") }
            }
        }
    }

    fun clearAllCookies(onFinished: (() -> Unit)? = null) {
        viewModelScope.launch {
            val cookieManager = CookieManager.getInstance()
            cookieManager.removeAllCookies { value ->
                cookieManager.flush()
                storageHelper.clearAll()
                _uiState.update {
                    it.copy(
                        rawCookies = null,
                        parsedCookies = emptyList(),
                        storageTimestamp = null,
                        isRestoredFromStorage = false,
                        statusMessage = "Tüm çerezler bellekten ve SharedPreferences'tan temizlendi.",
                        showClearDialog = false
                    )
                }
                onFinished?.invoke()
            }
        }
    }

    fun setTestCookie(name: String, value: String) {
        val current = _uiState.value.currentUrl
        val cookieManager = CookieManager.getInstance()
        val cookiePayload = "$name=$value; path=/; max-age=3600"
        cookieManager.setCookie(current, cookiePayload)
        cookieManager.flush()
        fetchCookiesFromManager(current, source = "Test Çerezi Eklendi")
        _uiState.update { it.copy(showAddCookieDialog = false) }
    }

    // ==========================================
    // ÇOK PARÇALI İNDİRİCİ (DOWNLOADER) İŞLEMLERİ
    // ==========================================

    fun onDownloadUrlChanged(url: String) {
        _uiState.update { it.copy(downloadUrl = url) }
    }

    fun onDownloadChunkCountChanged(count: Int) {
        _uiState.update { it.copy(downloadChunkCount = count.coerceIn(1, 8)) }
    }

    fun startOrResumeDownload() {
        val currentState = _uiState.value
        if (currentState.isDownloaderActive && !currentState.isDownloaderPaused) {
            return
        }

        if (currentState.isDownloaderPaused && activeDownloader != null) {
            _uiState.update { it.copy(isDownloaderPaused = false, downloadStatus = "Devam ediliyor...") }
            activeDownloader?.start()
            return
        }

        val context = getApplication<Application>()
        val downloadsDir = File(context.cacheDir, "downloads").apply { mkdirs() }
        val fileName = "download_${System.currentTimeMillis()}.bin"
        val destFile = File(downloadsDir, fileName)

        val cookie = currentState.rawCookies ?: storageHelper.getLatestCookies()

        activeDownloader = MultiThreadChunkedDownloader(
            fileUrl = currentState.downloadUrl,
            destinationFile = destFile,
            chunkCount = currentState.downloadChunkCount,
            cookieHeader = cookie,
            listener = object : DownloadListener {
                override fun onStarted(totalBytes: Long, chunkCount: Int) {
                    _uiState.update {
                        it.copy(
                            isDownloaderActive = true,
                            isDownloaderPaused = false,
                            downloadStatus = "İndiriliyor: $chunkCount parça (${totalBytes / 1024} KB)"
                        )
                    }
                }

                override fun onProgress(progress: DownloadProgress) {
                    _uiState.update {
                        it.copy(
                            downloadProgress = progress,
                            downloadStatus = "İndiriliyor: %${String.format(Locale.US, "%.1f", progress.progressPercent)} (${progress.speedBytesPerSec / 1024} KB/s)"
                        )
                    }
                }

                override fun onPaused(downloadedBytes: Long, totalBytes: Long) {
                    _uiState.update {
                        it.copy(
                            isDownloaderPaused = true,
                            downloadStatus = "Duraklatıldı: ${downloadedBytes / 1024} / ${totalBytes / 1024} KB"
                        )
                    }
                }

                override fun onCompleted(destinationFile: File) {
                    _uiState.update {
                        it.copy(
                            isDownloaderActive = false,
                            isDownloaderPaused = false,
                            downloadedFilePath = destinationFile.absolutePath,
                            downloadStatus = "Tamamlandı! Dosya boyutu: ${destinationFile.length() / 1024} KB",
                            statusMessage = "Çok parçalı indirme başarıyla tamamlandı!"
                        )
                    }
                }

                override fun onError(exception: Exception) {
                    _uiState.update {
                        it.copy(
                            isDownloaderActive = false,
                            isDownloaderPaused = false,
                            downloadStatus = "Hata: ${exception.message}",
                            statusMessage = "İndirme hatası: ${exception.message}"
                        )
                    }
                }

                override fun onCancelled() {
                    _uiState.update {
                        it.copy(
                            isDownloaderActive = false,
                            isDownloaderPaused = false,
                            downloadProgress = null,
                            downloadStatus = "İptal Edildi",
                            statusMessage = "İndirme iptal edildi."
                        )
                    }
                }
            }
        )

        _uiState.update {
            it.copy(
                isDownloaderActive = true,
                isDownloaderPaused = false,
                downloadStatus = "Bağlantı kuruluyor..."
            )
        }
        activeDownloader?.start()
    }

    fun pauseDownload() {
        activeDownloader?.pause()
        _uiState.update { it.copy(isDownloaderPaused = true, downloadStatus = "Duraklatıldı") }
    }

    fun cancelDownload() {
        activeDownloader?.cancel(deleteFile = true)
        activeDownloader = null
        _uiState.update {
            it.copy(
                isDownloaderActive = false,
                isDownloaderPaused = false,
                downloadProgress = null,
                downloadStatus = "İptal Edildi"
            )
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setShowClearDialog(show: Boolean) {
        _uiState.update { it.copy(showClearDialog = show) }
    }

    fun setShowAddCookieDialog(show: Boolean) {
        _uiState.update { it.copy(showAddCookieDialog = show) }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }
}
