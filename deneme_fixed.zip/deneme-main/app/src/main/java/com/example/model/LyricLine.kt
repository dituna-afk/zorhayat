package com.example.model

import androidx.compose.runtime.Immutable

/**
 * Zaman damgalı şarkı sözü satırı (LRC).
 */
@Immutable
data class LyricLine(
    val timeMs: Long,
    val text: String
)

object LrcParser {
    private val LRC_REGEX = Regex("""\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?](.*)""")

    /**
     * Standart LRC formatındaki metni ayrıştırarak zaman sırasına göre sıralı LyricLine listesi döner.
     * Örnek girdi:
     * [00:12.30] İlk dize
     * [00:15.80] İkinci dize
     */
    fun parse(lrcContent: String?): List<LyricLine> {
        if (lrcContent.isNullOrBlank()) return emptyList()

        val lines = mutableListOf<LyricLine>()

        lrcContent.lineSequence().forEach { line ->
            val match = LRC_REGEX.find(line.trim())
            if (match != null) {
                val (minutes, seconds, millis, text) = match.destructured
                val minVal = minutes.toLongOrNull() ?: 0L
                val secVal = seconds.toLongOrNull() ?: 0L
                val milliVal = when (millis.length) {
                    2 -> (millis.toLongOrNull() ?: 0L) * 10
                    3 -> millis.toLongOrNull() ?: 0L
                    else -> 0L
                }
                val totalMs = (minVal * 60 * 1000) + (secVal * 1000) + milliVal
                val cleanText = text.trim()
                if (cleanText.isNotEmpty()) {
                    lines.add(LyricLine(totalMs, cleanText))
                }
            }
        }

        return lines.sortedBy { it.timeMs }
    }

    /**
     * Verilen milisaniyeye denk gelen aktif söz satırının indeksini döner.
     */
    fun getActiveIndex(lines: List<LyricLine>, currentMs: Long): Int {
        if (lines.isEmpty()) return -1
        var activeIdx = -1
        for (i in lines.indices) {
            if (lines[i].timeMs <= currentMs) {
                activeIdx = i
            } else {
                break
            }
        }
        return activeIdx
    }
}
