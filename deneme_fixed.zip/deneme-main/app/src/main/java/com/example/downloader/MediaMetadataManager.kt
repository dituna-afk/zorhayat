package com.example.downloader

import android.content.Context
import android.os.Environment
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import androidx.compose.runtime.Immutable

/**
 * İndirilen ses dosyasının meta verilerini temsil eden veri modeli.
 */
@Immutable
data class MediaTrackInfo(
    val videoId: String,
    val title: String,
    val artist: String = "Bilinmeyen Sanatçı",
    val durationSeconds: Long = 0L,
    val thumbnailUrl: String? = null,
    val sourceUrl: String? = null,
    val savedAtTimestamp: Long = System.currentTimeMillis()
)

/**
 * Kayıt ve etiketleme işleminin nihai dosya çıktıları.
 */
@Immutable
data class SavedMediaResult(
    val trackInfo: MediaTrackInfo,
    val audioFile: File,
    val metadataJsonFile: File,
    val coverArtFile: File?
)

interface MediaSaveCallback {
    fun onSuccess(result: SavedMediaResult)
    fun onError(exception: Exception)
}

/**
 * İndirilen .m4a ses dosyalarını hedef dizine (Environment.DIRECTORY_MUSIC/Morphe) taşıyan,
 * şarkının videoId, başlık, sanatçı gibi bilgilerini {videoId}.json olarak kaydeden
 * ve kapak görselini {videoId}.jpg olarak indiren yardımcı yönetici sınıfı.
 */
class MediaMetadataManager(private val context: Context) {

    companion object {
        private const val TAG = "MediaMetadataManager"
        const val SUB_FOLDER_NAME = "Morphe"
    }

    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    /**
     * Hedef müzik dizinini döner.
     * Android Scoped Storage uyumluluğu için öncelikle app-specific harici müzik dizinini,
     * gerekirse genel Environment.DIRECTORY_MUSIC/Morphe dizinini kullanır.
     */
    fun getTargetMusicDirectory(): File {
        val appMusicDir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
        val targetDir = File(appMusicDir, SUB_FOLDER_NAME)
        if (!targetDir.exists()) {
            targetDir.mkdirs()
        }
        return targetDir
    }

    /**
     * Coroutine uyumlu doğrudan çağırma fonksiyonu (suspend).
     */
    suspend fun processAndSaveMedia(
        tempAudioFile: File,
        trackInfo: MediaTrackInfo
    ): SavedMediaResult = withContext(Dispatchers.IO) {
        val targetDir = getTargetMusicDirectory()

        // 1. Ses dosyasını {videoId}.m4a olarak hedef klasöre taşı / kopyala
        val cleanId = sanitizeFileName(trackInfo.videoId)
        val targetAudioFile = File(targetDir, "$cleanId.m4a")

        if (tempAudioFile.exists()) {
            if (tempAudioFile.absolutePath != targetAudioFile.absolutePath) {
                val moved = tempAudioFile.renameTo(targetAudioFile)
                if (!moved) {
                    tempAudioFile.inputStream().use { input ->
                        targetAudioFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    tempAudioFile.delete()
                }
                Log.d(TAG, "Ses dosyası taşındı: ${targetAudioFile.absolutePath}")
            } else {
                Log.d(TAG, "Ses dosyası zaten hedef konumda: ${targetAudioFile.absolutePath}")
            }
        } else {
            throw IllegalArgumentException("Kaynak ses dosyası bulunamadı: ${tempAudioFile.absolutePath}")
        }

        // 2. {videoId}.json meta veri yan dosyasını oluştur ve yaz
        val targetJsonFile = File(targetDir, "$cleanId.json")
        val jsonObject = JSONObject().apply {
            put("videoId", trackInfo.videoId)
            put("title", trackInfo.title)
            put("artist", trackInfo.artist)
            put("durationSeconds", trackInfo.durationSeconds)
            put("thumbnailUrl", trackInfo.thumbnailUrl ?: "")
            put("sourceUrl", trackInfo.sourceUrl ?: "")
            put("savedAtTimestamp", trackInfo.savedAtTimestamp)
            put("audioFileName", targetAudioFile.name)
            put("audioFileSizeBytes", targetAudioFile.length())
        }
        targetJsonFile.writeText(jsonObject.toString(2), Charsets.UTF_8)
        Log.d(TAG, "Meta veri JSON kaydedildi: ${targetJsonFile.absolutePath}")

        // 3. Varsa kapak görselini URL üzerinden arka planda çekip {videoId}.jpg olarak kaydet
        var coverArtFile: File? = null
        if (!trackInfo.thumbnailUrl.isNullOrBlank()) {
            val targetCoverFile = File(targetDir, "$cleanId.jpg")
            val downloaded = downloadCoverArt(trackInfo.thumbnailUrl, targetCoverFile)
            if (downloaded && targetCoverFile.exists()) {
                coverArtFile = targetCoverFile
                Log.d(TAG, "Kapak görseli kaydedildi: ${targetCoverFile.absolutePath}")
            }
        }

        SavedMediaResult(
            trackInfo = trackInfo,
            audioFile = targetAudioFile,
            metadataJsonFile = targetJsonFile,
            coverArtFile = coverArtFile
        )
    }

    /**
     * Fragment ve geleneksel callback mimarisiyle çalışan asenkron metod.
     */
    fun processAndSaveMediaAsync(
        tempAudioFile: File,
        trackInfo: MediaTrackInfo,
        callback: MediaSaveCallback
    ) {
        coroutineScope.launch {
            try {
                val result = processAndSaveMedia(tempAudioFile, trackInfo)
                withContext(Dispatchers.Main) {
                    callback.onSuccess(result)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Medya işlenirken hata oluştu: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    callback.onError(e)
                }
            }
        }
    }

    /**
     * Kapak görselini HTTP üzerinden çekip yerel dosyaya yazar.
     */
    private fun downloadCoverArt(imageUrl: String, outputFile: File): Boolean {
        var connection: HttpURLConnection? = null
        var inputStream: InputStream? = null
        var outputStream: FileOutputStream? = null

        return try {
            val url = URL(imageUrl)
            connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 10000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) MorpheMediaTagger/1.0")
            }
            connection.connect()

            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                inputStream = connection.inputStream
                outputStream = FileOutputStream(outputFile)
                val buffer = ByteArray(4096)
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                }
                outputStream.flush()
                true
            } else {
                Log.w(TAG, "Kapak görseli HTTP yanıt kodu: ${connection.responseCode}")
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Kapak görseli indirilemedi: ${e.message}")
            false
        } finally {
            outputStream?.close()
            inputStream?.close()
            connection?.disconnect()
        }
    }

    /**
     * Morphe müzik klasöründeki (Environment.DIRECTORY_MUSIC/Morphe) tüm fiziksel ses dosyalarını
     * MediaMetadataRetriever ve JSON meta verileri ile tarayıp listeler.
     */
    fun loadAllSavedTracks(): List<SavedMediaResult> {
        val targetDir = getTargetMusicDirectory()
        val audioFiles = targetDir.listFiles { _, name ->
            name.endsWith(".m4a", ignoreCase = true) ||
                    name.endsWith(".mp3", ignoreCase = true) ||
                    name.endsWith(".ogg", ignoreCase = true) ||
                    name.endsWith(".flac", ignoreCase = true)
        } ?: emptyArray()

        val results = mutableListOf<SavedMediaResult>()

        for (audioFile in audioFiles) {
            try {
                val baseName = audioFile.nameWithoutExtension
                val jsonFile = File(targetDir, "$baseName.json")
                var coverFile: File? = File(targetDir, "$baseName.jpg").takeIf { it.exists() }

                var videoId = baseName
                var title = baseName
                var artist = "Bilinmeyen Sanatçı"
                var duration = 0L
                var thumbUrl: String? = null
                var savedAt = audioFile.lastModified()
                var sourceUrl: String? = null

                if (jsonFile.exists()) {
                    try {
                        val jsonString = jsonFile.readText(Charsets.UTF_8)
                        val obj = JSONObject(jsonString)
                        videoId = obj.optString("videoId", baseName)
                        title = obj.optString("title", baseName)
                        artist = obj.optString("artist", "Bilinmeyen Sanatçı")
                        duration = obj.optLong("durationSeconds", 0L)
                        thumbUrl = obj.optString("thumbnailUrl", null)
                        savedAt = obj.optLong("savedAtTimestamp", audioFile.lastModified())
                        sourceUrl = obj.optString("sourceUrl", null)
                    } catch (e: Exception) {
                        Log.w(TAG, "JSON okunamadı ($baseName): ${e.message}")
                    }
                }

                // Eğer JSON yoksa veya eksikse, sistem MediaMetadataRetriever ile dosya etiketlerini oku
                if (!jsonFile.exists() || title == baseName) {
                    val retriever = android.media.MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(audioFile.absolutePath)
                        val metaTitle = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE)
                        val metaArtist = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        val metaDuration = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)

                        if (!metaTitle.isNullOrBlank()) title = metaTitle
                        if (!metaArtist.isNullOrBlank()) artist = metaArtist
                        if (metaDuration != null) {
                            duration = metaDuration.toLongOrNull()?.let { it / 1000 } ?: duration
                        }

                        // Eğer kapak resmi henüz yoksa ve dosyada gömülü resim varsa çıkar ve kaydet
                        if (coverFile == null) {
                            val picBytes = retriever.embeddedPicture
                            if (picBytes != null) {
                                val extractedCover = File(targetDir, "$baseName.jpg")
                                extractedCover.writeBytes(picBytes)
                                coverFile = extractedCover
                            }
                        }
                    } catch (re: Exception) {
                        Log.w(TAG, "MediaMetadataRetriever okuma hatası (${audioFile.name}): ${re.message}")
                    } finally {
                        retriever.release()
                    }
                }

                val track = MediaTrackInfo(
                    videoId = videoId,
                    title = title,
                    artist = artist,
                    durationSeconds = duration,
                    thumbnailUrl = thumbUrl,
                    sourceUrl = sourceUrl,
                    savedAtTimestamp = savedAt
                )

                results.add(
                    SavedMediaResult(
                        trackInfo = track,
                        audioFile = audioFile,
                        metadataJsonFile = jsonFile,
                        coverArtFile = coverFile
                    )
                )
            } catch (e: Exception) {
                Log.w(TAG, "Ses dosyası işlenirken hata (${audioFile.name}): ${e.message}")
            }
        }

        return results.sortedByDescending { it.trackInfo.savedAtTimestamp }
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    }
}
