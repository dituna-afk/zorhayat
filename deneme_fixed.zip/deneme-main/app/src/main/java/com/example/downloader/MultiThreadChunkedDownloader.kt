package com.example.downloader

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Immutable
data class DownloadProgress(
    val downloadedBytes: Long,
    val totalBytes: Long,
    val progressPercent: Float,
    val speedBytesPerSec: Long,
    val activeChunks: Int,
    val chunkProgresses: List<ChunkState> = emptyList()
)

@Stable
data class ChunkState(
    val chunkIndex: Int,
    val startByte: Long,
    val endByte: Long,
    var currentByte: Long,
    var isDone: Boolean = false
) {
    val totalChunkBytes: Long get() = (endByte - startByte) + 1
    val downloadedInChunk: Long get() = (currentByte - startByte)
    val progressPercent: Float get() = if (totalChunkBytes > 0) (downloadedInChunk.toFloat() / totalChunkBytes) * 100f else 0f
}

interface DownloadListener {
    fun onStarted(totalBytes: Long, chunkCount: Int)
    fun onProgress(progress: DownloadProgress)
    fun onPaused(downloadedBytes: Long, totalBytes: Long)
    fun onCompleted(destinationFile: File)
    fun onError(exception: Exception)
    fun onCancelled()
}

/**
 * HttpURLConnection kullanan, çok parçalı (multi-threaded chunked) dosya indirme yöneticisi.
 *
 * Özellikler:
 * 1. Content-Length ve Range: bytes desteğini kontrol eder.
 * 2. Dosyayı belirtilen sayıda parçaya bölerek her parçayı ayrı HTTP Range başlığı ile indirir.
 * 3. RandomAccessFile ile her parçayı hedef dosyanın doğru byte konumuna doğrudan yazar.
 * 4. Cookie ve User-Agent gibi özel HTTP başlıklarını (header) destekler.
 * 5. İndirme hızı, anlık byte ve yüzde ilerleme bildirimleri sunar.
 * 6. Duraklatma (Pause), Devam Etme (Resume) ve İptal (Cancel) mekanizmalarını içerir.
 */
class MultiThreadChunkedDownloader(
    val fileUrl: String,
    val destinationFile: File,
    val chunkCount: Int = 4,
    val cookieHeader: String? = null,
    val userAgent: String? = YouTubeStreamResolver.YOUTUBE_ANDROID_USER_AGENT,
    val listener: DownloadListener? = null
) {
    companion object {
        private const val TAG = "MultiChunkDownloader"
        private const val CONNECT_TIMEOUT_MS = 15000
        private const val READ_TIMEOUT_MS = 15000
        private const val BUFFER_SIZE = 8192 // 8 KB buffer
    }

    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    private var downloadJob: Job? = null

    // .part uzantılı geçici dosya üzerinde RandomAccessFile ile paralel yazım
    val partFile: File = if (destinationFile.name.endsWith(".part")) {
        destinationFile
    } else {
        File(destinationFile.parentFile, "${destinationFile.name}.part")
    }

    private val isPaused = AtomicBoolean(false)
    private val isCancelled = AtomicBoolean(false)
    private val isRunning = AtomicBoolean(false)

    private val totalBytes = AtomicLong(0L)
    private val totalDownloadedBytes = AtomicLong(0L)

    private val chunkList = mutableListOf<ChunkState>()
    private var lastSpeedCheckTime = 0L
    private var lastSpeedCheckBytes = 0L
    private var currentSpeed = 0L

    val isDownloading: Boolean get() = isRunning.get() && !isPaused.get()
    val isPausedState: Boolean get() = isPaused.get()

    /**
     * İndirme işlemini başlatır veya duraklatılmışsa kaldığı yerden devam ettirir.
     */
    fun start() {
        if (isRunning.get() && !isPaused.get()) {
            Log.w(TAG, "İndirme işlemi zaten aktif.")
            return
        }

        isPaused.set(false)
        isCancelled.set(false)
        isRunning.set(true)

        downloadJob = coroutineScope.launch {
            try {
                // Eğer ilk defa başlatılıyorsa meta verileri al ve parçaları hesapla
                if (chunkList.isEmpty()) {
                    val fileLength = fetchContentLengthAndCheckRange(fileUrl)
                    if (fileLength <= 0) {
                        throw IllegalStateException("Dosya boyutu belirlenemedi veya sunucu erişimi başarısız.")
                    }

                    totalBytes.set(fileLength)
                    prepareDestinationFile(fileLength)
                    initializeChunks(fileLength, chunkCount)

                    withContext(Dispatchers.Main) {
                        listener?.onStarted(fileLength, chunkList.size)
                    }
                }

                lastSpeedCheckTime = System.currentTimeMillis()
                lastSpeedCheckBytes = totalDownloadedBytes.get()

                // Tüm parçaları paralel (async) coroutine thread'lerinde çalıştır
                val chunkJobs = chunkList.mapIndexed { index, chunk ->
                    async(Dispatchers.IO) {
                        if (!chunk.isDone && !isPaused.get() && !isCancelled.get()) {
                            downloadChunk(chunk)
                        }
                    }
                }

                chunkJobs.awaitAll()

                if (isCancelled.get()) {
                    withContext(Dispatchers.Main) {
                        listener?.onCancelled()
                    }
                } else if (isPaused.get()) {
                    withContext(Dispatchers.Main) {
                        listener?.onPaused(totalDownloadedBytes.get(), totalBytes.get())
                    }
                } else {
                    // Tüm 4 parça başarıyla tamamlandı: .part uzantısını nihai .m4a dosyasına taşı
                    if (partFile != destinationFile) {
                        if (destinationFile.exists()) destinationFile.delete()
                        val renamed = partFile.renameTo(destinationFile)
                        if (!renamed) {
                            partFile.inputStream().use { input ->
                                destinationFile.outputStream().use { output ->
                                    input.copyTo(output)
                                }
                            }
                            partFile.delete()
                        }
                    }

                    isRunning.set(false)
                    withContext(Dispatchers.Main) {
                        listener?.onCompleted(destinationFile)
                    }
                }
            } catch (e: Exception) {
                isRunning.set(false)
                Log.e(TAG, "İndirme sırasında hata: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    listener?.onError(e)
                }
            }
        }
    }

    /**
     * İndirmeyi duraklatır. Segmentlerin kaldığı byte konumları korunur.
     */
    fun pause() {
        if (!isRunning.get() || isPaused.get()) return
        Log.d(TAG, "İndirme duraklatılıyor...")
        isPaused.set(true)
        downloadJob?.cancel()
        isRunning.set(false)
    }

    /**
     * İndirmeyi tamamen iptal eder ve geçici dosyayı temizler.
     */
    fun cancel(deleteFile: Boolean = true) {
        Log.d(TAG, "İndirme iptal ediliyor...")
        isCancelled.set(true)
        isPaused.set(false)
        isRunning.set(false)
        downloadJob?.cancel()

        if (deleteFile) {
            if (partFile.exists()) partFile.delete()
            if (destinationFile.exists()) destinationFile.delete()
        }
    }

    /**
     * Dosya boyutunu (Content-Length) ve Range desteğini sorgulamak için HEAD veya Range isteği yapar.
     * 173 KB sahte/hata dosyalarını engellemek için Content-Type ve boyut doğrulaması yapar.
     */
    private fun fetchContentLengthAndCheckRange(targetUrl: String): Long {
        val url = URL(targetUrl)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "HEAD"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            applyHeaders(this)
        }

        return try {
            connection.connect()
            val code = connection.responseCode
            val length = connection.contentLengthLong
            val contentType = connection.contentType ?: ""

            Log.d(TAG, "HEAD Yanıtı: HTTP $code | Content-Length: $length bytes | MIME: $contentType")

            // HTML veya JSON hata sayfası kontrolü (173 KB sahte dosya engeli)
            if (contentType.contains("text/html", ignoreCase = true) ||
                contentType.contains("application/json", ignoreCase = true)
            ) {
                throw IllegalStateException("Ses akışı yerine YouTube hata yanıtı ($contentType) döndü. Oturum çerezlerinizi yenileyiniz.")
            }

            if (length in 1 until 1024 * 1024L) {
                throw IllegalStateException("Ses dosyası boyutu 1 MB'tan küçük (${length / 1024} KB). 173 KB sahte dosya engellendi.")
            }

            if (length > 0) {
                length
            } else {
                probeViaGet(targetUrl)
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun probeViaGet(targetUrl: String): Long {
        val url = URL(targetUrl)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Range", "bytes=0-0")
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            applyHeaders(this)
        }

        return try {
            connection.connect()
            val contentType = connection.contentType ?: ""
            if (contentType.contains("text/html", ignoreCase = true) ||
                contentType.contains("application/json", ignoreCase = true)
            ) {
                throw IllegalStateException("Ses akışı yerine YouTube hata yanıtı ($contentType) döndü.")
            }

            val contentRange = connection.getHeaderField("Content-Range")
            Log.d(TAG, "Content-Range probu: $contentRange")
            val len = if (!contentRange.isNullOrBlank()) {
                val totalStr = contentRange.substringAfterLast('/')
                totalStr.toLongOrNull() ?: connection.contentLengthLong
            } else {
                connection.contentLengthLong
            }

            if (len in 1 until 1024 * 1024L) {
                throw IllegalStateException("Ses dosyası boyutu 1 MB'tan küçük (${len / 1024} KB).")
            }

            len
        } finally {
            connection.disconnect()
        }
    }

    /**
     * Hedef .part dosyasını hazırlar ve disk üzerinde boyutu önceden tahsis eder (pre-allocation).
     */
    private fun prepareDestinationFile(totalLength: Long) {
        partFile.parentFile?.mkdirs()
        RandomAccessFile(partFile, "rw").use { raf ->
            raf.setLength(totalLength)
        }
        Log.d(TAG, "Hedef .part dosya hazırlandı ve $totalLength byte boyut tahsis edildi: ${partFile.absolutePath}")
    }

    /**
     * Dosyayı eşit segmentlere böler.
     */
    private fun initializeChunks(fileLength: Long, count: Int) {
        chunkList.clear()
        totalDownloadedBytes.set(0L)

        val actualCount = if (fileLength < count * 1024L) 1 else count // Çok küçük dosyalarda tek segment
        val chunkSize = fileLength / actualCount

        for (i in 0 until actualCount) {
            val start = i * chunkSize
            val end = if (i == actualCount - 1) fileLength - 1 else (start + chunkSize - 1)
            val chunk = ChunkState(
                chunkIndex = i,
                startByte = start,
                endByte = end,
                currentByte = start
            )
            chunkList.add(chunk)
            Log.d(TAG, "Segment #$i oluşturuldu: $start - $end (${chunk.totalChunkBytes} bytes)")
        }
    }

    /**
     * Tek bir segmenti Range başlığıyla indirip RandomAccessFile ile doğru ofsete yazar.
     */
    private fun downloadChunk(chunk: ChunkState) {
        if (chunk.currentByte > chunk.endByte) {
            chunk.isDone = true
            return
        }

        val url = URL(fileUrl)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            applyHeaders(this)
            // Range HTTP başlığı: bytes=start-end
            setRequestProperty("Range", "bytes=${chunk.currentByte}-${chunk.endByte}")
        }

        try {
            connection.connect()
            val responseCode = connection.responseCode
            // HTTP 206 (Partial Content) veya HTTP 200 dönebilir
            if (responseCode != HttpURLConnection.HTTP_PARTIAL && responseCode != HttpURLConnection.HTTP_OK) {
                throw IllegalStateException("Segment #${chunk.chunkIndex} için beklenmeyen HTTP yanıtı: $responseCode")
            }

            var inputStream: InputStream? = null
            var raf: RandomAccessFile? = null

            try {
                inputStream = connection.inputStream
                raf = RandomAccessFile(partFile, "rw")
                raf.seek(chunk.currentByte)

                val buffer = ByteArray(BUFFER_SIZE)
                var bytesRead: Int

                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    if (isPaused.get() || isCancelled.get()) {
                        break
                    }

                    raf.write(buffer, 0, bytesRead)
                    chunk.currentByte += bytesRead
                    val currentTotal = totalDownloadedBytes.addAndGet(bytesRead.toLong())

                    notifyProgress(currentTotal)
                }

                if (chunk.currentByte > chunk.endByte) {
                    chunk.isDone = true
                    Log.d(TAG, "Segment #${chunk.chunkIndex} tamamlandı.")
                }
            } finally {
                raf?.close()
                inputStream?.close()
            }
        } finally {
            connection.disconnect()
        }
    }

    /**
     * İlerleme ve hız hesaplamalarını UI'a iletir.
     */
    private fun notifyProgress(downloaded: Long) {
        val total = totalBytes.get()
        val now = System.currentTimeMillis()
        val timeDiff = now - lastSpeedCheckTime

        if (timeDiff >= 500) { // Her 500ms'de bir hız hesapla
            val bytesDiff = downloaded - lastSpeedCheckBytes
            currentSpeed = if (timeDiff > 0) (bytesDiff * 1000L) / timeDiff else 0L
            lastSpeedCheckTime = now
            lastSpeedCheckBytes = downloaded
        }

        val percent = if (total > 0) (downloaded.toFloat() / total.toFloat()) * 100f else 0f
        val activeCount = chunkList.count { !it.isDone }

        val progress = DownloadProgress(
            downloadedBytes = downloaded,
            totalBytes = total,
            progressPercent = percent,
            speedBytesPerSec = currentSpeed,
            activeChunks = activeCount,
            chunkProgresses = chunkList.map { it.copy() }
        )

        coroutineScope.launch(Dispatchers.Main) {
            listener?.onProgress(progress)
        }
    }

    private fun applyHeaders(connection: HttpURLConnection) {
        val ua = userAgent ?: YouTubeStreamResolver.YOUTUBE_ANDROID_USER_AGENT
        connection.setRequestProperty("User-Agent", ua)
        connection.setRequestProperty("Referer", YouTubeStreamResolver.YOUTUBE_MUSIC_REFERER)
        connection.setRequestProperty("Origin", YouTubeStreamResolver.YOUTUBE_MUSIC_ORIGIN)
        if (!cookieHeader.isNullOrBlank()) {
            connection.setRequestProperty("Cookie", cookieHeader)
            val sapisidHash = YouTubeStreamResolver.generateSapisidHash(cookieHeader)
            if (sapisidHash != null) {
                connection.setRequestProperty("Authorization", sapisidHash)
            }
        }
        connection.setRequestProperty("Accept-Encoding", "identity") // Chunk boyutlarının tutarlılığı için
    }
}
