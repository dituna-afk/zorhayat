package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// YouTube Music Signature Dark Palette
val YtDarkBackground = Color(0xFF030303)
val YtDarkSurface = Color(0xFF181818)
val YtDarkSurfaceElevated = Color(0xFF212121)
val YtDarkSurfaceVariant = Color(0xFF282828)
val YtDarkBorder = Color(0xFF383838)

val YtRedPrimary = Color(0xFFFF0033)
val YtRedLight = Color(0xFFFF4E64)
val YtRedContainer = Color(0xFF3B000B)

val YtTextPrimary = Color(0xFFFFFFFF)
val YtTextSecondary = Color(0xFFAAAAAA)
val YtTextTertiary = Color(0xFF717171)

// Existing utility colors
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val CyanPrimary = Color(0xFF0284C7)
val CyanPrimaryDark = Color(0xFF38BDF8)
val AmberAccent = Color(0xFFD97706)
val AmberAccentDark = Color(0xFFFBBF24)

val TerminalGreen = Color(0xFF10B981)
val TerminalBg = Color(0xFF0B1120)
val CookieBrown = Color(0xFF92400E)
