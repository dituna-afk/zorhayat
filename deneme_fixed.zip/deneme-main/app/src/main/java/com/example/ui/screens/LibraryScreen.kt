package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserPlaylist
import com.example.downloader.DownloadProgress
import com.example.downloader.MediaTrackInfo
import com.example.downloader.SavedMediaResult
import com.example.ui.theme.LocalAppTheme
import com.example.ui.theme.TerminalGreen
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun LibraryScreen(
    savedTracks: List<SavedMediaResult>,
    userPlaylists: List<UserPlaylist> = emptyList(),
    onlineCandidateTracks: List<MediaTrackInfo> = emptyList(),
    isDownloading: Boolean,
    activeDownloadTitle: String?,
    downloadProgress: DownloadProgress?,
    downloadStatusText: String?,
    pendingQueueCount: Int = 0,
    onTrackSelected: (MediaTrackInfo) -> Unit,
    onAddToQueueNext: (MediaTrackInfo) -> Unit,
    onDeleteTrack: (MediaTrackInfo) -> Unit,
    onOpenPlaylistDetail: (String) -> Unit = {},
    onCreatePlaylist: (
        title: String,
        description: String,
        isAutoCollage: Boolean,
        selectedGalleryUri: Uri?,
        selectedTracks: List<MediaTrackInfo>
    ) -> Unit = { _, _, _, _, _ -> },
    onStartTestDownload: () -> Unit,
    onPauseDownload: () -> Unit,
    onResumeDownload: () -> Unit,
    onCancelDownload: () -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = LocalAppTheme.current
    var showCreatePlaylistSheet by remember { mutableStateOf(false) }

    val downloadedVideoIds by remember(savedTracks) {
        derivedStateOf {
            savedTracks.map { it.trackInfo.videoId }.toSet()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(theme.background)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Başlık
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Kitaplık",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = theme.textPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Morphe Müzik Klasörü • ${savedTracks.size} İndirilen • ${userPlaylists.size} Liste",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary
                        )
                    }
                }
            }

            // 1. Canlı Parçalı İndirici Paneli (Canlı Range S1, S2, S3, S4)
            item {
                ChunkedDownloaderLivePanel(
                    isDownloading = isDownloading,
                    activeDownloadTitle = activeDownloadTitle,
                    downloadProgress = downloadProgress,
                    downloadStatusText = downloadStatusText,
                    pendingQueueCount = pendingQueueCount,
                    onStartTestDownload = onStartTestDownload,
                    onPauseDownload = onPauseDownload,
                    onResumeDownload = onResumeDownload,
                    onCancelDownload = onCancelDownload
                )
            }

            // 2. Oynatma Listeleri Izgarası (2x2 Grid Kartları + Glassmorphic 1.dp Çerçeve)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.QueueMusic,
                            contentDescription = null,
                            tint = theme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Oynatma Listelerim",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = theme.textPrimary
                        )
                    }

                    Text(
                        text = "+ Yeni Liste",
                        style = MaterialTheme.typography.labelMedium,
                        color = theme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showCreatePlaylistSheet = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (userPlaylists.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = theme.surface),
                        shape = RoundedCornerShape(14.dp),
                        border = theme.glassGradientBorder(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCreatePlaylistSheet = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(theme.primary.copy(alpha = 0.16f))
                                    .border(theme.glassGradientBorder(isHighlighted = true), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = theme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "İlk Oynatma Listenizi Oluşturun",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = theme.textPrimary
                                )
                                Text(
                                    text = "Sağ alttaki '+' butonuna dokunarak 2x2 otomatik kolaj veya özel kapaklı liste oluşturun.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = theme.textSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            } else {
                val chunkedPlaylists = userPlaylists.chunked(2)
                items(chunkedPlaylists, key = { pair -> pair.joinToString("_") { it.id } }) { rowPlaylists ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (playlist in rowPlaylists) {
                            val missingCount = playlist.tracks.count { !downloadedVideoIds.contains(it.videoId) }
                            PlaylistGridCard(
                                playlist = playlist,
                                missingCount = missingCount,
                                onClick = { onOpenPlaylistDetail(playlist.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (rowPlaylists.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            // 3. Şarkı Listesi Başlığı ve Jest İpuçları
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "İndirilen Şarkılar",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = theme.textPrimary
                    )
                    Text(
                        text = "👉 Sağa: Sıraya | Sola: Sil 🗑️",
                        style = MaterialTheme.typography.labelSmall,
                        color = theme.textSecondary
                    )
                }
            }

            // 4. İndirilen Şarkılar Listesi (Çift Yönlü Swipeable Satırlar + 1.dp Gradyan Çerçeve)
            if (savedTracks.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = theme.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = theme.glassGradientBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Henüz indirilmiş şarkı yok.\nArama sekmesinden bir YouTube bağlantısı yapıştırarak veya şarkı aratarak 4 parçalı HTTP Range motoruyla indirebilirsiniz.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = theme.textSecondary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(savedTracks, key = { it.trackInfo.videoId }) { saved ->
                    BiDirectionalSwipeableTrackItem(
                        track = saved.trackInfo,
                        audioFileSize = saved.audioFile.length(),
                        onPlay = { onTrackSelected(saved.trackInfo) },
                        onSwipeNext = { onAddToQueueNext(saved.trackInfo) },
                        onSwipeDelete = { onDeleteTrack(saved.trackInfo) }
                    )
                }
            }
        }

        // Sağ Alt '+' Oynatma Listesi Oluşturma FAB Butonu
        FloatingActionButton(
            onClick = { showCreatePlaylistSheet = true },
            containerColor = theme.primary,
            contentColor = Color.White,
            shape = RoundedCornerShape(18.dp),
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 20.dp)
                .border(theme.glassGradientBorder(width = 1.5.dp, isHighlighted = true), RoundedCornerShape(18.dp))
                .testTag("create_playlist_fab")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Oynatma Listesi Oluştur",
                modifier = Modifier.size(28.dp)
            )
        }

        // ModalBottomSheet: Gelişmiş Oynatma Listesi Oluşturucu
        if (showCreatePlaylistSheet) {
            CreatePlaylistBottomSheet(
                savedTracks = savedTracks,
                onlineCandidateTracks = onlineCandidateTracks,
                onDismiss = { showCreatePlaylistSheet = false },
                onCreatePlaylist = { title, desc, isAutoCollage, uri, tracks ->
                    onCreatePlaylist(title, desc, isAutoCollage, uri, tracks)
                    showCreatePlaylistSheet = false
                }
            )
        }
    }
}

/**
 * Kitaplık Izgarasındaki Oynatma Listesi Kartı (1.dp Pembe ve Koyu Gri Gradyan Çerçeveli)
 */
@Composable
private fun PlaylistGridCard(
    playlist: UserPlaylist,
    missingCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = LocalAppTheme.current

    Card(
        colors = CardDefaults.cardColors(containerColor = theme.surface),
        shape = RoundedCornerShape(14.dp),
        border = theme.glassGradientBorder(),
        modifier = modifier
            .clickable { onClick() }
            .testTag("playlist_card_${playlist.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .border(theme.glassGradientBorder(isHighlighted = true), RoundedCornerShape(10.dp))
            ) {
                PlaylistCoverArtwork(
                    isAutoCollage = playlist.isAutoCollage,
                    coverImagePath = playlist.coverImagePath,
                    tracks = playlist.tracks,
                    modifier = Modifier.fillMaxSize()
                )

                if (missingCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(6.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.78f))
                            .border(theme.glassGradientBorder(), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "$missingCount bekliyor",
                            color = Color(0xFFFBBF24),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = playlist.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = theme.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = if (missingCount > 0) {
                    "${playlist.tracks.size} Parça • $missingCount bekliyor"
                } else {
                    "${playlist.tracks.size} Parça • Tümü Hazır"
                },
                style = MaterialTheme.typography.labelSmall,
                color = if (missingCount > 0) Color(0xFFFBBF24) else theme.textSecondary,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Canlı 4 Thread Parçalı İndirici Göstergesi (1.dp Gradyan Çerçeveli)
 */
@Composable
private fun ChunkedDownloaderLivePanel(
    isDownloading: Boolean,
    activeDownloadTitle: String?,
    downloadProgress: DownloadProgress?,
    downloadStatusText: String?,
    pendingQueueCount: Int,
    onStartTestDownload: () -> Unit,
    onPauseDownload: () -> Unit,
    onResumeDownload: () -> Unit,
    onCancelDownload: () -> Unit
) {
    val theme = LocalAppTheme.current

    Card(
        colors = CardDefaults.cardColors(containerColor = theme.surfaceElevated),
        shape = RoundedCornerShape(12.dp),
        border = theme.glassGradientBorder(isHighlighted = isDownloading),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chunked_downloader_status_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isDownloading) TerminalGreen else theme.textSecondary)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (pendingQueueCount > 0) {
                            "CANLI İNDİRİCİ (4 RANGE • $pendingQueueCount SIRADA)"
                        } else {
                            "CANLI PARÇALI İNDİRİCİ (4 RANGE)"
                        },
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                }

                if (isDownloading && downloadProgress != null) {
                    Text(
                        text = "${downloadProgress.speedBytesPerSec / 1024} KB/s",
                        color = theme.primary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isDownloading && downloadProgress != null) {
                Text(
                    text = "İndiriliyor: ${activeDownloadTitle ?: "Medya Dosyası"}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Ana İlerleme Çubuğu
                LinearProgressIndicator(
                    progress = { downloadProgress.progressPercent / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = theme.primary,
                    trackColor = Color.DarkGray
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Kalan Süre (ETA) ve Bayt Hesabı
                val remainingBytes = (downloadProgress.totalBytes - downloadProgress.downloadedBytes).coerceAtLeast(0L)
                val etaSeconds = if (downloadProgress.speedBytesPerSec > 0) remainingBytes / downloadProgress.speedBytesPerSec else 0L

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${downloadProgress.downloadedBytes / 1024} KB / ${downloadProgress.totalBytes / 1024} KB",
                        color = theme.textSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "%${String.format(Locale.US, "%.1f", downloadProgress.progressPercent)} • Kalan: ${etaSeconds}s",
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }

                // 4 Paralel Thread (S1, S2, S3, S4) Detay Çubukları
                if (downloadProgress.chunkProgresses.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        downloadProgress.chunkProgresses.forEach { chunk ->
                            Column(modifier = Modifier.weight(1f)) {
                                LinearProgressIndicator(
                                    progress = { chunk.progressPercent / 100f },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = if (chunk.isDone) TerminalGreen else theme.primary,
                                    trackColor = Color.DarkGray
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "S${chunk.chunkIndex + 1}",
                                        color = theme.textSecondary,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = if (chunk.isDone) "OK" else "%${chunk.progressPercent.toInt()}",
                                        color = if (chunk.isDone) TerminalGreen else Color.White,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(
                        onClick = onPauseDownload,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Pause, contentDescription = "Duraklat", tint = Color.White)
                    }
                    IconButton(
                        onClick = onCancelDownload,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = "İptal", tint = theme.primary)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = downloadStatusText ?: "Hazır • 4 Thread Beklemede",
                        style = MaterialTheme.typography.bodySmall,
                        color = theme.textSecondary,
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = onStartTestDownload,
                        colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                        shape = RoundedCornerShape(20.dp),
                        border = theme.glassGradientBorder(isHighlighted = true),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("4 Range İndir", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

/**
 * Çift yönlü kaydırılabilir şarkı satırı (1.dp Pembe ve Koyu Gri Gradyan Çerçeveli)
 */
@Composable
private fun BiDirectionalSwipeableTrackItem(
    track: MediaTrackInfo,
    audioFileSize: Long,
    onPlay: () -> Unit,
    onSwipeNext: () -> Unit,
    onSwipeDelete: () -> Unit
) {
    val theme = LocalAppTheme.current
    var offsetX by remember { mutableFloatStateOf(0f) }
    val maxSwipe = 140f

    val backgroundColor by animateColorAsState(
        targetValue = when {
            offsetX > 50f -> theme.primary
            offsetX < -50f -> Color(0xFFD32F2F)
            else -> theme.surface
        },
        label = "bidirectional_swipe_color"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(backgroundColor)
    ) {
        if (offsetX < 0) {
            Row(
                modifier = Modifier
                    .matchParentSize()
                    .padding(end = 16.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SİL",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Sil",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        if (offsetX > 0) {
            Row(
                modifier = Modifier
                    .matchParentSize()
                    .padding(start = 16.dp),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.PlaylistPlay,
                    contentDescription = "Sıraya Ekle",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SIRAYA EKLENDİ",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Surface(
            color = theme.surface,
            shape = RoundedCornerShape(10.dp),
            border = theme.glassGradientBorder(),
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), 0) }
                .fillMaxWidth()
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        val newOffset = (offsetX + delta).coerceIn(-maxSwipe, maxSwipe)
                        offsetX = newOffset
                    },
                    onDragStopped = {
                        if (offsetX > 65f) {
                            onSwipeNext()
                        } else if (offsetX < -65f) {
                            onSwipeDelete()
                        }
                        offsetX = 0f
                    }
                )
                .clickable { onPlay() }
                .testTag("track_item_${track.videoId}")
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(theme.surfaceVariant)
                        .border(theme.glassGradientBorder(), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🎵", fontSize = 22.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = theme.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${track.artist} • ${if (audioFileSize > 0) "${audioFileSize / 1024} KB" else "M4A"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = theme.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = onPlay) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Oynat",
                        tint = theme.primary,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}
