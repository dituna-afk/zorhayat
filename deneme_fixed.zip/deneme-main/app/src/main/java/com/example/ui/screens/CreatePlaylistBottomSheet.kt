package com.example.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesomeMosaic
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.downloader.MediaTrackInfo
import com.example.downloader.SavedMediaResult
import com.example.ui.theme.LocalAppTheme
import com.example.ui.theme.TerminalGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

/**
 * Gelişmiş Oynatma Listesi Oluşturucu (ModalBottomSheet):
 * - Liste Başlığı ve İsteğe Bağlı Açıklama alanı
 * - Kapak Seçici (Cover Picker): Galeriden 1:1 kare görsel seçimi veya ilk 4 parçanın
 *   albüm kapağından dinamik 2x2 grid oluşturan Otomatik Kolaj (Canvas çizimi)
 * - Hızlı Şarkı Ekleme: Yerel kütüphanedeki ve çözümlenmiş listedeki şarkıları arama yapılabilen
 *   çoklu seçimli (checkbox) bir picker ile seçme
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePlaylistBottomSheet(
    savedTracks: List<SavedMediaResult>,
    onlineCandidateTracks: List<MediaTrackInfo> = emptyList(),
    onDismiss: () -> Unit,
    onCreatePlaylist: (
        title: String,
        description: String,
        isAutoCollage: Boolean,
        selectedGalleryUri: Uri?,
        selectedTracks: List<MediaTrackInfo>
    ) -> Unit
) {
    val theme = LocalAppTheme.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isAutoCollage by remember { mutableStateOf(true) }
    var selectedGalleryUri by remember { mutableStateOf<Uri?>(null) }
    var pickerSearchQuery by remember { mutableStateOf("") }

    val selectedTrackIds = remember { mutableStateListOf<String>() }

    // Birleştirilmiş aday şarkı listesi (Önce yerel indirilenler, ardından varsa çevrimiçi/bekleyen parçalar)
    val allAvailableTracks by remember(savedTracks, onlineCandidateTracks) {
        derivedStateOf {
            val map = LinkedHashMap<String, MediaTrackInfo>()
            savedTracks.forEach { map[it.trackInfo.videoId] = it.trackInfo }
            onlineCandidateTracks.forEach {
                if (!map.containsKey(it.videoId)) {
                    map[it.videoId] = it
                }
            }
            map.values.toList()
        }
    }

    val downloadedVideoIds by remember(savedTracks) {
        derivedStateOf {
            savedTracks.map { it.trackInfo.videoId }.toSet()
        }
    }

    val filteredTracks by remember(allAvailableTracks, pickerSearchQuery) {
        derivedStateOf {
            val q = pickerSearchQuery.trim()
            if (q.isEmpty()) {
                allAvailableTracks
            } else {
                allAvailableTracks.filter {
                    it.title.contains(q, ignoreCase = true) ||
                            it.artist.contains(q, ignoreCase = true)
                }
            }
        }
    }

    val selectedTracksPreview by remember(allAvailableTracks, selectedTrackIds.size) {
        derivedStateOf {
            val idSet = selectedTrackIds.toSet()
            allAvailableTracks.filter { idSet.contains(it.videoId) }
        }
    }

    // Android Photo Picker (1:1 Kare Kapak Seçimi için)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedGalleryUri = uri
            isAutoCollage = false
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = theme.surface,
        scrimColor = Color.Black.copy(alpha = 0.72f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = Modifier.testTag("create_playlist_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            // Başlık Satırı
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LibraryAdd,
                        contentDescription = null,
                        tint = theme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Yeni Oynatma Listesi",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = theme.textPrimary
                        )
                        Text(
                            text = "OfflineStorage / Room Veritabanı Senkronizasyonu",
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Kapat",
                        tint = theme.textSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 1. Kapak Seçici (Cover Picker) & Canlı 1:1 Önizleme
            Surface(
                color = theme.surfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = theme.glassGradientBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1:1 Kare Kapak Önizlemesi (Otomatik 2x2 Kolaj veya Galeriden Seçilen Görsel)
                    Box(
                        modifier = Modifier
                            .size(84.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(theme.glassGradientBorder(isHighlighted = true), RoundedCornerShape(10.dp))
                            .clickable {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                    ) {
                        PlaylistCoverArtwork(
                            isAutoCollage = isAutoCollage,
                            coverImagePath = null,
                            previewUri = selectedGalleryUri,
                            tracks = selectedTracksPreview.ifEmpty { allAvailableTracks.take(4) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "KAPAK TASARIMI (1:1 KARE)",
                            style = MaterialTheme.typography.labelSmall,
                            color = theme.primary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = isAutoCollage,
                                onClick = { isAutoCollage = true },
                                label = { Text("Otomatik Kolaj", fontSize = 11.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesomeMosaic,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = theme.primary,
                                    selectedLabelColor = Color.White,
                                    selectedLeadingIconColor = Color.White,
                                    containerColor = theme.surface,
                                    labelColor = theme.textPrimary
                                ),
                                modifier = Modifier.testTag("cover_mode_collage")
                            )

                            FilterChip(
                                selected = !isAutoCollage,
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                label = { Text("Galeriden Seç", fontSize = 11.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.AddPhotoAlternate,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = theme.primary,
                                    selectedLabelColor = Color.White,
                                    selectedLeadingIconColor = Color.White,
                                    containerColor = theme.surface,
                                    labelColor = theme.textPrimary
                                ),
                                modifier = Modifier.testTag("cover_mode_gallery")
                            )
                        }

                        Text(
                            text = if (isAutoCollage) {
                                "İlk 4 parçanın albüm kapağından 2x2 dinamik Canvas kolajı üretilir."
                            } else {
                                "Galeriden seçilen görsel 1:1 kare olarak kırpılıp kaydedilir."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Liste Başlığı ve İsteğe Bağlı Açıklama
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Liste Başlığı *") },
                placeholder = { Text("Örn: Gece Sürüşü Synthwave", fontSize = 13.sp) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = theme.surfaceElevated,
                    unfocusedContainerColor = theme.surfaceElevated,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = theme.primary,
                    unfocusedIndicatorColor = theme.border,
                    focusedLabelColor = theme.primary,
                    unfocusedLabelColor = theme.textSecondary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("playlist_title_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Açıklama (İsteğe Bağlı)") },
                placeholder = { Text("Liste hakkında kısa bir not ekleyin...", fontSize = 13.sp) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = theme.surfaceElevated,
                    unfocusedContainerColor = theme.surfaceElevated,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = theme.primary,
                    unfocusedIndicatorColor = theme.border,
                    focusedLabelColor = theme.primary,
                    unfocusedLabelColor = theme.textSecondary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("playlist_desc_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Hızlı Şarkı Ekleme Başlığı + Çoklu SeçimKontrolleri
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HIZLI ŞARKI EKLE (${selectedTrackIds.size} Seçildi)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = theme.textPrimary,
                    letterSpacing = 0.8.sp
                )

                TextButton(
                    onClick = {
                        if (selectedTrackIds.size == filteredTracks.size && filteredTracks.isNotEmpty()) {
                            selectedTrackIds.clear()
                        } else {
                            filteredTracks.forEach { t ->
                                if (!selectedTrackIds.contains(t.videoId)) {
                                    selectedTrackIds.add(t.videoId)
                                }
                            }
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DoneAll,
                        contentDescription = null,
                        tint = theme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (selectedTrackIds.size == filteredTracks.size && filteredTracks.isNotEmpty()) {
                            "Seçimi Temizle"
                        } else {
                            "Tümünü Seç"
                        },
                        color = theme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Arama Kutusu (Şarkı filtreleme)
            OutlinedTextField(
                value = pickerSearchQuery,
                onValueChange = { pickerSearchQuery = it },
                placeholder = { Text("Yerel kütüphanede şarkı veya sanatçı ara...", fontSize = 12.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = theme.textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (pickerSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { pickerSearchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Temizle",
                                tint = theme.textSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = theme.surfaceElevated,
                    unfocusedContainerColor = theme.surfaceElevated,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = theme.primary,
                    unfocusedIndicatorColor = theme.border
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("playlist_song_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Çoklu Seçimli (Checkbox) Şarkı Listesi
            Surface(
                color = theme.background.copy(alpha = 0.65f),
                shape = RoundedCornerShape(12.dp),
                border = theme.glassGradientBorder(),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 130.dp, max = 210.dp)
            ) {
                if (filteredTracks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (allAvailableTracks.isEmpty()) {
                                "Kütüphanede henüz şarkı yok. Listeyi şimdi oluşturup daha sonra Arama sekmesinden şarkı ekleyebilirsiniz."
                            } else {
                                "\"$pickerSearchQuery\" ile eşleşen parça bulunamadı."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = theme.textSecondary
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(vertical = 6.dp, horizontal = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filteredTracks, key = { it.videoId }) { track ->
                            val isChecked = selectedTrackIds.contains(track.videoId)
                            val isDownloaded = downloadedVideoIds.contains(track.videoId)

                            Surface(
                                color = if (isChecked) theme.primary.copy(alpha = 0.14f) else theme.surfaceElevated.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isChecked) {
                                            selectedTrackIds.remove(track.videoId)
                                        } else {
                                            selectedTrackIds.add(track.videoId)
                                        }
                                    }
                                    .testTag("picker_track_${track.videoId}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            if (checked) {
                                                if (!selectedTrackIds.contains(track.videoId)) {
                                                    selectedTrackIds.add(track.videoId)
                                                }
                                            } else {
                                                selectedTrackIds.remove(track.videoId)
                                            }
                                        },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = theme.primary,
                                            uncheckedColor = theme.textSecondary,
                                            checkmarkColor = Color.White
                                        )
                                    )

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = track.title,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = theme.textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = track.artist,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = theme.textSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    // İndirildi / Bekliyor rozeti
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                if (isDownloaded) TerminalGreen.copy(alpha = 0.18f)
                                                else Color(0xFFF59E0B).copy(alpha = 0.2f)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (isDownloaded) Icons.Default.Check else Icons.Default.CloudQueue,
                                                contentDescription = null,
                                                tint = if (isDownloaded) TerminalGreen else Color(0xFFFBBF24),
                                                modifier = Modifier.size(11.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = if (isDownloaded) "İndirildi" else "Bekliyor",
                                                color = if (isDownloaded) TerminalGreen else Color(0xFFFBBF24),
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Oluştur Butonu (Tema Vurgulu Parlama & Glassmorphic Çerçeve)
            Button(
                onClick = {
                    val finalTitle = title.trim().ifEmpty { "Oynatma Listem #${(100..999).random()}" }
                    onCreatePlaylist(
                        finalTitle,
                        description.trim(),
                        isAutoCollage,
                        selectedGalleryUri,
                        selectedTracksPreview
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                shape = RoundedCornerShape(24.dp),
                border = theme.glassGradientBorder(isHighlighted = true),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("confirm_create_playlist_button")
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Oynatma Listesini Oluştur (${selectedTrackIds.size} Parça)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

/**
 * Oynatma Listesi Kapak Görseli:
 * - Eğer galeriden özel bir görsel seçilmişse onu 1:1 kare olarak gösterir.
 * - Eğer 'Otomatik Kolaj' aktifse ilk 4 parçanın albüm kapağından (veya kapak renklerinden)
 *   Canvas üzerinde dinamik 2x2 grid kolajı çizer.
 */
@Composable
fun PlaylistCoverArtwork(
    isAutoCollage: Boolean,
    coverImagePath: String?,
    previewUri: Uri? = null,
    tracks: List<MediaTrackInfo>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val theme = LocalAppTheme.current

    var customBitmap by remember(coverImagePath, previewUri) { mutableStateOf<ImageBitmap?>(null) }
    val quadrantBitmaps = remember { mutableStateListOf<ImageBitmap?>(null, null, null, null) }

    LaunchedEffect(isAutoCollage, coverImagePath, previewUri, tracks) {
        withContext(Dispatchers.IO) {
            if (!isAutoCollage) {
                val bmp = when {
                    previewUri != null -> {
                        try {
                            context.contentResolver.openInputStream(previewUri)?.use {
                                BitmapFactory.decodeStream(it)?.asImageBitmap()
                            }
                        } catch (_: Exception) {
                            null
                        }
                    }
                    !coverImagePath.isNullOrBlank() && File(coverImagePath).exists() -> {
                        BitmapFactory.decodeFile(coverImagePath)?.asImageBitmap()
                    }
                    else -> null
                }
                customBitmap = bmp
            } else {
                val targetDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Morphe")
                val loaded = Array<ImageBitmap?>(4) { null }
                for (i in 0 until minOf(4, tracks.size)) {
                    val cleanId = tracks[i].videoId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                    val coverFile = File(targetDir, "$cleanId.jpg")
                    if (coverFile.exists()) {
                        try {
                            loaded[i] = BitmapFactory.decodeFile(coverFile.absolutePath)?.asImageBitmap()
                        } catch (_: Exception) {
                        }
                    }
                }
                withContext(Dispatchers.Main) {
                    for (i in 0 until 4) {
                        quadrantBitmaps[i] = loaded[i]
                    }
                }
            }
        }
    }

    if (!isAutoCollage && customBitmap != null) {
        Image(
            bitmap = customBitmap!!,
            contentDescription = "Oynatma Listesi Kapağı",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        // Dinamik 2x2 Grid Kolaj Canvas Çizimi
        val palettePairs = remember(theme) {
            listOf(
                Pair(theme.primary, theme.primaryContainer),
                Pair(Color(0xFFFF2D75), Color(0xFF360F18)),
                Pair(Color(0xFFA855F7), Color(0xFF2B1242)),
                Pair(Color(0xFF0EA5E9), Color(0xFF0F2942))
            )
        }

        Canvas(modifier = modifier) {
            val halfW = size.width / 2f
            val halfH = size.height / 2f

            for (index in 0 until 4) {
                val col = index % 2
                val row = index / 2
                val left = col * halfW
                val top = row * halfH
                val quadCenter = Offset(left + halfW / 2f, top + halfH / 2f)

                val bmp = quadrantBitmaps.getOrNull(index)
                if (bmp != null) {
                    drawImage(
                        image = bmp,
                        dstOffset = IntOffset(left.toInt(), top.toInt()),
                        dstSize = IntSize(halfW.toInt(), halfH.toInt())
                    )
                } else {
                    val track = tracks.getOrNull(index)
                    val hashSeed = if (track != null) abs(track.videoId.hashCode()) else index
                    val pair = palettePairs[(hashSeed + index) % palettePairs.size]

                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(pair.first.copy(alpha = 0.88f), pair.second),
                            start = Offset(left, top),
                            end = Offset(left + halfW, top + halfH)
                        ),
                        topLeft = Offset(left, top),
                        size = Size(halfW, halfH)
                    )

                    // Plak/Vinil dairesel dokusu
                    val discRadius = minOf(halfW, halfH) * 0.34f
                    drawCircle(
                        color = Color.Black.copy(alpha = 0.28f),
                        radius = discRadius,
                        center = quadCenter
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.22f),
                        radius = discRadius,
                        center = quadCenter,
                        style = Stroke(width = 1.5f)
                    )
                    drawCircle(
                        color = pair.first,
                        radius = discRadius * 0.28f,
                        center = quadCenter
                    )
                }
            }

            // 2x2 Grid Ayırıcı Çizgileri
            val dividerColor = Color.Black.copy(alpha = 0.45f)
            drawLine(
                color = dividerColor,
                start = Offset(halfW, 0f),
                end = Offset(halfW, size.height),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = dividerColor,
                start = Offset(0f, halfH),
                end = Offset(size.width, halfH),
                strokeWidth = 2.dp.toPx()
            )
        }
    }
}
