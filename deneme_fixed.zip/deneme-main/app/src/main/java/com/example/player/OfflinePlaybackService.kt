package com.example.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity

/**
 * Android 14+ uyumlu Foreground Service Media Playback servisi.
 * Çevrimdışı müziklerin bildirim çubuğunda ve kilit ekranında canlı kontrollerle çalmasını sağlar.
 * Kulaklık bağlantısı koptuğunda (ACTION_AUDIO_BECOMING_NOISY) müziği otomatik duraklatır.
 */
class OfflinePlaybackService : Service() {

    companion object {
        const val CHANNEL_ID = "morphe_offline_playback_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_PLAY = "com.example.morphe.ACTION_PLAY"
        const val ACTION_PAUSE = "com.example.morphe.ACTION_PAUSE"
        const val ACTION_NEXT = "com.example.morphe.ACTION_NEXT"
        const val ACTION_PREV = "com.example.morphe.ACTION_PREV"
        const val ACTION_STOP = "com.example.morphe.ACTION_STOP"

        fun startService(context: Context) {
            val intent = Intent(context, OfflinePlaybackService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    // Kulaklık/Bluetooth koptuğunda otomatik duraklatma alıcısı
    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                val player = LocalDownloadsPlayer.getInstance(this@OfflinePlaybackService)
                player.pause()
                updateNotification()
            }
        }
    }

    private var isReceiverRegistered = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        registerNoisyReceiver()
    }

    private fun registerNoisyReceiver() {
        if (!isReceiverRegistered) {
            val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            registerReceiver(noisyReceiver, filter)
            isReceiverRegistered = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val player = LocalDownloadsPlayer.getInstance(this)

        when (intent?.action) {
            ACTION_PLAY -> player.resume()
            ACTION_PAUSE -> player.pause()
            ACTION_NEXT -> player.playNext()
            ACTION_PREV -> player.playPrevious()
            ACTION_STOP -> {
                player.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }

        updateNotification()
        return START_STICKY
    }

    private fun updateNotification() {
        val player = LocalDownloadsPlayer.getInstance(this)
        val trackTitle = player.playerState.value.currentTrack?.title ?: "Morphe Oynatıcı"
        val artist = player.playerState.value.currentTrack?.artist ?: "Çevrimdışı Müzik"
        val isPlaying = player.playerState.value.isPlaying

        val notification = buildNotification(trackTitle, artist, isPlaying)
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(title: String, artist: String, isPlaying: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpenApp = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Bildirim eylem butonları (Önceki, Oynat/Duraklat, Sonraki)
        val prevPending = createActionPendingIntent(ACTION_PREV, 1)
        val playPausePending = createActionPendingIntent(if (isPlaying) ACTION_PAUSE else ACTION_PLAY, 2)
        val nextPending = createActionPendingIntent(ACTION_NEXT, 3)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(artist)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pendingOpenApp)
            .addAction(android.R.drawable.ic_media_previous, "Önceki", prevPending)
            .addAction(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying) "Duraklat" else "Oynat",
                playPausePending
            )
            .addAction(android.R.drawable.ic_media_next, "Sonraki", nextPending)
            .setOngoing(isPlaying)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun createActionPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, OfflinePlaybackService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Morphe Çevrimdışı Oynatıcı",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Arka planda müzik oynatma ve kilit ekranı kontrolleri"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isReceiverRegistered) {
            try {
                unregisterReceiver(noisyReceiver)
            } catch (e: Exception) {
                // Ignore
            }
            isReceiverRegistered = false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
