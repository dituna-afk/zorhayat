package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.YtMusicMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.CookieViewModel
import com.example.viewmodel.MusicPlayerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val musicViewModel: MusicPlayerViewModel = viewModel()
            val cookieViewModel: CookieViewModel = viewModel()
            val musicUiState by musicViewModel.uiState.collectAsStateWithLifecycle()

            MyApplicationTheme(theme = musicUiState.currentTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    YtMusicMainScreen(
                        musicViewModel = musicViewModel,
                        cookieViewModel = cookieViewModel
                    )
                }
            }
        }
    }
}
