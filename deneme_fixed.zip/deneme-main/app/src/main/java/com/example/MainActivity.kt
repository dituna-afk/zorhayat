package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.rememberViewModel
import com.example.ui.player.MiniPlayerBar
import com.example.ui.screens.PlaylistsScreen
import com.example.viewmodel.MusicPlayerViewModel
import com.example.ui.theme.AppTheme
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Use Sakura theme by default
            MyApplicationTheme(theme = AppTheme.SAKURA_SAKURA) {
                // Edge to edge desteğini etkinleştir
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // ViewModel initialization
                    val viewModel: MusicPlayerViewModel = rememberViewModel()
                    
                    // UI State collector
                    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                    
                    // Main Scaffold
                    Scaffold(
                        topBar = {
                            // Minimalist top bar
                            TopAppBar(
                                title = { Text("Sakura Music", color = Color.White) },
                                navigationIcon = {
                                    IconButton(onClick = { }) {
                                        Icon(
                                            imageVector = Icons.Filled.Menu,
                                            contentDescription = null,
                                            tint = Color.White
                                        )
                                    }
                                },
                                containerColor = Color.Transparent,
                                elevation = 0.dp
                            )
                        },
                        bottomBar = {
                            // Mini player bar - her zaman görünür
                            MiniPlayerBar()
                        }
                    ) { padding ->
                        // Ana içerik - PlaylistsScreen
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(padding)
                                .background(AppTheme.SAKURA_SAKURA.background)
                        ) {
                            PlaylistsScreen(
                                onPlaylistSelected = { playlist ->
                                    Log.d("MainActivity", "Playlist selected: ${playlist.title}")
                                },
                                onTrackSelected = { track ->
                                    Log.d("MainActivity", "Track selected: ${track.title}")
                                }
                            )
                        }
                    }
                }
            )
        }
    }
}
