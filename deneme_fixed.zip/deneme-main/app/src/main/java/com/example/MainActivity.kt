package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.clickable
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.rememberViewModel
import com.example.ui.player.MiniPlayerBar
import com.example.ui.screens.PlaylistsScreen
import com.example.viewmodel.MusicPlayerViewModel
import com.example.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Use Sakura theme by default
            MyApplicationTheme(theme = AppTheme.SAKURA_SAKURA) {
                // Edge to edge desteğini etkinleştir
                EdgeToEdgeBox(
                    modifier = Modifier
                        .fillMaxSize()
                        .onRootSystemBars {
                            // System bar renklerini ayarla
                        }
                ) {
                    // ViewModel initialization
                    val viewModel: MusicPlayerViewModel = rememberViewModel()
                    
                    // UI State collector
                    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                    
                    // Main Scaffold
                    Scaffold(
                        topBar = {
                            // Minimalist top bar
                            TopAppBar(
                                title = { Text("Sakura Music") },
                                navigationIcon = {
                                    IconButton(onClick = { }) {
                                        Icon(
                                            imageVector = Icons.Filled.Menu,
                                            contentDescription = null,
                                            tint = Color(0xFFFFFFFF)
                                        )
                                    }
                                },
                                backgroundColor = Color.Transparent,
                                elevation = 0.dp
                            )
                        },
                        bottomBar = {
                            // Mini player bar - her zaman görünür
                            MiniPlayerBar()
                        }
                    ) { padding ->
                        // Ana içerik - PlaylistsScreen
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(padding)
                                .background(
                                    AppTheme.SAKURA_SAKURA.background
                                )
                        ) {
                            PlaylistsScreen(
                                onPlaylistSelected = { playlist ->
                                    // Playlist seçildi - detail screen'e geçiş
                                    Log.d("MainActivity", "Playlist selected: ${playlist.title}")
                                },
                                onTrackSelected = { track ->
                                    // Şarkı seçildi - oynatma başlat
                                    Log.d("MainActivity", "Track selected: ${track.title}")
                                }
                            )
                        }
                    }
                }
            )
        }
    }
}
