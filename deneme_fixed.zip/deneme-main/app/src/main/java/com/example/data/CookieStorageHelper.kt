package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Cookie değerlerini uygulama kapansa bile güvenli ve kalıcı bir şekilde
 * saklamak için EncryptedSharedPreferences (ve gerekirse standart SharedPreferences)
 * kullanan yardımcı sınıf (Helper / Repository).
 */
class CookieStorageHelper(context: Context) {

    private val sharedPreferences: SharedPreferences
    val isEncrypted: Boolean

    companion object {
        private const val TAG = "CookieStorageHelper"
        private const val ENCRYPTED_PREFS_NAME = "secure_cookies_prefs"
        private const val STANDARD_PREFS_NAME = "standard_cookies_prefs"
        
        // Anahtarlar
        private const val KEY_LATEST_COOKIE = "pref_latest_cookie_string"
        private const val KEY_LATEST_URL = "pref_latest_url"
        private const val KEY_PREFIX_URL = "cookie_url_"
        private const val KEY_TIMESTAMP = "pref_last_saved_timestamp"

        @Volatile
        private var instance: CookieStorageHelper? = null

        fun getInstance(context: Context): CookieStorageHelper {
            return instance ?: synchronized(this) {
                instance ?: CookieStorageHelper(context.applicationContext).also { instance = it }
            }
        }
    }

    init {
        var prefs: SharedPreferences? = null
        var encrypted = false

        try {
            // AndroidX Security MasterKey oluştur (AES256-GCM)
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            // EncryptedSharedPreferences başlat
            prefs = EncryptedSharedPreferences.create(
                context,
                ENCRYPTED_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            encrypted = true
            Log.d(TAG, "EncryptedSharedPreferences başarıyla başlatıldı (Şifreli Depolama Aktif).")
        } catch (e: Exception) {
            Log.w(TAG, "EncryptedSharedPreferences oluşturulamadı (${e.message}), Standart SharedPreferences'a geçiliyor.", e)
            prefs = context.getSharedPreferences(STANDARD_PREFS_NAME, Context.MODE_PRIVATE)
            encrypted = false
        }

        sharedPreferences = prefs
        isEncrypted = encrypted
    }

    @Volatile
    private var cachedLatestCookies: String? = null

    /**
     * Belirtilen URL'ye ait cookie string değerini ve en son kaydedilen cookie bilgisini depolar.
     * Örnek: saveCookies("https://music.youtube.com", "SAPISID=...; __Secure-3PAPISID=...; LOGIN_INFO=...")
     */
    fun saveCookies(url: String, cookieString: String) {
        if (cookieString.isBlank()) return
        val cleanUrl = sanitizeUrlKey(url)
        val timestamp = System.currentTimeMillis()
        cachedLatestCookies = cookieString

        sharedPreferences.edit()
            .putString(KEY_PREFIX_URL + cleanUrl, cookieString)
            .putString(KEY_LATEST_COOKIE, cookieString)
            .putString(KEY_LATEST_URL, url)
            .putLong(KEY_TIMESTAMP, timestamp)
            .commit()

        Log.d(TAG, "Çerez kaydedildi [$url] (Şifreli: $isEncrypted): ${cookieString.take(120)}...")
    }

    /**
     * Belirli bir URL için kaydedilmiş cookie string değerini okur.
     */
    fun getCookies(url: String): String? {
        val cleanUrl = sanitizeUrlKey(url)
        return sharedPreferences.getString(KEY_PREFIX_URL + cleanUrl, null)
    }

    /**
     * Uygulama açılışında en son kaydedilmiş genel cookie string değerini getirir.
     */
    fun getLatestCookies(): String? {
        return cachedLatestCookies ?: sharedPreferences.getString(KEY_LATEST_COOKIE, null)
    }

    /**
     * YouTube Music ve YouTube alan adları için EncryptedSharedPreferences ve WebView CookieManager
     * üzerindeki tüm oturum çerezlerini (SAPISID, __Secure-3PAPISID, LOGIN_INFO) eksiksiz birleştirerek döner.
     */
    fun getYouTubeMusicCookies(): String? {
        val storedMusic = getCookies("https://music.youtube.com")
        val storedLatest = getLatestCookies()

        val liveMusicCookies = try {
            android.webkit.CookieManager.getInstance().getCookie("https://music.youtube.com")
        } catch (_: Exception) {
            null
        }
        val liveYoutubeCookies = try {
            android.webkit.CookieManager.getInstance().getCookie("https://www.youtube.com")
        } catch (_: Exception) {
            null
        }

        return mergeCookieStrings(storedMusic, storedLatest, liveMusicCookies, liveYoutubeCookies)
    }

    /**
     * Birden fazla çerez dizesini (EncryptedSharedPreferences + WebView CookieManager)
     * anahtar bazında birleştirerek SAPISID, __Secure-3PAPISID ve LOGIN_INFO kaybını önler.
     */
    fun mergeCookieStrings(vararg cookieStrings: String?): String? {
        val cookieMap = LinkedHashMap<String, String>()
        for (raw in cookieStrings) {
            if (raw.isNullOrBlank()) continue
            val pairs = raw.split(";")
            for (pair in pairs) {
                val trimmed = pair.trim()
                val eqIdx = trimmed.indexOf('=')
                if (eqIdx > 0) {
                    val key = trimmed.substring(0, eqIdx).trim()
                    val value = trimmed.substring(eqIdx + 1).trim()
                    if (key.isNotEmpty() && value.isNotEmpty()) {
                        cookieMap[key] = value
                    }
                }
            }
        }
        if (cookieMap.isEmpty()) return null
        return cookieMap.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    /**
     * En son kaydedilen web sitesi URL'sini getirir.
     */
    fun getLatestUrl(): String? {
        return sharedPreferences.getString(KEY_LATEST_URL, null)
    }

    /**
     * Son kayıt zaman damgasını getirir.
     */
    fun getLastSavedTimestamp(): Long {
        return sharedPreferences.getLong(KEY_TIMESTAMP, 0L)
    }

    /**
     * Kaydedilmiş tüm URL ve çerez çiftlerini harita olarak döner.
     */
    fun getAllSavedCookies(): Map<String, String> {
        val allEntries = sharedPreferences.all
        val result = mutableMapOf<String, String>()
        for ((key, value) in allEntries) {
            if (key.startsWith(KEY_PREFIX_URL) && value is String) {
                val originalUrlKey = key.removePrefix(KEY_PREFIX_URL)
                result[originalUrlKey] = value
            }
        }
        return result
    }

    /**
     * Belirli bir URL için çerezi siler.
     */
    fun removeCookies(url: String) {
        val cleanUrl = sanitizeUrlKey(url)
        sharedPreferences.edit()
            .remove(KEY_PREFIX_URL + cleanUrl)
            .commit()
        Log.d(TAG, "Çerez silindi: $url")
    }

    /**
     * Saklanan tüm çerezleri temizler.
     */
    fun clearAll() {
        cachedLatestCookies = null
        sharedPreferences.edit().clear().commit()
        Log.d(TAG, "Tüm kayıtlı çerezler preferences'tan silindi.")
    }

    private fun sanitizeUrlKey(url: String): String {
        return url.replace("https://", "")
            .replace("http://", "")
            .replace("/", "_")
            .replace(":", "_")
    }
}
