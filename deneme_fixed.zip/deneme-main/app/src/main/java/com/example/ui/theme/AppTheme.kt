package com.example.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Uygulamanın desteklediği 4 farklı lüks ve şık karanlık tema paleti.
 */
@Immutable
enum class AppTheme(
    val id: String,
    val title: String,
    val subtitle: String,
    val background: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val surfaceVariant: Color,
    val border: Color,
    val primary: Color,
    val primaryContainer: Color,
    val textPrimary: Color = Color.White,
    val textSecondary: Color,
    val haloPrimary: Color,
    val haloSecondary: Color
) {
    // 1. Saf OLED Siyah (Varsayılan YouTube Music)
    OLED_BLACK(
        id = "oled_black",
        title = "Saf OLED Siyah",
        subtitle = "Klasik YouTube Music & Neon Kırmızı",
        background = Color(0xFF030303),
        surface = Color(0xFF161616),
        surfaceElevated = Color(0xFF222222),
        surfaceVariant = Color(0xFF2A2A2A),
        border = Color(0xFF333333),
        primary = Color(0xFFFF0033),
        primaryContainer = Color(0xFF3B000B),
        textSecondary = Color(0xFFAAAAAA),
        haloPrimary = Color(0xFFFF0033),
        haloSecondary = Color(0xFF8B0000)
    ),

    // 2. Koyu Pembe / Kiraz Rengi (Deep Cherry / Dark Crimson)
    DEEP_CHERRY(
        id = "deep_cherry",
        title = "Koyu Pembe / Kiraz",
        subtitle = "Deep Crimson & Neon Fuşya Pembe",
        background = Color(0xFF140508),
        surface = Color(0xFF240A10),
        surfaceElevated = Color(0xFF360F18),
        surfaceVariant = Color(0xFF471520),
        border = Color(0xFF5A1A28),
        primary = Color(0xFFFF2D75),
        primaryContainer = Color(0xFF520F24),
        textSecondary = Color(0xFFD4A5B2),
        haloPrimary = Color(0xFFFF2D75),
        haloSecondary = Color(0xFF8B0032)
    ),

    // 3. Sakura Çiçeği Teması (Sakura Blossom)
    SAKURA_SAKURA(
        id = "sakura_sakura",
        title = "Sakura Çiçeği",
        subtitle = "Sakura çiçeği, sakura ağacı, çiçek animasyonları",
        background = Color(0xFF1F0F12),  // Koyu sakura rengi
        surface = Color(0xFF2F1F20),    // Koyu taş rengi
        surfaceElevated = Color(0xFF3F2F30),
        surfaceVariant = Color(0xFF4F3F41),
        border = Color(0xFF5F4F52),
        primary = Color(0xFFFF5A87),     // Canlı sakura çiçeği rengi
        primaryContainer = Color(0xFF6B3A47),
        textSecondary = Color(0xFFE0D0E0), // Açık krem
        haloPrimary = Color(0xFFFF5A87),
        haloSecondary = Color(0xFFFF8AA5)
    ),

    // 4. Gece Moru (Ametist / Midnight Plum)
    MIDNIGHT_PLUM(
        id = "midnight_plum",
        title = "Gece Moru / Ametist",
        subtitle = "Midnight Plum & Ametist Moru",
        background = Color(0xFF0D0514),
        surface = Color(0xFF1B0B2A),
        surfaceElevated = Color(0xFF2B1242),
        surfaceVariant = Color(0xFF3D195C),
        border = Color(0xFF4C1F73),
        primary = Color(0xFFA855F7),
        primaryContainer = Color(0xFF4C1D95),
        textSecondary = Color(0xFFC0A6DC),
        haloPrimary = Color(0xFFA855F7),
        haloSecondary = Color(0xFF581C87)
    );

    /**
     * Kitaplık kartları ve ayar butonları için %15 alfa pembe, tema vurgu rengi ve koyu gri
     * geçişli 1.dp ince gradyan çerçeve (Glassmorphism Border).
     */
    fun glassGradientBorder(width: Dp = 1.dp, isHighlighted: Boolean = false): BorderStroke {
        val pinkTint = Color(0xFFFF2D75).copy(alpha = if (isHighlighted) 0.35f else 0.15f)
        val themeAccent = primary.copy(alpha = if (isHighlighted) 0.45f else 0.22f)
        val darkGray = Color(0xFF2A2A2A).copy(alpha = 0.55f)
        return BorderStroke(
            width = width,
            brush = Brush.linearGradient(
                colors = listOf(themeAccent, pinkTint, darkGray)
            )
        )
    }

    /**
     * Butonlar ve seçili yüzeyler için tema vurgulu parlama fırçası.
     */
    fun accentGlowBrush(): Brush {
        return Brush.horizontalGradient(
            colors = listOf(
                primary,
                haloPrimary.copy(alpha = 0.85f),
                Color(0xFFFF2D75).copy(alpha = 0.80f)
            )
        )
    }

    companion object {
        fun fromId(id: String?): AppTheme {
            return entries.firstOrNull { it.id == id } ?: SAKURA_SAKURA
    }

    // Sakura sakura teması için özel animasyon ve görsel yardımcı fonksiyonlar
    fun sakuraAnimationBrush(): Brush {
        return Brush.horizontalGradient(
            colors = listOf(
                primary.copy(alpha = 0.9f),
                haloPrimary.copy(alpha = 0.7f),
                primary.copy(alpha = 0.8f),
                haloSecondary.copy(alpha = 0.6f),
                primary.copy(alpha = 0.9f)
            )
        )
    }

    fun sakuraBorder(width: Dp = 2.dp, isBlooming: Boolean = false): BorderStroke {
        val cherryRed = Color(0xFFFF4E73).copy(alpha = if (isBlooming) 0.8f else 0.25f)
        val pinkAccent = Color(0xFFFF8AA5).copy(alpha = if (isBlooming) 0.6f else 0.15f)
        val lightPetal = Color(0xFFFFE0E5).copy(alpha = if (isBlooming) 0.4f else 0.1f)
        return BorderStroke(
            width = width,
            brush = Brush.linearGradient(
                colors = listOf(lightPetal, pinkAccent, cherryRed)
            )
        )
    }

    fun sakuraGlowBrush(): Brush {
        return Brush.radialGradient(
            colors = listOf(
                primary.copy(alpha = 0.95f),
                haloPrimary.copy(alpha = 0.7f),
                primary.copy(alpha = 0.5f)
            ),
            center = Offset(
                x = 0.5f,
                y = 0.5f
            )
        )
    }
}
}
