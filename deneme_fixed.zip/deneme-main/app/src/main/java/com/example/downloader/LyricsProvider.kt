package com.example.downloader

import android.util.Log
import com.example.model.LrcParser
import com.example.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charsets

/**
 * LRCLIB açık API'si ve yerel önbellek üzerinden senkronize şarkı sözü (LRC) sağlayan servis.
 */
object LyricsProvider {

    private const val TAG = "LyricsProvider"
    private const val LRCLIB_API_URL = "https://lrclib.net/api/get"
    private const val TIMEOUT_MS = 8000

    private val memoryCache = mutableMapOf<String, List<LyricLine>>()

    /**
     * Şarkı için senkronize edilmiş LRC sözlerini çeker.
     * Önce LRCLIB API'sinden çeker, başarısız olursa YouTube Music'ten, hala başarısız olursa şarkıya özel fallback sözlerini üretir.
     */
    suspend fun getSyncedLyrics(
        trackTitle: String,
        artistName: String,
        durationSeconds: Long = 0L,
        videoId: String? = null
    ): List<LyricLine> = withContext(Dispatchers.IO) {
        val cacheKey = "${trackTitle.trim().lowercase()}_${artistName.trim().lowercase()}"
        memoryCache[cacheKey]?.let { return@withContext it }

        var fetchedLyrics: List<LyricLine>? = null

        try {
            val encodedTrack = URLEncoder.encode(trackTitle, "UTF-8")
            val encodedArtist = URLEncoder.encode(artistName, "UTF-8")
            var query = "$LRCLIB_API_URL?track_name=$encodedTrack&artist_name=$encodedArtist"
            if (durationSeconds > 0) {
                query += "&duration=$durationSeconds"
            }

            val connection = (URL(query).openConnection() as HttpURLConnection).apply {
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MorpheMusic/1.0 (Android; OpenLyrics)")
            }

            connection.connect()
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val jsonText = connection.inputStream.bufferedReader().use { it.readText() }
                val jsonObj = JSONObject(jsonText)
                val syncedLrc = jsonObj.optString("syncedLyrics", null)

                if (!syncedLrc.isNullOrBlank()) {
                    val parsed = LrcParser.parse(syncedLrc)
                    if (parsed.isNotEmpty()) {
                        Log.d(TAG, "LRCLIB API'den ${parsed.size} satır senkronize söz başarıyla alındı.")
                        fetchedLyrics = parsed
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "LRCLIB API çağrısı başarısız (${e.message}), YouTube Music'ten deneniyor.")
        }

        // Eğer LRCLIB ile bulunamadıysa YouTube Music'ten dener
        if (fetchedLyrics == null && videoId != null) {
            try {
                fetchedLyrics = fetchYouTubeMusicLyrics(videoId)
                if (fetchedLyrics != null && fetchedLyrics.isNotEmpty()) {
                    Log.d(TAG, "YouTube Music'ten ${fetchedLyrics.size} satır senkronize söz alındı.")
                }
            } catch (e: Exception) {
                Log.w(TAG, "YouTube Music API çağrısı başarısız (${e.message}), fallback sözlere dönülüyor.")
            }
        }

        val result = fetchedLyrics ?: generateSampleSyncedLyrics(trackTitle, artistName, durationSeconds)
        memoryCache[cacheKey] = result
        return@withContext result
    }

    /**
     * YouTube Music API'den şarkı sözü çeker, başarısız olursa null döner.
     */
    private suspend fun fetchYouTubeMusicLyrics(videoId: String): List<LyricLine>? = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "YouTube Music'ten şarkı sözü alıyor: $videoId")
            
            // YouTube Music'ten şarkı sözü verilerini alır
            val jsonResponse = getYouTubeMusicLyricsJson(videoId)
            if (jsonResponse != null) {
                val extractedLyrics = extractLyricsFromYouTubeJson(jsonResponse)
                if (extractedLyrics.isNotEmpty()) {
                    Log.d(TAG, "YouTube Music'ten ${extractedLyrics.size} satır şarkı sözü alındı.")
                    return@withContext extractedLyrics
                }
            }
            
            return@withContext null
        } catch (e: Exception) {
            Log.w(TAG, "YouTube Music lyrics extraction başarısız: ${e.message}")
            return@withContext null
        }
    }

    /**
     * YouTube Music API'den şarkı sözü JSON verilerini alır.
     */
    private suspend fun getYouTubeMusicLyricsJson(videoId: String): String? = withContext(Dispatchers.IO) {
        try {
            // YouTube Music API endpointini kullanır
            val endpoint = "https://music.youtube.com/youtubei/v1/next"
            val payload = "{\"context\":{\"client\":{\"clientName\":\"WEB_REMIX\",\"clientVersion\":\"1.20240101.01.00\",\"hl\":\"en\",\"gl\":\"US\"}},\"videoId\":\"$videoId\"}"
            
            val url = URL(endpoint)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
            connection.setRequestProperty("Origin", "https://music.youtube.com")
            connection.setRequestProperty("Referer", "https://music.youtube.com/")
            connection.doOutput = true
            connection.connectTimeout = TIMEOUT_MS
            connection.readTimeout = TIMEOUT_MS

            // Payload'u gönder
            connection.outputStream.use { outputStream ->
                outputStream.write(payload.toByteArray(Charsets.UTF_8))
                outputStream.flush()
            }

            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                Log.d(TAG, "YouTube Music API'den yanıt alındı: ${response.length} karakter")
                return@withContext response
            } else {
                Log.w(TAG, "YouTube Music API hatası: ${connection.responseCode}")
                return@withContext null
            }
        } catch (e: Exception) {
            Log.w(TAG, "YouTube Music lyrics JSON alırken hata: ${e.message}")
            return@withContext null
        }
    }

    /**
     * YouTube Music JSON yanıtından şarkı sözü verilerini çıkarır.
     */
    private fun extractLyricsFromYouTubeJson(jsonResponse: String): List<LyricLine> {
        return try {
            val json = JSONObject(jsonResponse)
            val lyricsArray = json.optJSONArray("lyrics") ?: json.optJSONArray("syncedLyrics") ?: json.optJSONArray("actions")
            if (lyricsArray != null && lyricsArray.length() > 0) {
                val extractedLyrics = ArrayList<LyricLine>()
                for (i in 0 until lyricsArray.length()) {
                    val lyricObj = lyricsArray.getJSONObject(i)
                    val timeMs = lyricObj.optLong("time", lyricObj.optLong("startTimeMs", 0L)) * 1000L
                    val text = lyricObj.optString("text", lyricObj.optString("lineText", ""))
                    if (text.isNotBlank()) {
                        extractedLyrics.add(LyricLine(timeMs, text))
                    }
                }
                if (extractedLyrics.isNotEmpty()) {
                    Log.d(TAG, "YouTube Music JSON'ten ${extractedLyrics.size} satır şarkı sözü çıkarıldı.")
                }
                extractedLyrics
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.w(TAG, "YouTube JSON'ten şarkı sözü çıkarılırken hata: ${e.message}")
            emptyList()
        }
    }

    /**
     * Çevrimdışı durumlarda veya API'de olmayan şarkılar için dinamik zaman damgalı söz şablonu üretir.
     */
    private fun generateSampleSyncedLyrics(
        title: String,
        artist: String,
        durationSeconds: Long
    ): List<LyricLine> {
        val totalMs = if (durationSeconds > 0) durationSeconds * 1000L else 180000L
        val step = (totalMs / 8).coerceAtLeast(8000L)

        return listOf(
            LyricLine(0L, "🎶 [Giriş Enstrümantal]"),
            LyricLine(step, "I never meant to cause you any sorrow"),
            LyricLine(step * 2, "I never meant to cause you any pain"),
            LyricLine(step * 3, "$title - $artist"),
            LyricLine(step * 4, "You know the rules and so do I"),
            LyricLine(step * 5, "A full commitment's what I'm thinking of"),
            LyricLine(step * 6, "Never gonna give you up, never gonna let you down"),
            LyricLine(step * 7, "🎶 [Bitiş Solo]")
        )
    }
}
