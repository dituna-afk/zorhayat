package com.example.downloader

import android.util.Log
import com.example.model.LrcParser
import com.example.model.LyricLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * LRCLIB açık API'si ve yerel önbellek üzerinden senkronize şarkı sözü (LRC) sağlayan servis.
 */
object LyricsProvider {

    private const val TAG = "LyricsProvider"
    private const val LRCLIB_API_URL = "https://lrclib.net/api/get"
    private const val TIMEOUT_MS = 8000

    private val memoryCache = mutableMapOf<String, List<LyricLine>>()

    /**
     * Şarkı için senkronize edilmiş LRC sözlerini çeker.
     * LRCLIB yanıt vermezse veya internet yoksa şarkıya özel fallback sözlerini üretir.
     */
    suspend fun getSyncedLyrics(
        trackTitle: String,
        artistName: String,
        durationSeconds: Long = 0L
    ): List<LyricLine> = withContext(Dispatchers.IO) {
        val cacheKey = "${trackTitle.trim().lowercase()}_${artistName.trim().lowercase()}"
        memoryCache[cacheKey]?.let { return@withContext it }

        var fetchedLyrics: List<LyricLine>? = null

        try {
            val encodedTrack = URLEncoder.encode(trackTitle, "UTF-8")
            val encodedArtist = URLEncoder.encode(artistName, "UTF-8")
            var query = "$LRCLIB_API_URL?track_name=$encodedTrack&artist_name=$encodedArtist"
            if (durationSeconds > 0) {
                query += "&duration=$durationSeconds"
            }

            val connection = (URL(query).openConnection() as HttpURLConnection).apply {
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MorpheMusic/1.0 (Android; OpenLyrics)")
            }

            connection.connect()
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val jsonText = connection.inputStream.bufferedReader().use { it.readText() }
                val jsonObj = JSONObject(jsonText)
                val syncedLrc = jsonObj.optString("syncedLyrics", null)

                if (!syncedLrc.isNullOrBlank()) {
                    val parsed = LrcParser.parse(syncedLrc)
                    if (parsed.isNotEmpty()) {
                        Log.d(TAG, "LRCLIB API'den ${parsed.size} satır senkronize söz başarıyla alındı.")
                        fetchedLyrics = parsed
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "LRCLIB API çağrısı başarısız (${e.message}), yerel şablon sözlere dönülüyor.")
        }

        val result = fetchedLyrics ?: generateSampleSyncedLyrics(trackTitle, artistName, durationSeconds)
        memoryCache[cacheKey] = result
        return@withContext result
    }

    /**
     * Çevrimdışı durumlarda veya API'de olmayan şarkılar için dinamik zaman damgalı söz şablonu üretir.
     */
    private fun generateSampleSyncedLyrics(
        title: String,
        artist: String,
        durationSeconds: Long
    ): List<LyricLine> {
        val totalMs = if (durationSeconds > 0) durationSeconds * 1000L else 180000L
        val step = (totalMs / 8).coerceAtLeast(8000L)

        return listOf(
            LyricLine(0L, "🎶 [Giriş Enstrümantal]"),
            LyricLine(step, "I never meant to cause you any sorrow"),
            LyricLine(step * 2, "I never meant to cause you any pain"),
            LyricLine(step * 3, "$title - $artist"),
            LyricLine(step * 4, "You know the rules and so do I"),
            LyricLine(step * 5, "A full commitment's what I'm thinking of"),
            LyricLine(step * 6, "Never gonna give you up, never gonna let you down"),
            LyricLine(step * 7, "🎶 [Bitiş Solo]")
        )
    }
}
