package com.example.downloader

import android.util.Log

/**
 * YouTube audio stream resolver using yt-dlp command-line tool.
 * This class provides functionality to resolve YouTube audio streams without requiring cookies or JavaScript runtime.
 */
object YTDlpResolver {

    private const val TAG = "YTDlpResolver"

    /**
     * Resolves audio stream URL for a given YouTube video ID using yt-dlp.
     * @param videoId The YouTube video ID.
     * @return StreamResolutionResult containing the audio stream URL or error details.
     */
    fun resolveAudioStreamWithYTDlp(videoId: String): StreamResolutionResult {
        try {
            // Use yt-dlp to get the audio stream URL (format 139 = mp4 audio only)
            val command = listOf(
                "yt-dlp",
                "--skip-download",
                "--format", "139",
                "--print", "%(url)s",
                "https://www.youtube.com/watch?v=$videoId"
            )

            val process = ProcessBuilder(*command.toTypedArray()).redirectErrorStream(true).start()
            val output = process.inputStream.reader().readText()
            val error = process.errorStream.reader().readText()
            process.waitFor()

            // Log error output for debugging
            if (error.isNotBlank()) {
                Log.w(TAG, "yt-dlp error: $error")
            }

            // Remove the warning line if present
            val cleanOutput = output.removePrefix("WARNING: [youtube] No supported JavaScript runtime could be found. Only deno is enabled by default; to use another runtime add  --js-runtimes RUNTIME[:PATH]  to your command/config. YouTube extraction without a JS runtime has been deprecated, and some formats may be missing. See  https://github.com/yt-dlp/yt-dlp/wiki/EJS  for details on installing one\n")

            return if (cleanOutput.isNotBlank()) {
                StreamResolutionResult(
                    streamUrl = cleanOutput.trim(),
                    mimeType = "audio/mp4",
                    bitrate = 0,
                    contentLength = 0L,
                    errorCode = null,
                    errorDetail = null
                )
            } else {
                StreamResolutionResult(
                    streamUrl = null,
                    mimeType = null,
                    bitrate = 0,
                    contentLength = 0L,
                    errorCode = "YTDLP_ERROR",
                    errorDetail = "Failed to resolve audio stream URL"
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Exception in resolveAudioStreamWithYTDlp: ${e.message}", e)
            return StreamResolutionResult(
                streamUrl = null,
                mimeType = null,
                bitrate = 0,
                contentLength = 0L,
                errorCode = "YTDLP_EXCEPTION",
                errorDetail = e.message ?: "Unknown error"
            )
        }
    }

    /**
     * Resolves audio stream URL for a given search query using yt-dlp.
     * @param searchQuery The search query (artist + title).
     * @return StreamResolutionResult containing the audio stream URL or error details.
     */
    fun resolveAudioStreamWithYTDlpFromSearch(searchQuery: String): StreamResolutionResult {
        try {
            // Use yt-dlp to search for the video and get the first result's audio stream URL
            val command = listOf(
                "yt-dlp",
                "--default-search", "ytsearch1:$searchQuery",
                "--skip-download",
                "--format", "139",
                "--print", "%(url)s"
            )

            val process = ProcessBuilder(*command.toTypedArray()).redirectErrorStream(true).start()
            val output = process.inputStream.reader().readText()
            val error = process.errorStream.reader().readText()
            process.waitFor()

            // Log error output for debugging
            if (error.isNotBlank()) {
                Log.w(TAG, "yt-dlp error: $error")
            }

            // Remove the warning line if present
            val cleanOutput = output.removePrefix("WARNING: [youtube] No supported JavaScript runtime could be found. Only deno is enabled by default; to use another runtime add  --js-runtimes RUNTIME[:PATH]  to your command/config. YouTube extraction without a JS runtime has been deprecated, and some formats may be missing. See  https://github.com/yt-dlp/yt-dlp/wiki/EJS  for details on installing one\n")

            return if (cleanOutput.isNotBlank()) {
                StreamResolutionResult(
                    streamUrl = cleanOutput.trim(),
                    mimeType = "audio/mp4",
                    bitrate = 0,
                    contentLength = 0L,
                    errorCode = null,
                    errorDetail = null
                )
            } else {
                StreamResolutionResult(
                    streamUrl = null,
                    mimeType = null,
                    bitrate = 0,
                    contentLength = 0L,
                    errorCode = "YTDLP_ERROR",
                    errorDetail = "Failed to resolve audio stream URL from search"
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Exception in resolveAudioStreamWithYTDlpFromSearch: ${e.message}", e)
            return StreamResolutionResult(
                streamUrl = null,
                mimeType = null,
                bitrate = 0,
                contentLength = 0L,
                errorCode = "YTDLP_EXCEPTION",
                errorDetail = e.message ?: "Unknown error"
            )
        }
    }
}
