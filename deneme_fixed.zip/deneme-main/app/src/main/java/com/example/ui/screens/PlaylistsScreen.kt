package com.example.ui.screens

import android.app.Application
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.animation.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.rememberViewModel
import com.example.downloader.LyricsProvider
import com.example.downloader.MediaMetadataManager
import com.example.model.LyricLine
import com.example.ui.theme.AppTheme
import com.example.viewmodel.MusicPlayerViewModel
import com.example.viewmodel.MusicUiState
import com.example.data.UserPlaylist
import com.example.downloader.MediaTrackInfo
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import kotlin.random.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// Sakura çiçeği verisi
@Immutable
data class SakuraFlower(
    val id: String,
    val x: Float,
    val y: Float,
    val size: Float,
    val rotation: Float,
    val animationProgress: Float = 0f,
    val bloomProgress: Float = 0f,
    val colorIntensity: Float = 1f
)

// Sakura ağacı verisi
@Immutable
data class SakuraTree(
    val id: String,
    val x: Float,
    val y: Float,
    val height: Float,
    val trunkWidth: Float,
    val branches: List<SakuraBranch>
)

@Immutable
data class SakuraBranch(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val thickness: Float,
    val branchIndex: Int
)

/**
 * PlaylistsScreen - Ana ekranı gösteren composable
 * Çalma listelerini doğrudan açar, akıcı animasyonlar içerir
 */
@Composable
fun PlaylistsScreen(
    viewModel: MusicPlayerViewModel = rememberViewModel(),
    onPlaylistSelected: (UserPlaylist) -> Unit = { },
    onTrackSelected: (MediaTrackInfo) -> Unit = { }
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    // Sakura temalı renk paleti
    val sakuraBackground = AppTheme.SAKURA_SAKURA.background
    val sakuraSurface = AppTheme.SAKURA_SAKURA.surface
    val sakuraPrimary = AppTheme.SAKURA_SAKURA.primary
    val sakuraPrimaryContainer = AppTheme.SAKURA_SAKURA.primaryContainer
    val sakuraTextPrimary = AppTheme.SAKURA_SAKURA.textPrimary
    val sakuraTextSecondary = AppTheme.SAKURA_SAKURA.textSecondary
    
    // Animasyon state'leri
    val animateState = remember { Animatable(1f) }
    val sakuraFlowers = remember { mutableStateOf(generateSakuraFlowers()) }
    val sakuraTree = remember { mutableStateOf(generateSakuraTree()) }
    
    // Sakura çiçeklerini animasyonla
    LaunchedEffect(Unit) {
        launch {
            while (true) {
                sakuraFlowers.value = sakuraFlowers.value.map { flower ->
                    if (flower.bloomProgress < 1f) {
                        flower.copy(
                            bloomProgress = (flower.bloomProgress + 0.005f).coerceAtMost(1f),
                            animationProgress = (flower.animationProgress + 0.02f).coerceAtMost(1f)
                        )
                    } else {
                        val sway = (Random.nextFloat() - 0.5f) * 0.1f
                        flower.copy(
                            rotation = flower.rotation + sway,
                            bloomProgress = 0f,
                            animationProgress = (flower.animationProgress + 0.02f).coerceAtMost(1f)
                        )
                    }
                }
                delay(50)
            }
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(sakuraBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        playlistHeader(uiState, sakuraPrimary, sakuraPrimaryContainer, sakuraTextSecondary)
        
        sakuraBackgroundDrawing(sakuraTree.value, sakuraPrimary)
        
        animateListItems(uiState.playlists, animateState, sakuraPrimary, sakuraPrimaryContainer, sakuraTextSecondary, uiState)
        
        sakuraFlowersDisplay(sakuraFlowers.value, sakuraPrimary)
    }
}

/**
 * Başlık bölümü - fade animasyonu ile (Sakura temalı)
 */
@Composable
fun playlistHeader(
    uiState: MusicUiState,
    sakuraPrimary: Color,
    sakuraPrimaryContainer: Color,
    sakuraTextSecondary: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .background(
                Brush.linearGradient(
                    colors = listOf(sakuraPrimaryContainer, sakuraPrimary),
                    start = Offset.Zero, // Changed from Alignment.TopEnd to Offset
                    end = Offset.Infinite // Changed from Alignment.BottomStart to Offset
                )
            )
            .shadow(
                shadowColor = Color(0x44000000),
                shape = RoundedCornerShape(16.dp),
                elevation = 4.dp
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Sakura Music",
                style = MaterialTheme.typography.headlineSmall, // h5 deprecated, use headlineSmall
                color = Color.White,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            
            Text(
                text = "Blooming with cherry blossoms",
                style = MaterialTheme.typography.bodySmall, // caption deprecated, use bodySmall
                color = sakuraTextSecondary
            )
            
            OutlinedTextField(
                value = "",
                onValueChange = { },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                label = { Text("Ara", color = sakuraTextSecondary) },
                placeholder = { Text("Şarkı, albüm veya sanatçı ara", color = sakuraTextSecondary) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = null,
                        tint = sakuraPrimary
                    )
                }
            )
        }
    }
}

/**
 * Sakura ağacı çizimi
 */
@Composable
fun sakuraBackgroundDrawing(sakuraTree: SakuraTree, sakuraPrimary: Color) {
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 0.3f }
    ) {
        sakuraTree.branches.forEach { branch ->
            drawLine(
                color = sakuraPrimary.copy(alpha = 0.5f),
                start = Offset(branch.startX, branch.startY),
                end = Offset(branch.endX, branch.endY),
                strokeWidth = branch.thickness,
                cap = StrokeCap.Round
            )
        }
    }
}

/**
 * Sakura çiçeklerini render et
 */
@Composable
fun sakuraFlowersDisplay(flowers: List<SakuraFlower>, sakuraPrimary: Color) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 0.8f }
            .drawBehind {
                flowers.forEach { flower ->
                    val bloomAlpha = flower.bloomProgress * flower.colorIntensity * 0.7f
                    val swayX = flower.size * 0.3f * cos(flower.rotation * PI / 180)
                    
                    // Ana çiçek
                    drawOval(
                        color = sakuraPrimary.copy(alpha = bloomAlpha),
                        topLeft = Offset(flower.x - flower.size / 2, flower.y - flower.size / 2),
                        size = Size(flower.size, flower.size)
                    )
                    
                    // Çiçek eğriliği (sway)
                    drawCircle(
                        color = sakuraPrimary.copy(alpha = flower.bloomProgress * 0.4f),
                        center = Offset(flower.x + swayX, flower.y + flower.size * 0.3f),
                        radius = flower.size * 0.4f * flower.bloomProgress
                    )
                }
            }
    )
}

/**
 * Sakura çiçeklerini oluşturur
 */
private fun generateSakuraFlowers(): List<SakuraFlower> {
    val flowers = mutableListOf<SakuraFlower>()
    val screenWidth = 360.dp.toPx()
    val screenHeight = 640.dp.toPx()
    
    repeat(15) {
        val x = Random.nextFloat() * screenWidth
        val y = screenHeight - Random.nextFloat() * 200f - 100f
        val size = Random.nextFloat() * 20f + 10f
        val rotation = Random.nextFloat() * 360f
        
        flowers.add(SakuraFlower(
            id = "flower_${Random.nextInt(10000)}",
            x = x,
            y = y,
            size = size,
            rotation = rotation,
            animationProgress = 0f,
            bloomProgress = 0f,
            colorIntensity = Random.nextFloat() * 0.5f + 0.5f
        ))
    }
    
    return flowers
}

/**
 * Sakura ağacı oluşturur
 */
private fun generateSakuraTree(): SakuraTree {
    val screenWidth = 360.dp.toPx()
    val screenHeight = 640.dp.toPx()
    
    val branches = mutableListOf<SakuraBranch>()
    
    for (i in 0..6) {
        val branchAngle = 60f - i * 20f
        val startX = screenWidth * 0.5f
        val startY = screenHeight * 0.3f - i * 30f
        val length = 80f
        
        val endX = startX + cos(branchAngle * PI / 180) * length
        val endY = startY - sin(branchAngle * PI / 180) * length
        val thickness = 4f + i * 0.5f
        
        branches.add(
            SakuraBranch(
                startX = startX,
                startY = startY,
                endX = endX,
                endY = endY,
                thickness = thickness,
                branchIndex = i
            )
        )
    }
    
    return SakuraTree(
        id = "main_tree",
        x = screenWidth * 0.5f,
        y = screenHeight * 0.8f,
        height = 300f,
        trunkWidth = 20f,
        branches = branches
    )
}

/**
 * Tek playlist kartı - slide ve fade animasyonu ile
 */
@Composable
fun PlaylistCard(
    playlist: UserPlaylist,
    onClick: () -> Unit,
    isSelected: Boolean = false,
    sakuraPrimary: Color,
    sakuraPrimaryContainer: Color,
    sakuraTextSecondary: Color
) {
    val fadeAnim = remember { Animatable(0f, durationMillis = 300) }
    val slideAnim = remember { Animatable(0f, durationMillis = 300) }
    
    LaunchedEffect(Unit) {
        fadeAnim.animateTo(1f)
        slideAnim.animateTo(1f)
    }
    
    val alpha by animateFloatAsState(fadeAnim, 1f)
    val offsetY by animateFloatAsState(slideAnim, 0f)
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .background(
                Brush.horizontalGradient(
                    colors = if (isSelected) {
                        listOf(sakuraPrimary.copy(alpha = 0.3f), sakuraPrimaryContainer.copy(alpha = 0.3f))
                    } else {
                        listOf(Color(0xFF1A1A1A), Color(0xFF1A1A1A))
                    }
                )
            )
            .shadow(
                shadowColor = Color(0x55000000),
                shape = RoundedCornerShape(12.dp),
                elevation = if (isSelected) 8.dp else 4.dp
            )
            .padding(4.dp)
            .clip(RoundedCornerShape(12.dp))
            .offset(x = 0.dp, y = offsetY)
            .alpha(alpha)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple()
            ) {
                onClick()
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(sakuraPrimary, sakuraPrimaryContainer)
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.QueueMusic,
                    contentDescription = null,
                    tint = Color.White,
                    size = 24.dp
                )
            }
            
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 12.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = playlist.title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1
                )
                
                Text(
                    text = "${playlist.trackCount} şarkı • ${playlist.totalDuration}",
                    style = MaterialTheme.typography.bodySmall,
                    color = sakuraTextSecondary,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Liste öğelerini animasyonlu olarak gösterir
 */
@Composable
fun animateListItems(
    playlists: List<UserPlaylist>,
    animateState: Animatable,
    sakuraPrimary: Color,
    sakuraPrimaryContainer: Color,
    sakuraTextSecondary: Color,
    uiState: MusicUiState
) {
    if (playlists.isEmpty()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF1A1A1A), Color(0xFF0A0A0A))
                    )
                ),
            elevation = 4.dp,
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Filled.Failed,
                    contentDescription = null,
                    tint = sakuraTextSecondary,
                    size = 64.dp
                )
                Text(
                    text = "Henüz playlist yok",
                    style = MaterialTheme.typography.bodyLarge,
                    color = sakuraTextSecondary
                )
                Text(
                    text = "Şarkı inderek playlist oluşturun",
                    style = MaterialTheme.typography.bodySmall,
                    color = sakuraTextSecondary.copy(alpha = 0.7f)
                )
            }
        }
        return
    }
    
    // Staggered animation - her öğe farklı zamanlarda görünür
    playlists.forEachIndexed { index, playlist ->
        val itemAnim = remember { Animatable(0f, durationMillis = 300) }
        
        LaunchedEffect(index) {
            delay((index * 30).toLong())
            itemAnim.animateTo(1f)
        }
        
        val itemAlpha by animateFloatAsState(itemAnim, 1f)
        val itemOffsetY by animateFloatAsState(itemAnim, 0f) { 20f * (1 - it) }
        
        PlaylistCard(
            playlist = playlist,
            onClick = { onPlaylistSelected(playlist) },
            isSelected = uiState.selectedPlaylist?.id == playlist.id,
            sakuraPrimary = sakuraPrimary,
            sakuraPrimaryContainer = sakuraPrimaryContainer,
            sakuraTextSecondary = sakuraTextSecondary
        )
    }
}
