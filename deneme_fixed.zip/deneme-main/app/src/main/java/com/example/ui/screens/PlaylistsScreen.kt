package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberprogressstate.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.dropShadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.epsilon
import androidx.compose.ui.unit.textUnitInInches
import androidx.compose.ui.unit.textUnitPx
import androidx.compose.ui.unit.textUnitSp
import androidx.compose.ui.unit.alignValue
import androidx.compose.ui.unit.px
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.dpEnd
import androidx.compose.ui.unit.dpStart
import androidx.compose.ui.unit.height
import androidx.compose.ui.unit.width
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.textSize
import androidx.compose.ui.semantics.clickable
import androidx.compose.ui.semantics.interactionSource
import androidx.compose.ui.sideeffect.*
import androidx.compose.ui.surface.*
import androidx.compose.ui.text.layout.*
import androidx.compose.ui.text.selection.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.textUnitInInches
import androidx.compose.ui.unit.textUnitPx
import androidx.compose.ui.unit.textUnitSp
import androidx.compose.ui.layout.Arrangement
import androidx.compose.ui.layout.Column
import androidx.compose.ui.layout.Row
import androidx.compose.ui.layout.Spacer
import androidx.compose.ui.layout.fillMaxWidth
import androidx.compose.ui.layout.fillMaxSize
import androidx.compose.ui.layout.padding
import androidx.compose.ui.layout.size
import androidx.compose.ui.unit.align
import androidx.compose.ui.unit.Alignment
import androidx.compose.ui.unit.padding
import androidx.compose.ui.unit.size
import androidx.lifecycle.viewmodel.compose.rememberViewModel
import com.example.downloader.LyricsProvider
import com.example.downloader.MediaMetadataManager
import com.example.model.LyricLine
import com.example.viewmodel.MusicPlayerViewModel
import com.example.ui.theme.AppTheme
import com.example.viewmodel.MusicUiState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import kotlin.random.Random
import kotlin.math.PI

// Sakura çiçeği verisi
@Immutable
data class SakuraFlower(
    val id: String,
    val x: Float,
    val y: Float,
    val size: Float,
    val rotation: Float,
    val animationProgress: Float = 0f,
    val bloomProgress: Float = 0f,
    val colorIntensity: Float = 1f
)

// Sakura ağacı verisi
@Immutable
data class SakuraTree(
    val id: String,
    val x: Float,
    val y: Float,
    val height: Float,
    val trunkWidth: Float,
    val branches: List<SakuraBranch>
)

@Immutable
data class SakuraBranch(
    val startX: Float,
    val startY: Float,
    val endX: Float,
    val endY: Float,
    val thickness: Float,
    val branchIndex: Int
)

/**
 * PlaylistsScreen - Ana ekranı gösteren composable
 * Çalma listelerini doğrudan açar, akıcı animasyonlar içerir
 */
@Composable
fun PlaylistsScreen(
    viewModel: MusicPlayerViewModel = MusicPlayerViewModel((Application(LocalContext.current)))),
    onPlaylistSelected: (UserPlaylist) -> Unit = { },
    onTrackSelected: (MediaTrackInfo) -> Unit = { }
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val musicUiState by viewModel.musicUiState.collectAsState()
    
    // Sakura temalı renk paleti
    val sakuraBackground = AppTheme.SAKURA_SAKURA.background
    val sakuraSurface = AppTheme.SAKURA_SAKURA.surface
    val sakuraPrimary = AppTheme.SAKURA_SAKURA.primary
    val sakuraPrimaryContainer = AppTheme.SAKURA_SAKURA.primaryContainer
    val sakuraTextPrimary = AppTheme.SAKURA_SAKURA.textPrimary
    val sakuraTextSecondary = AppTheme.SAKURA_SAKURA.textSecondary
    
    // Animasyon state'leri
    val animateState = remember { Animatable(1f) }
    val sakuraFlowers = remember { mutableStateOf(generateSakuraFlowers()) }
    val sakuraTree = remember { mutableStateOf(generateSakuraTree()) }
    
    // Sakura çiçeklerini animasyonla
    LaunchedEffect(Unit) {
        launch {
            while (true) {
                // Her çiçek için bloom animasyonu
                sakuraFlowers.value = sakuraFlowers.value.map { flower ->
                    if (flower.bloomProgress < 1f) {
                        flower.copy(
                            bloomProgress = (flower.bloomProgress + 0.005f).coerceAtMost(1f),
                            animationProgress = (flower.animationProgress + 0.02f).coerceAtMost(1f)
                        )
                    } else {
                        // Her çiçek için rastgele sway animasyonu
                        val sway = (Random.nextFloat() - 0.5f) * 0.1f
                        flower.copy(
                            rotation = flower.rotation + sway,
                            bloomProgress = 0f,
                            animationProgress = (flower.animationProgress + 0.02f).coerceAtMost(1f)
                        )
                    }
                }
                delay(50) // 50ms gecikme
            }
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(sakuraBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp) {
            // Başlık bölümü
            playlistHeader(uiState, sakuraPrimary, sakuraPrimaryContainer)
            
            // Sakura ağacı çizimi
            sakuraBackgroundDrawing(sakuraTree.value)
            
            // Playlist listesi with animasyon
            animateListItems(uiState.playlists, animateState)
            
            // Sakura çiçekleri render et
            sakuraFlowersDisplay(sakuraFlowers.value)
        }
    )
}

/**
 * Başlık bölümü - fade animasyonu ile (Sakura temalı)
 */
@Composable
fun playlistHeader(
    uiState: MusicUiState,
    sakuraPrimary: Color,
    sakuraPrimaryContainer: Color
) {
    val showSearch = remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        sakuraPrimaryContainer,
                        sakuraPrimary
                    ),
                    start = Alignment.TopEnd,
                    end = Alignment.BottomStart
                )
            )
            .shadow(
                shadowColor = Color(0x44000000),
                shape = RoundedCornerShape(16.dp),
                elevation = 4.dp
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp) {
                // App adı ve subtitle
                Text(
                    text = "Sakura Music",
                    style = MaterialTheme.typography.h5,
                    color = Color(0xFFFFFFFF),
                    modifier = Modifier
                        .padding(bottom = 4.dp)
                )
                
                SmallText(
                    text = "Blooming with cherry blossoms",
                    color = sakuraTextSecondary
                )
                
                // Search bar
                OutlinedTextField(
                    value = "",
                    onValueChange = { },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp),
                    label = { Text("Ara", color = sakuraTextSecondary) },
                    placeholder = { Text("Şarkı, albüm veya sanatçı ara", color = sakuraTextSecondary) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = null,
                            tint = sakuraPrimary
                        )
                    }
                )
            }
    )
}

/**
 * Sakura ağacı çizimi
 */
@Composable
fun sakuraBackgroundDrawing(sakuraTree: SakuraTree) {
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 0.3f }
    ) {
        sakuraTree.branches.forEach { branch ->
            // Branch çizimi
            drawLine(
                color = sakuraTree.trunkWidth,
                start = Offset(branch.startX, branch.startY),
                end = Offset(branch.endX, branch.endY),
                strokeWidth = branch.thickness,
                cap = StrokeCap.Round,
                pathEffect = PathEffect.cornerPathEffect(8.dp.toPx())
            )
        }
    }
}

/**
 * Sakura çiçeklerini render et
 */
@Composable
fun sakuraFlowersDisplay(flowers: List<SakuraFlower>) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 0.8f }
    ) {
        flowers.forEach { flower ->
            // Sakura çiçeği çizimi
            drawOval(
                color = sakuraPrimary.copy(alpha = flower.bloomProgress * flower.colorIntensity * 0.7f),
                left = flower.x - flower.size / 2,
                top = flower.y - flower.size / 2,
                right = flower.x + flower.size / 2,
                bottom = flower.y + flower.size / 2,
                transformOrigin = TransformOrigin.Center
            )
            
            // Çiçek eğriliği (sway)
            drawCircle(
                color = sakuraPrimary.copy(alpha = flower.bloomProgress * 0.4f),
                center = Offset(flower.x + flower.size * 0.3f * kotlin.math.cos(flower.rotation * PI / 180), flower.y + flower.size * 0.3f),
                radius = flower.size * 0.4f * flower.bloomProgress
            )
        }
    }
}

/**
 * Sakura çiçeklerini oluşturur
 */
private fun generateSakuraFlowers(): List<SakuraFlower> {
    val flowers = mutableListOf<SakuraFlower>()
    val screenWidth = 360.dp.toPx()
    val screenHeight = 640.dp.toPx()
    
    repeat(15) { // 15 çiçek
        val x = Random.nextFloat() * screenWidth
        val y = screenHeight - Random.nextFloat() * 200f - 100f // Alttan başla
        val size = Random.nextFloat() * 20f + 10f // 10-30px
        val rotation = Random.nextFloat() * 360f
        
        flowers.add(SakuraFlower(
            id = "flower_${Random.nextInt(10000)}",
            x = x,
            y = y,
            size = size,
            rotation = rotation,
            animationProgress = 0f,
            bloomProgress = 0f,
            colorIntensity = Random.nextFloat() * 0.5f + 0.5f
        ))
    }
    
    return flowers
}

/**
 * Sakura ağacı oluşturur
 */
private fun generateSakuraTree(): SakuraTree {
    val screenWidth = 360.dp.toPx()
    val screenHeight = 640.dp.toPx()
    
    val trunk = SakuraBranch(
        startX = screenWidth * 0.5f,
        startY = screenHeight * 0.8f,
        endX = screenWidth * 0.5f,
        endY = screenHeight * 0.3f,
        thickness = 8f,
        branchIndex = 0
    )
    
    // Ağaç dalları
    val branches = mutableListOf<SakuraBranch>()
    
    for (i in 0..6) { // 7 ana dal
        val branchAngle = 60f - i * 20f // dallar yukarıda yayılır
        val startX = screenWidth * 0.5f
        val startY = screenHeight * 0.3f - i * 30f
        val length = 80f
        
        val endX = startX + kotlin.math.cos(branchAngle * PI / 180) * length
        val endY = startY - kotlin.math.sin(branchAngle * PI / 180) * length
        val thickness = 4f + i * 0.5f
        
        branches.add(
            SakuraBranch(
                startX = startX,
                startY = startY,
                endX = endX,
                endY = endY,
                thickness = thickness,
                branchIndex = i
            )
        )
    }
    
    return SakuraTree(
        id = "main_tree",
        x = screenWidth * 0.5f,
        y = screenHeight * 0.8f,
        height = 300f,
        trunkWidth = 20f,
        branches = branches
    )
}

/**
 * Tek playlist kartı - slide ve fade animasyonu ile
 */
@Composable
fun PlaylistCard(
    playlist: UserPlaylist,
    onClick: () -> Unit,
    isSelected: Boolean = false
) {
    // Her öğe için giriş animasyonu
    var expanded by remember { mutableStateOf(false) }
    val fadeAnim = remember { Animatable(0f, durationMillis = 300) }
    val slideAnim = remember { Animatable(0f, durationMillis = 300) }
    
    LaunchedEffect(expand) {
        fadeAnim.animateTo(1f)
        slideAnim.animateTo(1f)
    }
    
    val alpha by animateOrMemo(fadeAnim) { 1f }
    val offsetY by animateAsState(slideAnim) { 0f }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .background(
                Brush.solid(
                    if (isSelected) {
                        Color(0xFF1A0F2B) // Seçili kart arka planı
                    } else {
                        Color(0xFF181818) // Normal kart arka planı
                    }
                )
            )
            .shadow(
                shadowColor = Color(0x55000000),
                shape = RoundedCornerShape(12.dp),
                elevation = isSelected ? 8.dp : 4.dp
            )
            .padding(4.dp)
            .clip(RoundedCornerShape(12.dp))
            .offset(x = 0.dp, y = offsetY)
            .alpha(alpha)
            .clickable(
                interactionSource = remember { InteractionSource.clickable() },
                indication = remember { RippleTheme(rippleColor = accentPink) }
            ) {
            onClick()
        }
        
        // Kart içeriği - vertical scroll olmadan sabit height
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically {
                    // Playlist ikonu
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(
                                Brush.gradient(
                                    colors = listOf(accentPink, accentPurple)
                                ),
                                shape = CircleShape
                            ),
                        content = {
                            Icon(
                                imageVector = Icons.Filled.QueueMusic,
                                contentDescription = null,
                                tint = Color(0xFFFFFFFF)
                            )
                        }
                    )
                    
                    // Playlist bilgileri
                    Column(
                        modifier = Modifier.weight(1f).padding(start = 8.dp) {
                            Text(
                                text = playlist.title,
                                style = MaterialTheme.typography.body2,
                                color = Color(0xFFFFFFFF),
                                overflow = TextOverflow.Ellipsis,
                                maxLines = 1
                            )
                            
                            Text(
                                text = "${playlist.trackCount} şarkı • ${playlist.totalDuration}",
                                style = MaterialTheme.typography.caption,
                                color = textSecondary,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    )
                }
            )
        }
    )
}

/**
 * Liste öğelerini animasyonlu olarak gösterir
 */
@Composable
fun animateListItems(
    playlists: List<UserPlaylist>,
    animateState: Animatable
) {
    if (playlists.isEmpty()) {
        // Boş durum mesajı
        Card(
            modifier = Modifier
                .fillMaxSize()
                .height(200.dp)
                .background(
                    Brush.gradient(
                        colors = listOf(Color(0xFF1A1A1A), Color(0xFF0A0A0A))
                    )
                ),
            elevation = 4.dp,
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Failed,
                    contentDescription = null,
                    tint = textSecondary,
                    size = 64.dp
                )
                Text(
                    text = "Henüz playlist yok",
                    style = MaterialTheme.typography.body1,
                    color = textSecondary
                )
                Text(
                    text = "Şarkı inderek playlist oluşturun",
                    style = MaterialTheme.typography.caption,
                    color = textSecondary.copy(alpha = 0.7f)
                )
            }
        }
        return
    }
    
    // Staggered animation - her öğe farklı zamanlarda görünür
    val item animateListAsState(
        items = playlists,
        step = 50, // her öğe 50ms gecikme
        reverse = false
    ) {
        // Her öğe için farklı animation gecikmesi
        var index by remember { mutableStateOf(0) }
        
        playlists.forEachIndexed { index, playlist ->
            PlaylistCard(
                playlist = playlist,
                onClick = { /* Playlist seçildi işlemi */ },
                isSelected = uiState.selectedPlaylist?.id == playlist.id
            )
        }
    }
    
    // Alternatif: Manuel stagger animasyonu
    playlists.forEachIndexed { index, playlist ->
        var itemAnim by remember { Animatable(0f) }
        
        LaunchedEffect(index) {
            delay(index.toLong() * 30) // Artan gecikme
            itemAnim.animateTo(1f)
        }
        
        PlaylistCard(
            playlist = playlist,
            onClick = { /* Playlist seçildi işlemi */ },
            isSelected = uiState.selectedPlaylist?.id == playlist.id
        ) { /* lambda body needed */}
    }
}

/**
 * Ana Activity - Activity'yi ayarlayan wrapper
 */
@Composable
fun ContentScreen() {
    val viewModel: MusicPlayerViewModel = viewModel()
    
    // UI State collector
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    // Main Scaffold
    Scaffold(
        topBar = {
            // Üst bar - minimal
            TopAppBar(
                title = { Text("Morphe Music") },
                navigationIcon = {
                    IconButton(onClick = { }) {
                        Icon(
                            imageVector = Icons.Filled.Menu,
                            contentDescription = null,
                            tint = Color(0xFFFFFFFF)
                        )
                    }
                },
                backgroundColor = Color.Transparent,
                elevation = 0.dp
            )
        },
        bottomBar = {
            // Mini player bar
            MiniPlayerBar()
        }
    ) { padding ->
        PlaylistsScreen(uiState = uiState) { playlist ->
            // Playlist seçildi - detail screen'e geçiş
            Log.d("PlaylistsScreen", "Playlist selected: ${playlist.title}")
        }
    }
}
