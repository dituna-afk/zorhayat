package com.example.ui.navigation

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalAppTheme
import com.example.viewmodel.YtMusicTab

private data class NavItem(
    val tab: YtMusicTab,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val NAV_ITEMS = listOf(
    NavItem(YtMusicTab.HOME, "Ana Sayfa", Icons.Filled.Home, Icons.Outlined.Home),
    NavItem(YtMusicTab.SEARCH, "Ara", Icons.Filled.Search, Icons.Outlined.Search),
    NavItem(YtMusicTab.LIBRARY, "Kitaplık", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
    NavItem(YtMusicTab.SETTINGS, "Ayarlar", Icons.Filled.Settings, Icons.Outlined.Settings)
)

@Composable
fun YtBottomNavigation(
    selectedTab: YtMusicTab,
    onTabSelected: (YtMusicTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = LocalAppTheme.current

    NavigationBar(
        containerColor = theme.background,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .height(68.dp)
            .testTag("yt_bottom_navigation")
    ) {
        NAV_ITEMS.forEach { item ->
            val isSelected = selectedTab == item.tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(item.tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.title
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        fontSize = 10.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = theme.primary,
                    selectedTextColor = theme.primary,
                    indicatorColor = theme.surfaceElevated,
                    unselectedIconColor = theme.textSecondary,
                    unselectedTextColor = theme.textSecondary
                ),
                modifier = Modifier.testTag("nav_tab_${item.tab.name.lowercase()}")
            )
        }
    }
}
