package com.example.downloader

import android.util.Log
import androidx.compose.runtime.Immutable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.regex.Pattern

/**
 * Akış çözümleme sonucunu ve olası hata kodlarını/detaylarını taşıyan veri modeli.
 */
@Immutable
data class StreamResolutionResult(
    val streamUrl: String? = null,
    val mimeType: String? = null,
    val bitrate: Int = 0,
    val contentLength: Long = 0L,
    val errorCode: String? = null,
    val errorDetail: String? = null
) {
    val isSuccess: Boolean get() = !streamUrl.isNullOrBlank()
}

/**
 * Oynatma listesi (Playlist) çözümleme sonucunu taşıyan veri modeli.
 */
@Immutable
data class PlaylistResolutionResult(
    val playlistId: String,
    val playlistTitle: String,
    val tracks: List<MediaTrackInfo>,
    val errorCode: String? = null,
    val errorDetail: String? = null
)

/**
 * YouTube ve YouTube Music bağlantılarını (Tekil Video ve Oynatma Listesi / Playlist) çözen,
 * EncryptedSharedPreferences üzerinden aktarılan oturum çerezlerini (SAPISID, __Secure-3PAPISID, LOGIN_INFO)
 * ve dinamik SAPISIDHASH imzasını kullanarak ses akışlarını ve oynatma listelerini çözümleyen motor.
 */
object YouTubeStreamResolver {

    private const val TAG = "YouTubeStreamResolver"

    const val YOUTUBE_ANDROID_USER_AGENT =
        "com.google.android.youtube/19.47.53 (Linux; U; Android 14) gzip"
    const val YOUTUBE_WEB_REMIX_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    const val YOUTUBE_MUSIC_ORIGIN = "https://music.youtube.com"
    const val YOUTUBE_MUSIC_REFERER = "https://music.youtube.com/"
    const val WEB_REMIX_CLIENT_NAME = "67"
    const val WEB_REMIX_CLIENT_VERSION = "1.20260101.01.00"

    // 173 KB sahte/hata dosyalarını engellemek için minimum geçerli ses boyutu (256 KB)
    private const val MIN_VALID_AUDIO_BYTES = 256 * 1024L

    private val VIDEO_ID_PATTERNS = listOf(
        Pattern.compile("(?:v=|youtu\\.be/|embed/|shorts/|watch\\?v=|music\\.youtube\\.com/watch\\?v=)([a-zA-Z0-9_-]{11})"),
        Pattern.compile("^([a-zA-Z0-9_-]{11})$")
    )

    private val PLAYLIST_ID_PATTERNS = listOf(
        Pattern.compile("[?&]list=([a-zA-Z0-9_-]+)"),
        Pattern.compile("^(VLLM|LM|PL[a-zA-Z0-9_-]{10,}|VL[a-zA-Z0-9_-]{2,}|OLAK5uy_[a-zA-Z0-9_-]+|RDCLAK5uy_[a-zA-Z0-9_-]+)$")
    )

    /**
     * Girilen metnin bir oynatma listesi (playlist?list=...) bağlantısı olup olmadığını kontrol eder.
     * Tekil bir video bağlantısı (watch?v= veya youtu.be/) değilse ve list parametresi içeriyorsa true döner.
     */
    fun isPlaylistUrl(input: String): Boolean {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return false

        // Doğrudan playlist?list= içeren bağlantılar her zaman playlist olarak işlenir
        if (trimmed.contains("playlist?list=", ignoreCase = true) ||
            trimmed.contains("/playlist?", ignoreCase = true)
        ) {
            return extractPlaylistId(trimmed) != null
        }

        // Eğer tekil bir watch?v= veya youtu.be/ video ID'si yoksa ama geçerli bir playlist ID varsa
        val hasDirectVideoId = extractVideoId(trimmed) != null
        val playlistId = extractPlaylistId(trimmed)
        return !hasDirectVideoId && playlistId != null
    }

    /**
     * Verilen bağlantıdan veya metinden 'list' parametresini (ör. LM, VLLM, PL...) ayıklar.
     */
    fun extractPlaylistId(input: String): String? {
        val trimmed = input.trim()
        for (pattern in PLAYLIST_ID_PATTERNS) {
            val matcher = pattern.matcher(trimmed)
            if (matcher.find()) {
                return matcher.group(1)
            }
        }
        return null
    }

    /**
     * Verilen metin veya linkten 11 haneli YouTube video ID'sini ayıklar.
     * Eğer girdi doğrudan bir playlist bağlantısıysa ("playlist?list=...") null döner.
     */
    fun extractVideoId(input: String): String? {
        val trimmed = input.trim()
        if (trimmed.contains("playlist?list=", ignoreCase = true)) {
            return null
        }
        for (pattern in VIDEO_ID_PATTERNS) {
            val matcher = pattern.matcher(trimmed)
            if (matcher.find()) {
                return matcher.group(1)
            }
        }
        return null
    }

    /**
     * Çerez dizesinden SAPISID veya __Secure-3PAPISID değerini ayıklar.
     */
    fun extractSapisid(cookies: String?): String? {
        if (cookies.isNullOrBlank()) return null
        val patterns = listOf(
            Regex("(?:^|;\\s*)SAPISID=([^;\\s]+)"),
            Regex("(?:^|;\\s*)__Secure-3PAPISID=([^;\\s]+)"),
            Regex("(?:^|;\\s*)__Secure-1PAPISID=([^;\\s]+)")
        )
        for (regex in patterns) {
            val match = regex.find(cookies)
            if (match != null) {
                return match.groupValues[1].trim()
            }
        }
        return null
    }

    /**
     * Verilen girdinin SHA-1 özetini küçük harf hex dizesi olarak üretir.
     */
    fun sha1Hex(input: String): String {
        val md = MessageDigest.getInstance("SHA-1")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * Çerez dizisi içerisindeki SAPISID veya __Secure-3PAPISID üzerinden
     * YouTube Music InnerTube API'si için dinamik SHA-1 imzasını (SAPISIDHASH) üretir:
     * Format: "SAPISIDHASH " + timestamp + "_" + sha1Hex(timestamp + " " + sapisid + " " + "https://music.youtube.com")
     */
    fun generateSapisidHash(cookies: String?, origin: String = YOUTUBE_MUSIC_ORIGIN): String? {
        val sapisid = extractSapisid(cookies) ?: return null
        return try {
            val timestamp = System.currentTimeMillis() / 1000L
            val hash = sha1Hex("$timestamp $sapisid $origin")
            "SAPISIDHASH ${timestamp}_$hash"
        } catch (e: Exception) {
            Log.e(TAG, "SAPISIDHASH üretilirken hata oluştu: ${e.message}")
            null
        }
    }

    /**
     * YouTube Music InnerTube istekleri için standart kimlik doğrulama ve istemci başlıklarını uygular.
     */
    fun applyInnerTubeHeaders(
        conn: HttpURLConnection,
        cookies: String?,
        clientNameHeader: String = WEB_REMIX_CLIENT_NAME,
        clientVersionHeader: String = WEB_REMIX_CLIENT_VERSION,
        userAgent: String = YOUTUBE_WEB_REMIX_USER_AGENT
    ) {
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        conn.setRequestProperty("User-Agent", userAgent)
        conn.setRequestProperty("Origin", YOUTUBE_MUSIC_ORIGIN)
        conn.setRequestProperty("Referer", YOUTUBE_MUSIC_REFERER)
        conn.setRequestProperty("X-Origin", YOUTUBE_MUSIC_ORIGIN)
        conn.setRequestProperty("X-YouTube-Client-Name", clientNameHeader)
        conn.setRequestProperty("X-YouTube-Client-Version", clientVersionHeader)
        conn.setRequestProperty("X-Goog-AuthUser", "0")

        if (!cookies.isNullOrBlank()) {
            conn.setRequestProperty("Cookie", cookies)
            val sapisidHash = generateSapisidHash(cookies, YOUTUBE_MUSIC_ORIGIN)
            if (sapisidHash != null) {
                conn.setRequestProperty("Authorization", sapisidHash)
            }
        }
    }

    /**
     * YouTube oEmbed API'si üzerinden video başlığı, sanatçı/kanal ve kapak görselini çeker.
     */
    suspend fun fetchMetadataFromOEmbed(videoId: String): MediaTrackInfo? = withContext(Dispatchers.IO) {
        val oEmbedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json"
        var conn: HttpURLConnection? = null
        try {
            val url = URL(oEmbedUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("User-Agent", YOUTUBE_WEB_REMIX_USER_AGENT)
                setRequestProperty("Referer", YOUTUBE_MUSIC_REFERER)
            }

            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)

                val rawTitle = json.optString("title", "YouTube Ses Parçası")
                val author = json.optString("author_name", "Bilinmeyen Sanatçı")
                val thumb = json.optString("thumbnail_url", "https://i.ytimg.com/vi/$videoId/hqdefault.jpg")

                val parsedArtist: String
                val parsedTitle: String
                if (rawTitle.contains(" - ")) {
                    val parts = rawTitle.split(" - ", limit = 2)
                    parsedArtist = parts[0].trim()
                    parsedTitle = parts[1].replace(
                        Regex("\\((Official|Audio|Video|Lyrics|HD|4K)[^)]*\\)", RegexOption.IGNORE_CASE),
                        ""
                    ).trim()
                } else {
                    parsedArtist = author.removeSuffix(" - Topic").trim()
                    parsedTitle = rawTitle
                }

                return@withContext MediaTrackInfo(
                    videoId = videoId,
                    title = parsedTitle,
                    artist = parsedArtist,
                    durationSeconds = 210L,
                    thumbnailUrl = thumb,
                    sourceUrl = "https://music.youtube.com/watch?v=$videoId"
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "oEmbed çekilemedi ($videoId): ${e.message}")
        } finally {
            conn?.disconnect()
        }

        return@withContext MediaTrackInfo(
            videoId = videoId,
            title = "YouTube Parçası ($videoId)",
            artist = "YouTube Music",
            durationSeconds = 180L,
            thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            sourceUrl = "https://music.youtube.com/watch?v=$videoId"
        )
    }

    /**
     * LocalDownloadManager.fetchInnerTubeBrowseIds mantığını kullanarak
     * verilen oynatma listesi (ör. LM / VLLM Beğenilenler veya PL... kullanıcı listeleri)
     * içerisindeki videoId'leri ve şarkı bilgilerini InnerTube '/youtubei/v1/browse' uç noktasından çözümler.
     */
    suspend fun fetchInnerTubeBrowseIds(
        playlistId: String,
        cookies: String? = null
    ): List<String> = withContext(Dispatchers.IO) {
        val result = resolvePlaylistTracks(playlistId, cookies)
        result.tracks.map { it.videoId }
    }

    /**
     * Oynatma listesi kimliğini (LM, VLLM, PL..., OLAK5uy_...) InnerTube Browse API üzerinden
     * çözümleyerek listedeki tüm şarkıları MediaTrackInfo listesi olarak döner.
     */
    suspend fun resolvePlaylistTracks(
        playlistId: String,
        cookies: String? = null,
        onPartialTracksLoaded: (suspend (List<MediaTrackInfo>) -> Unit)? = null
    ): PlaylistResolutionResult = withContext(Dispatchers.IO) {
        val cleanId = playlistId.trim()
        val browseId = when {
            cleanId.equals("LM", ignoreCase = true) || cleanId.equals("VLLM", ignoreCase = true) -> "VLLM"
            cleanId.startsWith("VL") -> cleanId
            else -> "VL$cleanId"
        }

        val diagnostics = mutableListOf<String>()
        val extractedTracks = LinkedHashMap<String, MediaTrackInfo>()
        val rawVideoIds = LinkedHashSet<String>()
        var playlistTitle = if (browseId == "VLLM") "Beğenilen Şarkılar (LM)" else "Oynatma Listesi ($cleanId)"

        // 1. Adım: InnerTube /youtubei/v1/browse (WEB_REMIX - Client 67)
        var conn: HttpURLConnection? = null
        try {
            val endpoint = "https://music.youtube.com/youtubei/v1/browse?prettyPrint=false"
            conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 15000
                requestMethod = "POST"
                doOutput = true
                applyInnerTubeHeaders(
                    conn = this,
                    cookies = cookies,
                    clientNameHeader = WEB_REMIX_CLIENT_NAME,
                    clientVersionHeader = WEB_REMIX_CLIENT_VERSION,
                    userAgent = YOUTUBE_WEB_REMIX_USER_AGENT
                )
            }

            val body = JSONObject().apply {
                put("context", JSONObject().apply {
                    put("client", JSONObject().apply {
                        put("clientName", "WEB_REMIX")
                        put("clientVersion", WEB_REMIX_CLIENT_VERSION)
                        put("hl", "tr")
                        put("gl", "TR")
                    })
                })
                put("browseId", browseId)
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }

            val code = conn.responseCode
            if (code == HttpURLConnection.HTTP_OK) {
                val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                val rootJson = JSONObject(responseText)

                // Yapılandırılmış JSON ağacından parçaları çıkar
                extractTracksFromInnerTubeJson(rootJson, extractedTracks)

                // Ayrıca tüm videoId eşleşmelerini yakala (fetchInnerTubeBrowseIds mantığı)
                val idMatcher = Pattern.compile("\"videoId\"\\s*:\\s*\"([a-zA-Z0-9_-]{11})\"").matcher(responseText)
                while (idMatcher.find()) {
                    val vid = idMatcher.group(1)
                    if (!vid.isNullOrBlank()) {
                        rawVideoIds.add(vid)
                    }
                }
            } else {
                diagnostics.add("BROWSE_HTTP_$code")
            }
        } catch (e: Exception) {
            diagnostics.add("BROWSE_EX:${e.javaClass.simpleName}")
            Log.e(TAG, "InnerTube browse hatası ($browseId): ${e.message}", e)
        } finally {
            conn?.disconnect()
        }

        // 2. Adım: Eğer browse boş döndüyse InnerTube /youtubei/v1/next (playlistId ile) dene
        if (extractedTracks.isEmpty() && rawVideoIds.isEmpty()) {
            var nextConn: HttpURLConnection? = null
            try {
                val rawListId = cleanId.removePrefix("VL")
                val endpoint = "https://music.youtube.com/youtubei/v1/next?prettyPrint=false"
                nextConn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000
                    readTimeout = 12000
                    requestMethod = "POST"
                    doOutput = true
                    applyInnerTubeHeaders(
                        conn = this,
                        cookies = cookies,
                        clientNameHeader = WEB_REMIX_CLIENT_NAME,
                        clientVersionHeader = WEB_REMIX_CLIENT_VERSION,
                        userAgent = YOUTUBE_WEB_REMIX_USER_AGENT
                    )
                }

                val body = JSONObject().apply {
                    put("context", JSONObject().apply {
                        put("client", JSONObject().apply {
                            put("clientName", "WEB_REMIX")
                            put("clientVersion", WEB_REMIX_CLIENT_VERSION)
                            put("hl", "tr")
                            put("gl", "TR")
                        })
                    })
                    put("playlistId", rawListId)
                }

                OutputStreamWriter(nextConn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(body.toString())
                    writer.flush()
                }

                if (nextConn.responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = nextConn.inputStream.bufferedReader().use { it.readText() }
                    val rootJson = JSONObject(responseText)
                    extractTracksFromInnerTubeJson(rootJson, extractedTracks)

                    val idMatcher = Pattern.compile("\"videoId\"\\s*:\\s*\"([a-zA-Z0-9_-]{11})\"").matcher(responseText)
                    while (idMatcher.find()) {
                        val vid = idMatcher.group(1)
                        if (!vid.isNullOrBlank()) {
                            rawVideoIds.add(vid)
                        }
                    }
                } else {
                    diagnostics.add("NEXT_HTTP_${nextConn.responseCode}")
                }
            } catch (e: Exception) {
                diagnostics.add("NEXT_EX:${e.javaClass.simpleName}")
            } finally {
                nextConn?.disconnect()
            }
        }

        // 3. Adım: Hala boşsa standart YouTube Playlist Web sayfasından videoId'leri kazı
        if (extractedTracks.isEmpty() && rawVideoIds.isEmpty()) {
            var webConn: HttpURLConnection? = null
            try {
                val rawListId = cleanId.removePrefix("VL")
                val webUrl = "https://www.youtube.com/playlist?list=$rawListId"
                webConn = (URL(webUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000
                    readTimeout = 10000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", YOUTUBE_WEB_REMIX_USER_AGENT)
                    if (!cookies.isNullOrBlank()) {
                        setRequestProperty("Cookie", cookies)
                    }
                }
                if (webConn.responseCode == HttpURLConnection.HTTP_OK) {
                    val html = webConn.inputStream.bufferedReader().use { it.readText() }
                    val idMatcher = Pattern.compile("\"videoId\":\"([a-zA-Z0-9_-]{11})\"").matcher(html)
                    while (idMatcher.find()) {
                        val vid = idMatcher.group(1)
                        if (!vid.isNullOrBlank()) {
                            rawVideoIds.add(vid)
                        }
                    }
                }
            } catch (e: Exception) {
                diagnostics.add("WEB_EX:${e.javaClass.simpleName}")
            } finally {
                webConn?.disconnect()
            }
        }

        // 4. Adım: Yapılandırılmış verisi olmayan videoId'leri oEmbed ile tek tek çözümle
        if (extractedTracks.isNotEmpty()) {
            onPartialTracksLoaded?.invoke(extractedTracks.values.toList())
        }

        val missingIds = rawVideoIds.filter { !extractedTracks.containsKey(it) }.take(40)
        for (vid in missingIds) {
            val resolved = fetchMetadataFromOEmbed(vid)
            if (resolved != null) {
                extractedTracks[vid] = resolved
                onPartialTracksLoaded?.invoke(extractedTracks.values.toList())
            }
        }

        val finalTracks = extractedTracks.values.toList()
        if (finalTracks.isEmpty()) {
            val hasSapisid = extractSapisid(cookies) != null
            val errCode = if (!hasSapisid && (browseId == "VLLM" || cleanId == "LM")) {
                "ERR_PLAYLIST_AUTH_REQUIRED"
            } else {
                "ERR_PLAYLIST_EMPTY"
            }
            val errDetail = if (!hasSapisid && (browseId == "VLLM" || cleanId == "LM")) {
                "[$errCode] Beğenilen Şarkılar (LM) özel bir listedir. Çözümlemek için Ayarlar'dan YouTube Music oturum çerezlerinizi (SAPISID) kaydedin."
            } else {
                "[$errCode] Oynatma listesi ($cleanId) çözümlenemedi veya gizli. Detay: ${diagnostics.joinToString(", ").ifEmpty { "Parça bulunamadı" }}"
            }
            return@withContext PlaylistResolutionResult(
                playlistId = cleanId,
                playlistTitle = playlistTitle,
                tracks = emptyList(),
                errorCode = errCode,
                errorDetail = errDetail
            )
        }

        return@withContext PlaylistResolutionResult(
            playlistId = cleanId,
            playlistTitle = playlistTitle,
            tracks = finalTracks
        )
    }

    /**
     * InnerTube Browse veya Next JSON yanıt ağacındaki musicResponsiveListItemRenderer,
     * playlistVideoRenderer ve playlistPanelVideoRenderer öğelerini özyinelemeli (recursive) tarar.
     */
    private fun extractTracksFromInnerTubeJson(
        node: Any?,
        outMap: LinkedHashMap<String, MediaTrackInfo>
    ) {
        when (node) {
            is JSONObject -> {
                if (node.has("musicResponsiveListItemRenderer")) {
                    val item = node.optJSONObject("musicResponsiveListItemRenderer")
                    if (item != null) {
                        parseMusicResponsiveListItem(item)?.let { track ->
                            if (!outMap.containsKey(track.videoId)) {
                                outMap[track.videoId] = track
                            }
                        }
                    }
                }
                if (node.has("playlistVideoRenderer")) {
                    val item = node.optJSONObject("playlistVideoRenderer")
                    if (item != null) {
                        parsePlaylistVideoRenderer(item)?.let { track ->
                            if (!outMap.containsKey(track.videoId)) {
                                outMap[track.videoId] = track
                            }
                        }
                    }
                }
                if (node.has("playlistPanelVideoRenderer")) {
                    val item = node.optJSONObject("playlistPanelVideoRenderer")
                    if (item != null) {
                        parsePlaylistPanelVideoRenderer(item)?.let { track ->
                            if (!outMap.containsKey(track.videoId)) {
                                outMap[track.videoId] = track
                            }
                        }
                    }
                }

                val keys = node.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    extractTracksFromInnerTubeJson(node.opt(key), outMap)
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    extractTracksFromInnerTubeJson(node.opt(i), outMap)
                }
            }
        }
    }

    private fun parseMusicResponsiveListItem(item: JSONObject): MediaTrackInfo? {
        val videoId = item.optJSONObject("playlistItemData")?.optString("videoId", "")
            ?.takeIf { it.length == 11 }
            ?: findFirstVideoIdInJson(item)
            ?: return null

        var title = ""
        var artist = ""

        val flexColumns = item.optJSONArray("flexColumns")
        if (flexColumns != null && flexColumns.length() > 0) {
            val col0Runs = flexColumns.optJSONObject(0)
                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")
            if (col0Runs != null && col0Runs.length() > 0) {
                title = col0Runs.optJSONObject(0)?.optString("text", "") ?: ""
            }

            if (flexColumns.length() > 1) {
                val col1Runs = flexColumns.optJSONObject(1)
                    ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                    ?.optJSONObject("text")
                    ?.optJSONArray("runs")
                if (col1Runs != null && col1Runs.length() > 0) {
                    artist = col1Runs.optJSONObject(0)?.optString("text", "") ?: ""
                }
            }
        }

        if (title.isBlank()) return null
        if (artist.isBlank()) artist = "YouTube Music"

        return MediaTrackInfo(
            videoId = videoId,
            title = title,
            artist = artist,
            durationSeconds = 210L,
            thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            sourceUrl = "https://music.youtube.com/watch?v=$videoId"
        )
    }

    private fun parsePlaylistVideoRenderer(item: JSONObject): MediaTrackInfo? {
        val videoId = item.optString("videoId", "").takeIf { it.length == 11 } ?: return null
        val title = item.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text", "")
            ?: item.optJSONObject("title")?.optString("simpleText", "")
            ?: return null
        val artist = item.optJSONObject("shortBylineText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text", "")
            ?: "YouTube Music"
        val durationSec = item.optString("lengthSeconds", "200").toLongOrNull() ?: 200L

        return MediaTrackInfo(
            videoId = videoId,
            title = title,
            artist = artist.removeSuffix(" - Topic").trim(),
            durationSeconds = durationSec,
            thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            sourceUrl = "https://music.youtube.com/watch?v=$videoId"
        )
    }

    private fun parsePlaylistPanelVideoRenderer(item: JSONObject): MediaTrackInfo? {
        val videoId = item.optString("videoId", "").takeIf { it.length == 11 } ?: return null
        val title = item.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text", "")
            ?: item.optJSONObject("title")?.optString("simpleText", "")
            ?: return null
        val artist = item.optJSONObject("longBylineText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text", "")
            ?: item.optJSONObject("shortBylineText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text", "")
            ?: "YouTube Music"

        return MediaTrackInfo(
            videoId = videoId,
            title = title,
            artist = artist.removeSuffix(" - Topic").trim(),
            durationSeconds = 200L,
            thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            sourceUrl = "https://music.youtube.com/watch?v=$videoId"
        )
    }

    private fun findFirstVideoIdInJson(obj: JSONObject): String? {
        val raw = obj.toString()
        val matcher = Pattern.compile("\"videoId\"\\s*:\\s*\"([a-zA-Z0-9_-]{11})\"").matcher(raw)
        return if (matcher.find()) matcher.group(1) else null
    }

    /**
     * YouTube arama sorgusunu çalıştırıp eşleşen parçaları döner.
     */
    suspend fun searchYouTube(query: String, cookies: String? = null): List<MediaTrackInfo> = withContext(Dispatchers.IO) {
        val results = mutableListOf<MediaTrackInfo>()
        var conn: HttpURLConnection? = null
        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val searchUrl = "https://www.youtube.com/results?search_query=$encodedQuery+audio"

            val url = URL(searchUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("User-Agent", YOUTUBE_WEB_REMIX_USER_AGENT)
                setRequestProperty("Referer", YOUTUBE_MUSIC_REFERER)
                setRequestProperty("Origin", YOUTUBE_MUSIC_ORIGIN)
                if (!cookies.isNullOrBlank()) {
                    setRequestProperty("Cookie", cookies)
                }
            }

            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val html = conn.inputStream.bufferedReader().use { it.readText() }

                val idMatcher = Pattern.compile("\"videoId\":\"([a-zA-Z0-9_-]{11})\"").matcher(html)
                val titleMatcher = Pattern.compile("\"title\":\\{\"runs\":\\[\\{\"text\":\"([^\"]+)\"\\}").matcher(html)

                val ids = mutableListOf<String>()
                while (idMatcher.find()) {
                    val id = idMatcher.group(1)
                    if (id != null && !ids.contains(id)) {
                        ids.add(id)
                    }
                }

                val titles = mutableListOf<String>()
                while (titleMatcher.find()) {
                    val title = titleMatcher.group(1)
                    if (title != null) {
                        titles.add(title)
                    }
                }

                val count = minOf(ids.size, titles.size, 15)
                for (i in 0 until count) {
                    val vid = ids[i]
                    val rawTitle = titles[i]

                    var artistName = "YouTube Music"
                    var trackTitle = rawTitle
                    if (rawTitle.contains(" - ")) {
                        val parts = rawTitle.split(" - ", limit = 2)
                        artistName = parts[0].trim()
                        trackTitle = parts[1].replace(
                            Regex("\\((Official|Audio|Video|Lyrics|HD|4K)[^)]*\\)", RegexOption.IGNORE_CASE),
                            ""
                        ).trim()
                    }

                    results.add(
                        MediaTrackInfo(
                            videoId = vid,
                            title = trackTitle,
                            artist = artistName,
                            durationSeconds = 200L,
                            thumbnailUrl = "https://i.ytimg.com/vi/$vid/hqdefault.jpg",
                            sourceUrl = "https://music.youtube.com/watch?v=$vid"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Arama hatası ($query): ${e.message}", e)
        } finally {
            conn?.disconnect()
        }

        return@withContext results
    }

    /**
     * Geriye dönük uyumlu ses akış URL'si çözümleyici.
     */
    suspend fun resolveAudioStreamUrl(
        videoId: String,
        cookies: String? = null
    ): String? = withContext(Dispatchers.IO) {
        resolveAudioStreamWithDiagnostics(videoId, cookies).streamUrl
    }

    /**
     * Çerezleri (SAPISID, __Secure-3PAPISID, LOGIN_INFO) ve dinamik SAPISIDHASH başlığını kullanarak
     * ses akışını çözümler. Çözümlenemediğinde çökmek yerine detaylı hata kodu ve tanı mesajı döner.
     */
    suspend fun resolveAudioStreamWithDiagnostics(
        videoId: String,
        cookies: String? = null
    ): StreamResolutionResult = withContext(Dispatchers.IO) {
        val diagnostics = mutableListOf<String>()
        val hasCookies = !cookies.isNullOrBlank()
        val hasSapisid = extractSapisid(cookies) != null
        val hasLoginInfo = cookies?.contains("LOGIN_INFO=", ignoreCase = true) == true

        Log.d(
            TAG,
            "Akış çözümleme başlatıldı ($videoId) | Cookie: $hasCookies | SAPISID: $hasSapisid | LOGIN_INFO: $hasLoginInfo"
        )

        // 1. Strateji: WEB_REMIX (X-YouTube-Client-Name: 67, X-YouTube-Client-Version: 1.20260101.01.00 + SAPISIDHASH)
        val webRemixAttempt = queryInnertubePlayer(
            endpoint = "https://music.youtube.com/youtubei/v1/player?prettyPrint=false",
            videoId = videoId,
            clientName = "WEB_REMIX",
            clientVersion = WEB_REMIX_CLIENT_VERSION,
            clientNameHeader = WEB_REMIX_CLIENT_NAME,
            userAgent = YOUTUBE_WEB_REMIX_USER_AGENT,
            cookies = cookies
        )
        if (webRemixAttempt.isSuccess) {
            return@withContext webRemixAttempt
        } else {
            diagnostics.add("WEB_REMIX:${webRemixAttempt.errorCode ?: "FAIL"}")
        }

        // 2. Strateji: ANDROID_VR (Şifresiz doğrudan akış URL'si sağlar + SAPISIDHASH desteği)
        val vrAttempt = queryInnertubePlayer(
            endpoint = "https://music.youtube.com/youtubei/v1/player?prettyPrint=false",
            videoId = videoId,
            clientName = "ANDROID_VR",
            clientVersion = "1.60.19",
            clientNameHeader = "28",
            userAgent = "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            cookies = cookies
        )
        if (vrAttempt.isSuccess) {
            return@withContext vrAttempt
        } else {
            diagnostics.add("ANDROID_VR:${vrAttempt.errorCode ?: "FAIL"}")
        }

        // 3. Strateji: ANDROID İstemcisi (YouTube Android 19.47.53)
        val androidAttempt = queryInnertubePlayer(
            endpoint = "https://music.youtube.com/youtubei/v1/player?prettyPrint=false",
            videoId = videoId,
            clientName = "ANDROID",
            clientVersion = "19.47.53",
            clientNameHeader = "3",
            userAgent = YOUTUBE_ANDROID_USER_AGENT,
            cookies = cookies,
            androidSdkVersion = 34
        )
        if (androidAttempt.isSuccess) {
            return@withContext androidAttempt
        } else {
            diagnostics.add("ANDROID:${androidAttempt.errorCode ?: "FAIL"}")
        }

        // 4. Strateji: IOS İstemcisi
        val iosAttempt = queryInnertubePlayer(
            endpoint = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false",
            videoId = videoId,
            clientName = "IOS",
            clientVersion = "19.45.4",
            clientNameHeader = "5",
            userAgent = "com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)",
            cookies = cookies
        )
        if (iosAttempt.isSuccess) {
            return@withContext iosAttempt
        } else {
            diagnostics.add("IOS:${iosAttempt.errorCode ?: "FAIL"}")
        }

        val primaryCode = when {
            !hasCookies -> "ERR_NO_COOKIES"
            !hasSapisid -> "ERR_SAPISID_MISSING"
            else -> webRemixAttempt.errorCode ?: "ERR_STREAM_UNAVAILABLE"
        }

        val detailMsg = buildString {
            append("[$primaryCode] ")
            if (!hasCookies) {
                append("Kayıtlı oturum çerezi bulunamadı. Ayarlar > YouTube Music Oturumu ekranından giriş yapıp 'Çerezleri Kaydet ve Tamamla' butonuna basın.")
            } else if (!hasSapisid) {
                append("Çerezlerde SAPISID / __Secure-3PAPISID bulunamadı. Lütfen YouTube Music'te oturum açtığınızdan emin olun.")
            } else {
                append(webRemixAttempt.errorDetail ?: "Ses akışı çözümlenemedi.")
            }
            append(" (Log: ${diagnostics.joinToString(" | ")})")
        }

        Log.e(TAG, "Tüm akış çözümleme stratejileri başarısız oldu: $detailMsg")
        return@withContext StreamResolutionResult(
            streamUrl = null,
            errorCode = primaryCode,
            errorDetail = detailMsg
        )
    }

    private fun queryInnertubePlayer(
        endpoint: String,
        videoId: String,
        clientName: String,
        clientVersion: String,
        clientNameHeader: String,
        userAgent: String,
        cookies: String?,
        androidSdkVersion: Int? = null
    ): StreamResolutionResult {
        var conn: HttpURLConnection? = null
        try {
            val url = URL(endpoint)
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                requestMethod = "POST"
                doOutput = true
                applyInnerTubeHeaders(
                    conn = this,
                    cookies = cookies,
                    clientNameHeader = clientNameHeader,
                    clientVersionHeader = clientVersion,
                    userAgent = userAgent
                )
            }

            val clientObj = JSONObject().apply {
                put("clientName", clientName)
                put("clientVersion", clientVersion)
                put("hl", "tr")
                put("gl", "TR")
                if (androidSdkVersion != null) {
                    put("androidSdkVersion", androidSdkVersion)
                }
            }

            val body = JSONObject().apply {
                put("context", JSONObject().apply {
                    put("client", clientObj)
                })
                put("videoId", videoId)
                put("playbackContext", JSONObject().apply {
                    put("contentPlaybackContext", JSONObject().apply {
                        put("html5Preference", "HTML5_PREF_WANTS")
                    })
                })
                put("contentCheckOk", true)
                put("racyCheckOk", true)
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }

            val responseCode = conn.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                return StreamResolutionResult(
                    errorCode = "ERR_HTTP_$responseCode",
                    errorDetail = "InnerTube Player HTTP $responseCode döndü ($clientName)"
                )
            }

            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val rootJson = JSONObject(response)

            val playability = rootJson.optJSONObject("playabilityStatus")
            val status = playability?.optString("status", "UNKNOWN") ?: "UNKNOWN"
            val reason = playability?.optString("reason", "") ?: ""

            if (!rootJson.has("streamingData")) {
                return StreamResolutionResult(
                    errorCode = "ERR_PLAYABILITY_$status",
                    errorDetail = if (reason.isNotBlank()) "$status: $reason" else "streamingData bulunamadı ($status)"
                )
            }

            val streamingData = rootJson.getJSONObject("streamingData")
            val adaptiveFormats = streamingData.optJSONArray("adaptiveFormats")
            val standardFormats = streamingData.optJSONArray("formats")

            var bestUrl: String? = null
            var bestMime: String? = null
            var highestBitrate = 0
            var bestContentLength = 0L
            var sawCipherOnly = false

            fun scanFormatsArray(formats: JSONArray?) {
                if (formats == null) return
                for (i in 0 until formats.length()) {
                    val format = formats.getJSONObject(i)
                    val mime = format.optString("mimeType", "")
                    val itag = format.optInt("itag", 0)
                    val bitrate = format.optInt("bitrate", 0)
                    val contentLen = format.optString("contentLength", "0").toLongOrNull() ?: 0L

                    val isAudioFormat = mime.startsWith("audio/mp4") ||
                            mime.startsWith("audio/webm") ||
                            itag == 140 || itag == 251 || itag == 139 || itag == 250 || itag == 249

                    if (isAudioFormat) {
                        var streamUrl = format.optString("url", null)
                        if (streamUrl.isNullOrBlank()) {
                            val cipher = format.optString("signatureCipher", format.optString("cipher", null))
                            if (!cipher.isNullOrBlank()) {
                                val extracted = extractUrlFromCipher(cipher)
                                // Eğer s= parametresi varsa şifreli imzadır, doğrudan indirilemez
                                if (cipher.contains("s=")) {
                                    sawCipherOnly = true
                                } else {
                                    streamUrl = extracted
                                }
                            }
                        }

                        if (!streamUrl.isNullOrBlank() && bitrate >= highestBitrate) {
                            highestBitrate = bitrate
                            bestUrl = streamUrl
                            bestMime = mime
                            bestContentLength = contentLen
                        }
                    }
                }
            }

            scanFormatsArray(adaptiveFormats)
            if (bestUrl.isNullOrBlank()) {
                scanFormatsArray(standardFormats)
            }

            if (!bestUrl.isNullOrBlank()) {
                // Eğer JSON içinde contentLength >= 256 KB olarak bildirilmişse veya doğrulama başarılıysa kabul et
                val isValid = if (bestContentLength >= MIN_VALID_AUDIO_BYTES) {
                    true
                } else {
                    validateAudioStream(bestUrl!!, cookies)
                }

                if (isValid) {
                    Log.d(TAG, "Ses akışı çözüldü ($clientName): Bitrate=$highestBitrate | Boyut=$bestContentLength")
                    return StreamResolutionResult(
                        streamUrl = bestUrl,
                        mimeType = bestMime,
                        bitrate = highestBitrate,
                        contentLength = bestContentLength
                    )
                } else {
                    return StreamResolutionResult(
                        errorCode = "ERR_VALIDATION_FAILED",
                        errorDetail = "Akış URL doğrulaması başarısız ($clientName)"
                    )
                }
            }

            if (sawCipherOnly) {
                return StreamResolutionResult(
                    errorCode = "ERR_SIGNATURE_CIPHER",
                    errorDetail = "$clientName istemcisi şifreli imza (signatureCipher) döndürdü"
                )
            }

            return StreamResolutionResult(
                errorCode = "ERR_NO_AUDIO_FORMAT",
                errorDetail = "Uygun ses formatı (itag 140/251) bulunamadı ($status)"
            )
        } catch (e: Exception) {
            Log.w(TAG, "queryInnertubePlayer istisnası ($clientName): ${e.message}")
            return StreamResolutionResult(
                errorCode = "ERR_NETWORK_${e.javaClass.simpleName}",
                errorDetail = e.message ?: "Ağ bağlantı hatası"
            )
        } finally {
            conn?.disconnect()
        }
    }

    private fun extractUrlFromCipher(cipher: String): String? {
        val pairs = cipher.split("&")
        for (pair in pairs) {
            val parts = pair.split("=", limit = 2)
            if (parts.size == 2 && parts[0] == "url") {
                return URLDecoder.decode(parts[1], "UTF-8")
            }
        }
        return null
    }

    /**
     * Boyut ve MIME Kontrolü: Range: bytes=0-1023 GET isteğiyle akışın gerçek bir ses dosyası olduğunu doğrular.
     * 173 KB'lık HTML/JSON hata yanıtlarını reddeder.
     */
    fun validateAudioStream(streamUrl: String, cookies: String?): Boolean {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(streamUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("Range", "bytes=0-1023")
                setRequestProperty("User-Agent", YOUTUBE_WEB_REMIX_USER_AGENT)
                setRequestProperty("Referer", YOUTUBE_MUSIC_REFERER)
                setRequestProperty("Origin", YOUTUBE_MUSIC_ORIGIN)
                if (!cookies.isNullOrBlank()) {
                    setRequestProperty("Cookie", cookies)
                }
            }

            val code = conn.responseCode
            val contentType = conn.contentType ?: ""
            val contentRange = conn.getHeaderField("Content-Range")
            val totalLength = if (!contentRange.isNullOrBlank() && contentRange.contains("/")) {
                contentRange.substringAfterLast("/").toLongOrNull() ?: conn.contentLengthLong
            } else {
                conn.contentLengthLong
            }

            Log.d(TAG, "Akış Doğrulama: HTTP $code | Toplam Boyut: $totalLength | MIME: $contentType")

            if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                return false
            }

            if (contentType.contains("text/html", ignoreCase = true) ||
                contentType.contains("application/json", ignoreCase = true)
            ) {
                return false
            }

            if (totalLength in 1 until MIN_VALID_AUDIO_BYTES) {
                return false
            }

            true
        } catch (e: Exception) {
            Log.w(TAG, "Akış doğrulama sırasında istisna: ${e.message}")
            false
        } finally {
            conn?.disconnect()
        }
    }
}
