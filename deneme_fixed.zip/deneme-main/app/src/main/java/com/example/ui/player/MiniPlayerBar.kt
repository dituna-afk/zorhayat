package com.example.ui.player

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.paint.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.rememberViewModel
import com.example.player.PlayerState
import com.example.viewmodel.MusicUiState
import com.example.viewmodel.MusicPlayerViewModel
import kotlinx.coroutines.flow.*

/**
 * Mini player bar - Tam ekranda iken altta görünen mini oynatıcı
 * Şarkı değiştiğinde veya kullanıcı aşağı kaydığında görünür
 */
@Composable
fun MiniPlayerBar(
    onPlayPauseClick: () -> Unit = {},
    onNextClick: () -> Unit = {},
    onPrevClick: () -> Unit = {},
    isExpanded: Boolean = false,
    expandClick: (() -> Unit) = {}
) {
    val viewModel: MusicPlayerViewModel = rememberViewModel()
    val playerState by viewModel.playerState.collectAsState()
    val uiState by viewModel.musicUiState.collectAsState()
    
    // Mini player animasyon state
    var animate by remember { mutableStateOf(false) }
    val miniAnim = remember { Animatable(1f) }
    val expandedAnim = remember { Animatable(0f) }
    
    // Animasyonları tetikle
    LaunchedEffect(Unit) {
        if (isExpanded) {
            miniAnim.animateTo(0f)
            expandedAnim.animateTo(1f)
        } else {
            miniAnim.animateTo(1f)
            expandedAnim.animateTo(0f)
        }
    }
    
    val miniProgress by animateAsState(miniAnim) { it }
    val expandedProgress by animateAsState(expandedAnim) { it }
    
    // Mini player kartı
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(isExpanded ? 120.dp : 56.dp)
            .background(
                Brush.solid(
                    Color(0xFF1A0F2B) // Dark purple background
                )
            )
            .shadow(
                shadowColor = Color(0x66000000),
                shape = RoundedCornerShape(isExpanded ? 16.dp : 20.dp),
                elevation = if (isExpanded) 8.dp else 4.dp
            )
            .padding(8.dp)
            .clip(RoundedCornerShape(isExpanded ? 16.dp : 20.dp))
    ) {
        // İkon ve şarkı bilgileri satırı
        Row(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Önceki şarkı butonu
            IconButton(
                onClick = onPrevClick,
                enabled = playerState.currentTrackIndex > 0
            ) {
                Icon(
                    imageVector = Icons.Filled.SkipPrevious,
                    contentDescription = null,
                    tint = Color(0xFFFFFFFF),
                    size = 20.dp
                )
            }
            
            // Şarkı adı ve sanatçı
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = playerState.currentTrack?.title ?: "Şarkı yok",
                    style = MaterialTheme.typography.body1,
                    color = Color(0xFFFFFFFF),
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1
                )
                
                Text(
                    text = playerState.currentTrack?.artist ?: "Bilinmeyen sanatçı",
                    style = MaterialTheme.typography.caption,
                    color = Color(0xFFAAAAAA),
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            // Duraklat/Çalma butonu
            IconButton(onClick = onPlayPauseClick) {
                Icon(
                    imageVector = if (playerState.isPlaying) {
                        Icons.Filled.Pause
                    } else {
                        Icons.Filled.PlayArrow
                    },
                    contentDescription = null,
                    tint = Color(0xFFFFFFFF),
                    size = 24.dp
                )
            }
            
            // Sonraki şarkı butonu
            IconButton(onClick = onNextClick) {
                Icon(
                    imageVector = Icons.Filled.SkipNext,
                    contentDescription = null,
                    tint = Color(0xFFFFFFFF),
                    size = 20.dp
                )
            }
        }
    }
    
    // Progress bar - expanded modunda görünür
    if (expandedProgress > 0.5f) {
        Divider(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp),
            thickness = 1.dp,
            color = Color(0x44000000)
        )
        
        Slider(
            value = if (playerState.isPlaying) {
                playerState.currentPositionMs
                    .coerceAtLeast(0L)
                    .coerceAtMost(
                        (playerState.currentTrack?.durationSeconds ?: 0L) * 1000L
                    )
            } else { 0f },
            onValueChange = { },
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .height(4.dp),
            colors = SliderDefaults.thumbColor(
                defaultThumbColor = Color(0xFFFFFFFF),
                pressedThumbColor = Color(0xFFFF00E5)
            ),
            trackColors = {
                listOf(
                    Color(0x33000000), // inaktif track rengi
                    Color(0x88FF00E5)  // aktif track rengi
                )
            }
        )
    }
    
    // Click area for expanding/collapsing
    clickableArea(animate, onPlayPauseClick)
}

/**
 * Kaydırılabilir alan için clickable extension
 */
private fun clickableArea(
    var animate: Boolean,
    onPlayPauseClick: () -> Unit
) {
    // Mini player'a tıklayarak genişlet/kapat
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.Indeterminate),
        onClick = {
            animate = !animate
        },
        content = {}
    )
}
