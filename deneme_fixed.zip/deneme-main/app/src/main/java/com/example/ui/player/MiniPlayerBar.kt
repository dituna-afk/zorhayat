package com.example.ui.player

import android.util.Log
import androidx.compose.animation.*
import androidx.compose.animation.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.rememberViewModel
import com.example.player.PlayerState
import com.example.viewmodel.MusicPlayerViewModel
import kotlinx.coroutines.flow.*

/**
 * Mini player bar - Tam ekranda iken altta görünen mini oynatıcı
 * Şarkı değiştiğinde veya kullanıcı aşağı kaydığında görünür
 */
@Composable
fun MiniPlayerBar(
    onPlayPauseClick: () -> Unit = {},
    onNextClick: () -> Unit = {},
    onPrevClick: () -> Unit = {},
    isExpanded: Boolean = false,
    onExpandClick: () -> Unit = {}
) {
    val viewModel: MusicPlayerViewModel = rememberViewModel()
    val playerState by viewModel.playerState.collectAsStateWithLifecycle()
    
    // Mini player animasyon state
    val miniAnim = remember { Animatable(if (isExpanded) 0f else 1f) }
    val expandedAnim = remember { Animatable(if (isExpanded) 1f else 0f) }
    
    // Animasyonları tetikle
    LaunchedEffect(isExpanded) {
        if (isExpanded) {
            miniAnim.animateTo(0f)
            expandedAnim.animateTo(1f)
        } else {
            miniAnim.animateTo(1f)
            expandedAnim.animateTo(0f)
        }
    }
    
    val miniProgress by animateFloatAsState(miniAnim)
    val expandedProgress by animateFloatAsState(expandedAnim)
    
    // Mini player kartı
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (expandedProgress > 0.5f) 120.dp else 56.dp)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(Color(0xFF1A0F2B), Color(0xFF2A1A3A))
                )
            )
            .shadow(
                shadowColor = Color(0x66000000),
                shape = RoundedCornerShape(if (expandedProgress > 0.5f) 16.dp else 20.dp),
                elevation = if (expandedProgress > 0.5f) 8.dp else 4.dp
            )
            .padding(8.dp)
            .clip(RoundedCornerShape(if (expandedProgress > 0.5f) 16.dp else 20.dp))
    ) {
        // İkon ve şarkı bilgileri satırı
        Row(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Önceki şarkı butonu
            IconButton(
                onClick = onPrevClick,
                enabled = playerState.currentTrackIndex > 0
            ) {
                Icon(
                    imageVector = Icons.Filled.SkipPrevious,
                    contentDescription = null,
                    tint = Color.White,
                    size = 20.dp
                )
            }
            
            // Şarkı adı ve sanatçı
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = playerState.currentTrack?.title ?: "Şarkı yok",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1
                )
                
                Text(
                    text = playerState.currentTrack?.artist ?: "Bilinmeyen sanatçı",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFAAAAAA),
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            // Duraklat/Çalma butonu
            IconButton(onClick = onPlayPauseClick) {
                Icon(
                    imageVector = if (playerState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    size = 24.dp
                )
            }
            
            // Sonraki şarkı butonu
            IconButton(onClick = onNextClick) {
                Icon(
                    imageVector = Icons.Filled.SkipNext,
                    contentDescription = null,
                    tint = Color.White,
                    size = 20.dp
                )
            }
        }
        
        // Progress bar - expanded modunda görünür
        if (expandedProgress > 0.5f) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Divider(
                    thickness = 1.dp,
                    color = Color(0x44000000)
                )
                
                Slider(
                    value = if (playerState.isPlaying && playerState.currentTrack != null) {
                        val durationMs = (playerState.currentTrack?.durationSeconds ?: 1L) * 1000L
                        (playerState.currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                    } else { 0f },
                    onValueChange = { },
                    modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFF00E5),
                        inactiveTrackColor = Color(0x33000000)
                    )
                )
            }
        }
    }
    
    // Click area for expanding/collapsing
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .clickable { onExpandClick() }
    )
}
