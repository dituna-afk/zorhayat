package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CookieStorageHelper
import com.example.downloader.DownloadListener
import com.example.downloader.DownloadNotificationHelper
import com.example.downloader.DownloadProgress
import com.example.downloader.LyricsProvider
import com.example.downloader.MediaMetadataManager
import com.example.downloader.MediaSaveCallback
import com.example.downloader.MediaTrackInfo
import com.example.downloader.MultiThreadChunkedDownloader
import com.example.downloader.SavedMediaResult
import com.example.downloader.YouTubeStreamResolver
import com.example.downloader.YTDlpResolver
import com.example.model.LyricLine
import com.example.player.LocalDownloadsPlayer
import com.example.player.PlayerState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

import android.net.Uri
import com.example.data.OfflinePlaylistRepository
import com.example.data.ThemeStorageHelper
import com.example.data.UserPlaylist
import com.example.ui.theme.AppTheme

enum class YtMusicTab {
    HOME, SEARCH, LIBRARY, SETTINGS
}

data class MusicUiState(
    val selectedTab: YtMusicTab = YtMusicTab.HOME,
    val isNowPlayingExpanded: Boolean = false,
    val savedTracks: List<SavedMediaResult> = emptyList(),
    val userPlaylists: List<UserPlaylist> = emptyList(),
    val activePlaylistDetailId: String? = null,
    val selectedPlaylist: UserPlaylist? = null,
    val quickPicks: List<MediaTrackInfo> = emptyList(),
    val searchQuery: String = "",
    val searchResults: List<MediaTrackInfo> = emptyList(),
    val resolvedUrlTrack: MediaTrackInfo? = null,
    val resolvedPlaylistId: String? = null,
    val resolvedPlaylistTitle: String? = null,
    val streamErrorDetail: String? = null,
    val isSearching: Boolean = false,
    val isResolving: Boolean = false,
    val selectedFilter: String = "Hepsi",
    val snackbarMessage: String? = null,

    // Tema ve Görünüm Seçimi
    val currentTheme: AppTheme = AppTheme.SAKURA_SAKURA,

    // Parçalı İndirici ve Kuyruk (Canlı Durum)
    val isDownloading: Boolean = false,
    val activeDownloadTitle: String? = null,
    val downloadProgress: DownloadProgress? = null,
    val downloadStatusText: String? = null,
    val pendingQueueCount: Int = 0,

    // Otomatik Beğenilenleri İndirme ve Tercihler
    val isAutoDownloadLiked: Boolean = true,
    val isWifiOnlyDownload: Boolean = false,
    val likedVideoIds: Set<String> = emptySet(),

    // Canlı Senkronize Şarkı Sözleri (LRC)
    val currentLyrics: List<LyricLine> = emptyList(),
    val isLyricsLoading: Boolean = false
)

class MusicPlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val player = LocalDownloadsPlayer.getInstance(application)
    private val metadataManager = MediaMetadataManager(application)
    private val storageHelper = CookieStorageHelper.getInstance(application)
    private val themeHelper = ThemeStorageHelper.getInstance(application)
    private val playlistRepository = OfflinePlaylistRepository.getInstance(application)
    private val notificationHelper = DownloadNotificationHelper(application)

    val playerState: StateFlow<PlayerState> = player.playerState

    private val _uiState = MutableStateFlow(
        MusicUiState(
            currentTheme = themeHelper.getSelectedTheme()
        )
    )
    val uiState: StateFlow<MusicUiState> = _uiState.asStateFlow()

    private var activeDownloader: MultiThreadChunkedDownloader? = null
    private val downloadQueue = ArrayDeque<MediaTrackInfo>()
    private var urlResolutionJob: kotlinx.coroutines.Job? = null
    private var lastLoadedLyricsTrackId: String? = null

    companion object {
        private const val TAG = "MusicPlayerViewModel"
    }

    init {
        // Yalnızca kullanıcının yerel hafızasındaki (Music/Morphe) gerçek dosyaları yükle
        loadLibraryTracks()

        // Room / OfflineStorage oynatma listelerini canlı dinle
        viewModelScope.launch {
            playlistRepository.playlistsFlow.collect { playlists ->
                _uiState.update { it.copy(userPlaylists = playlists) }
            }
        }

        // Şarkı değiştikçe senkronize şarkı sözlerini arka planda çek
        viewModelScope.launch {
            player.playerState.collect { state ->
                val track = state.currentTrack
                if (track != null && track.videoId != lastLoadedLyricsTrackId) {
                    lastLoadedLyricsTrackId = track.videoId
                    loadLyricsForTrack(track)
                }
            }
        }
    }

    fun setTheme(theme: AppTheme) {
        _uiState.update { it.copy(currentTheme = theme) }
        viewModelScope.launch(Dispatchers.IO) {
            themeHelper.saveSelectedTheme(theme)
        }
        showSnackbar("Tema değiştirildi: ${theme.title}")
    }

    fun selectTab(tab: YtMusicTab) {
        _uiState.update { it.copy(selectedTab = tab, activePlaylistDetailId = null) }
    }

    fun selectPlaylist(playlist: UserPlaylist?) {
        _uiState.update { it.copy(selectedPlaylist = playlist) }
    }

    fun openPlaylistDetail(playlistId: String?) {
        _uiState.update { it.copy(activePlaylistDetailId = playlistId) }
    }

    fun createNewPlaylist(
        title: String,
        description: String,
        isAutoCollage: Boolean,
        selectedGalleryUri: Uri?,
        selectedTracks: List<MediaTrackInfo>
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val savedCoverPath = if (!isAutoCollage && selectedGalleryUri != null) {
                playlistRepository.saveCustomSquareCoverFromUri(selectedGalleryUri)
            } else {
                null
            }
            val newPlaylist = UserPlaylist(
                title = title,
                description = description,
                coverImagePath = savedCoverPath,
                isAutoCollage = isAutoCollage || savedCoverPath == null,
                tracks = selectedTracks
            )
            playlistRepository.saveOrUpdatePlaylist(newPlaylist)
            showSnackbar("\"${newPlaylist.title}\" oynatma listesi oluşturuldu ve kaydedildi.")
        }
    }

    fun deleteUserPlaylist(playlistId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            playlistRepository.deletePlaylist(playlistId)
            _uiState.update {
                if (it.activePlaylistDetailId == playlistId) {
                    it.copy(activePlaylistDetailId = null)
                } else {
                    it
                }
            }
            showSnackbar("Oynatma listesi silindi.")
        }
    }

    fun setNowPlayingExpanded(expanded: Boolean) {
        _uiState.update { it.copy(isNowPlayingExpanded = expanded) }
    }

    fun setAutoDownloadLiked(enabled: Boolean) {
        _uiState.update { it.copy(isAutoDownloadLiked = enabled) }
        showSnackbar(if (enabled) "Beğenilenleri otomatik indirme etkinleştirildi." else "Otomatik indirme kapatıldı.")
    }

    fun setWifiOnlyDownload(enabled: Boolean) {
        _uiState.update { it.copy(isWifiOnlyDownload = enabled) }
        showSnackbar(if (enabled) "İndirmeler yalnızca Wi-Fi üzerindeyken yapılacak." else "Hücresel veri indirmelerine izin verildi.")
    }

    /**
     * Music/Morphe dizinindeki fiziksel dosyaları MediaMetadataRetriever ile tarar
     * ve arayüzü günceller. Sahte/mock veri eklenmez.
     */
    fun loadLibraryTracks() {
        viewModelScope.launch {
            val tracks = withContext(Dispatchers.IO) {
                metadataManager.loadAllSavedTracks()
            }
            _uiState.update {
                it.copy(
                    savedTracks = tracks,
                    quickPicks = tracks.map { res -> res.trackInfo }
                )
            }
        }
    }

    private fun loadLyricsForTrack(track: MediaTrackInfo) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLyricsLoading = true) }
            val lyrics = LyricsProvider.getSyncedLyrics(track.title, track.artist, track.durationSeconds, track.videoId)
            _uiState.update { it.copy(currentLyrics = lyrics, isLyricsLoading = false) }
        }
    }

    fun loadLyricsForVideoId(videoId: String, trackTitle: String, artistName: String, durationSeconds: Long) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLyricsLoading = true) }
            val lyrics = LyricsProvider.getSyncedLyrics(trackTitle, artistName, durationSeconds, videoId)
            _uiState.update { it.copy(currentLyrics = lyrics, isLyricsLoading = false) }
        }
    }

    // =============================
    // OYNATICI VE BEĞENME (AUTO-DOWNLOAD)
    // =============================

    fun playTrack(track: MediaTrackInfo, playlist: List<MediaTrackInfo>? = null) {
        val list = playlist ?: _uiState.value.savedTracks.map { it.trackInfo }.ifEmpty { listOf(track) }
        player.playTrack(track, list)
    }

    fun togglePlayPause() = player.togglePlayPause()

    fun seekTo(positionMs: Long) = player.seekTo(positionMs)

    fun playNext() = player.playNext()

    fun playPrevious() = player.playPrevious()

    fun addToQueueNext(track: MediaTrackInfo) {
        player.addToQueueNext(track)
        showSnackbar("\"${track.title}\" sıradaki olarak eklendi.")
    }

    fun toggleShuffle() = player.toggleShuffle()

    fun toggleRepeat() = player.toggleRepeat()

    /**
     * Beğen (Like) butonuna tıklandığında favoriye ekler.
     * Eğer 'Otomatik İndir' aktif ve şarkı henüz yerel hafızada yoksa,
     * 4 parçalı indirme motorunu otomatik tetikler!
     */
    fun toggleLike() {
        val currentTrack = player.playerState.value.currentTrack ?: return
        player.toggleLike()

        val videoId = currentTrack.videoId
        val isNowLiked = player.playerState.value.isLiked

        _uiState.update { state ->
            val updatedLikes = if (isNowLiked) state.likedVideoIds + videoId else state.likedVideoIds - videoId
            state.copy(likedVideoIds = updatedLikes)
        }

        if (isNowLiked) {
            val isAlreadyDownloaded = _uiState.value.savedTracks.any { it.trackInfo.videoId == videoId }
            if (!isAlreadyDownloaded && _uiState.value.isAutoDownloadLiked) {
                if (_uiState.value.isWifiOnlyDownload && !isWifiConnected()) {
                    showSnackbar("\"${currentTrack.title}\" beğenildi. Yalnızca Wi-Fi ayarı aktif olduğu için indirme bekletiliyor.")
                } else {
                    showSnackbar("\"${currentTrack.title}\" beğenildi, arka planda 4 parça ile otomatik indiriliyor...")
                    triggerChunkedDownload(
                        trackInfo = currentTrack,
                        chunkCount = 4
                    )
                }
            } else {
                showSnackbar("\"${currentTrack.title}\" beğenilenlere eklendi.")
            }
        }
    }

    private fun isWifiConnected(): Boolean {
        val context = getApplication<Application>()
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    fun setVolume(volume: Float) = player.setVolume(volume)

    fun setBrightness(brightness: Float) = player.setBrightness(brightness)

    // =============================
    // ARAMA VE BAĞLANTI ÇÖZÜMLEME
    // =============================

    fun clearStreamError() {
        _uiState.update { it.copy(streamErrorDetail = null) }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query, streamErrorDetail = null) }
        urlResolutionJob?.cancel()

        if (query.isBlank()) {
            _uiState.update {
                it.copy(
                    resolvedUrlTrack = null,
                    resolvedPlaylistId = null,
                    resolvedPlaylistTitle = null,
                    isResolving = false
                )
            }
            return
        }

        // 1. Oynatma listesi bağlantısı kontrolü (playlist?list=... veya LM / VLLM)
        if (YouTubeStreamResolver.isPlaylistUrl(query)) {
            val playlistId = YouTubeStreamResolver.extractPlaylistId(query)
            if (playlistId != null) {
                resolvePlaylistById(playlistId)
                return
            }
        }

        // 2. Tekil video bağlantısı kontrolü (watch?v= veya youtu.be/)
        val detectedVideoId = YouTubeStreamResolver.extractVideoId(query)
        if (detectedVideoId != null) {
            urlResolutionJob = viewModelScope.launch {
                _uiState.update {
                    it.copy(
                        isResolving = true,
                        resolvedPlaylistId = null,
                        resolvedPlaylistTitle = null
                    )
                }
                val resolved = YouTubeStreamResolver.fetchMetadataFromOEmbed(detectedVideoId)
                _uiState.update {
                    it.copy(
                        resolvedUrlTrack = resolved,
                        isResolving = false
                    )
                }
            }
        } else {
            _uiState.update {
                it.copy(
                    resolvedUrlTrack = null,
                    resolvedPlaylistId = null,
                    resolvedPlaylistTitle = null,
                    isResolving = false
                )
            }
        }
    }

    private fun resolvePlaylistById(playlistId: String) {
        urlResolutionJob?.cancel()
        urlResolutionJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isResolving = true,
                    isSearching = true,
                    resolvedUrlTrack = null,
                    resolvedPlaylistId = playlistId,
                    resolvedPlaylistTitle = if (playlistId.equals("LM", ignoreCase = true) || playlistId.equals("VLLM", ignoreCase = true)) {
                        "Beğenilen Şarkılar (LM)"
                    } else {
                        "Oynatma Listesi ($playlistId)"
                    },
                    streamErrorDetail = null
                )
            }

            val cookies = storageHelper.getYouTubeMusicCookies()
            val result = YouTubeStreamResolver.resolvePlaylistTracks(
                playlistId = playlistId,
                cookies = cookies,
                onPartialTracksLoaded = { partialTracks ->
                    _uiState.update { state ->
                        state.copy(searchResults = partialTracks)
                    }
                }
            )

            _uiState.update {
                it.copy(
                    resolvedPlaylistId = result.playlistId,
                    resolvedPlaylistTitle = result.playlistTitle,
                    searchResults = result.tracks,
                    streamErrorDetail = result.errorDetail,
                    isResolving = false,
                    isSearching = false
                )
            }

            if (result.errorDetail != null) {
                showSnackbar(result.errorDetail)
            } else {
                // Çözümlenen oynatma listesini OfflineStorage / Room veritabanına da kaydet
                if (result.tracks.isNotEmpty()) {
                    val syncedPlaylist = UserPlaylist(
                        id = "yt_${result.playlistId}",
                        title = result.playlistTitle,
                        description = "YouTube Music InnerTube (${result.playlistId})",
                        isAutoCollage = true,
                        tracks = result.tracks
                    )
                    playlistRepository.saveOrUpdatePlaylist(syncedPlaylist)
                }
                showSnackbar("${result.playlistTitle}: ${result.tracks.size} şarkı çözümlendi ve Kitaplığa eklendi.")
            }
        }
    }

    fun executeSearch(query: String = _uiState.value.searchQuery) {
        if (query.isBlank()) return

        // 1. Eğer oynatma listesi (playlist?list=...) bağlantısıysa arama sorgusu olarak işletme; listeyi çözümle
        if (YouTubeStreamResolver.isPlaylistUrl(query)) {
            val playlistId = YouTubeStreamResolver.extractPlaylistId(query)
            if (playlistId != null) {
                resolvePlaylistById(playlistId)
                return
            }
        }

        // 2. Eğer tekil video bağlantısıysa (watch?v= veya youtu.be/) doğrudan video kartını çıkar
        val detectedVideoId = YouTubeStreamResolver.extractVideoId(query)
        if (detectedVideoId != null) {
            urlResolutionJob?.cancel()
            urlResolutionJob = viewModelScope.launch {
                _uiState.update {
                    it.copy(
                        isResolving = true,
                        resolvedPlaylistId = null,
                        resolvedPlaylistTitle = null
                    )
                }
                val resolved = YouTubeStreamResolver.fetchMetadataFromOEmbed(detectedVideoId)
                _uiState.update {
                    it.copy(
                        resolvedUrlTrack = resolved,
                        searchResults = if (resolved != null) listOf(resolved) else emptyList(),
                        isResolving = false
                    )
                }
            }
            return
        }

        // 3. Standart metin araması
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSearching = true,
                    resolvedUrlTrack = null,
                    resolvedPlaylistId = null,
                    resolvedPlaylistTitle = null,
                    streamErrorDetail = null
                )
            }
            val cookies = storageHelper.getYouTubeMusicCookies()
            val results = YouTubeStreamResolver.searchYouTube(query, cookies)
            _uiState.update {
                it.copy(
                    searchResults = results,
                    isSearching = false
                )
            }
        }
    }

    fun onFilterSelected(filter: String) {
        _uiState.update { it.copy(selectedFilter = filter) }
    }

    // =============================
    // PARÇALI İNDİRİCİ & ARKA PLAN KUYRUĞU (HTTP RANGE)
    // =============================

    /**
     * Çalma listesindeki henüz indirilmemiş (bekleyen) tüm parçaları kuyruğa ekler ve
     * 4 parçalı HTTP Range motoruyla arka planda sırayla indirir.
     */
    fun downloadMissingPlaylistTracks(missingTracks: List<MediaTrackInfo>) {
        if (missingTracks.isEmpty()) {
            showSnackbar("Listedeki tüm parçalar zaten indirilmiş.")
            return
        }

        val downloadedIds = _uiState.value.savedTracks.map { it.trackInfo.videoId }.toSet()
        var addedCount = 0
        synchronized(downloadQueue) {
            for (track in missingTracks) {
                val alreadyQueued = downloadQueue.any { it.videoId == track.videoId }
                if (!downloadedIds.contains(track.videoId) && !alreadyQueued) {
                    downloadQueue.addLast(track)
                    addedCount++
                }
            }
            _uiState.update { it.copy(pendingQueueCount = downloadQueue.size) }
        }

        if (!_uiState.value.isDownloading) {
            processNextInDownloadQueue()
        } else {
            showSnackbar("$addedCount eksik parça arka plan indirme kuyruğuna eklendi.")
        }
    }

    private fun processNextInDownloadQueue() {
        val nextTrack: MediaTrackInfo? = synchronized(downloadQueue) {
            val next = if (downloadQueue.isNotEmpty()) downloadQueue.removeFirst() else null
            _uiState.update { it.copy(pendingQueueCount = downloadQueue.size) }
            next
        }
        if (nextTrack != null) {
            triggerChunkedDownload(trackInfo = nextTrack, chunkCount = 4)
        }
    }

    fun triggerChunkedDownload(
        trackInfo: MediaTrackInfo,
        customUrl: String? = null,
        chunkCount: Int = 4
    ) {
        viewModelScope.launch {
            val cookies = storageHelper.getYouTubeMusicCookies()

            _uiState.update {
                it.copy(
                    isDownloading = true,
                    activeDownloadTitle = trackInfo.title,
                    downloadStatusText = "Akış bağlantısı çözümleniyor...",
                    streamErrorDetail = null
                )
            }

            // 1. Akış URL'sini ve olası hata kodunu çöz
            var downloadUrl = customUrl
            var errorDetail: String? = null
            if (downloadUrl.isNullOrBlank()) {
                // First try the existing resolver
                var resolution = YouTubeStreamResolver.resolveAudioStreamWithDiagnostics(trackInfo.videoId, cookies)
                if (resolution.streamUrl.isNullOrBlank()) {
                    // If that fails, try yt-dlp resolver
                    resolution = YTDlpResolver.resolveAudioStreamWithYTDlp(trackInfo.videoId)
                }
                downloadUrl = resolution.streamUrl
                errorDetail = resolution.errorDetail
            }

            // Eğer akış çözülemediyse çökmek veya sahte dosya indirmek yerine hata kodunu arayüze bas
            if (downloadUrl.isNullOrBlank()) {
                val readableError = errorDetail
                    ?: "[ERR_STREAM_RESOLVE] Ses akışı çözülemedi. Lütfen Ayarlar > YouTube Music Oturumu sekmesinden çerezlerinizi kaydediniz."
                _uiState.update {
                    it.copy(
                        isDownloading = false,
                        activeDownloadTitle = null,
                        downloadStatusText = readableError,
                        streamErrorDetail = readableError
                    )
                }
                notificationHelper.showDownloadError(trackInfo.title, readableError)
                showSnackbar(readableError)
                processNextInDownloadQueue()
                return@launch
            }

            val targetDir = metadataManager.getTargetMusicDirectory()
            val cleanId = trackInfo.videoId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val targetFile = File(targetDir, "$cleanId.m4a")

            notificationHelper.showDownloadStarted(trackInfo.title, chunkCount)

            activeDownloader = MultiThreadChunkedDownloader(
                fileUrl = downloadUrl,
                destinationFile = targetFile,
                chunkCount = chunkCount,
                cookieHeader = cookies,
                listener = object : DownloadListener {
                    override fun onStarted(totalBytes: Long, chunkCount: Int) {
                        _uiState.update {
                            it.copy(
                                isDownloading = true,
                                activeDownloadTitle = trackInfo.title,
                                downloadStatusText = "İndiriliyor: $chunkCount parça (${totalBytes / 1024} KB)"
                            )
                        }
                    }

                    override fun onProgress(progress: DownloadProgress) {
                        _uiState.update {
                            it.copy(
                                downloadProgress = progress,
                                downloadStatusText = "%${progress.progressPercent.toInt()} • ${progress.speedBytesPerSec / 1024} KB/s"
                            )
                        }
                        notificationHelper.updateProgress(trackInfo.title, progress)
                    }

                    override fun onPaused(downloadedBytes: Long, totalBytes: Long) {
                        _uiState.update { it.copy(downloadStatusText = "Duraklatıldı") }
                    }

                    override fun onCompleted(destinationFile: File) {
                        metadataManager.processAndSaveMediaAsync(
                            tempAudioFile = destinationFile,
                            trackInfo = trackInfo,
                            callback = object : MediaSaveCallback {
                                override fun onSuccess(result: SavedMediaResult) {
                                    notificationHelper.showDownloadCompleted(trackInfo.title)
                                    _uiState.update {
                                        val updated = listOf(result) + it.savedTracks.filter { s -> s.trackInfo.videoId != result.trackInfo.videoId }
                                        it.copy(
                                            isDownloading = false,
                                            activeDownloadTitle = null,
                                            downloadProgress = null,
                                            downloadStatusText = null,
                                            savedTracks = updated
                                        )
                                    }
                                    showSnackbar("\"${trackInfo.title}\" başarıyla indirildi ve Kitaplığa eklendi!")
                                    processNextInDownloadQueue()
                                }

                                override fun onError(exception: Exception) {
                                    notificationHelper.showDownloadError(trackInfo.title, exception.message ?: "")
                                    _uiState.update { it.copy(isDownloading = false) }
                                    showSnackbar("Kayıt hatası: ${exception.message}")
                                    processNextInDownloadQueue()
                                }
                            }
                        )
                    }

                    override fun onError(exception: Exception) {
                        notificationHelper.showDownloadError(trackInfo.title, exception.message ?: "Bağlantı kesildi")
                        _uiState.update {
                            it.copy(isDownloading = false, downloadStatusText = "Hata: ${exception.message}")
                        }
                        showSnackbar("İndirme hatası: ${exception.message}")
                        processNextInDownloadQueue()
                    }

                    override fun onCancelled() {
                        notificationHelper.cancelNotification()
                        _uiState.update {
                            it.copy(isDownloading = false, downloadProgress = null)
                        }
                    }
                }
            )

            activeDownloader?.start()
        }
    }

    fun pauseChunkedDownload() = activeDownloader?.pause()

    fun resumeChunkedDownload() = activeDownloader?.start()

    fun cancelChunkedDownload() {
        synchronized(downloadQueue) {
            downloadQueue.clear()
        }
        activeDownloader?.cancel(deleteFile = true)
        activeDownloader = null
        notificationHelper.cancelNotification()
        _uiState.update {
            it.copy(
                isDownloading = false,
                downloadProgress = null,
                activeDownloadTitle = null,
                downloadStatusText = null,
                pendingQueueCount = 0
            )
        }
    }

    fun deleteTrack(track: MediaTrackInfo) {
        viewModelScope.launch {
            val targetDir = metadataManager.getTargetMusicDirectory()
            File(targetDir, "${track.videoId}.m4a").delete()
            File(targetDir, "${track.videoId}.mp3").delete()
            File(targetDir, "${track.videoId}.json").delete()
            File(targetDir, "${track.videoId}.jpg").delete()
            val updated = _uiState.value.savedTracks.filter { it.trackInfo.videoId != track.videoId }
            _uiState.update { it.copy(savedTracks = updated) }
            showSnackbar("\"${track.title}\" kitaplıktan ve hafızadan silindi.")
        }
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
