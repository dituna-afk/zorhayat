package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.CookieStorageHelper
import com.example.ui.theme.LocalAppTheme
import com.example.ui.theme.TerminalGreen

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CookieInspectorScreen(
    onDismiss: () -> Unit,
    onCookiesCaptured: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val theme = LocalAppTheme.current
    val storageHelper = remember { CookieStorageHelper.getInstance(context) }

    var currentUrl by remember { mutableStateOf("https://music.youtube.com") }
    var webTitle by remember { mutableStateOf("YouTube Music") }
    var progress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(true) }

    var hasSapisid by remember { mutableStateOf(false) }
    var has3psid by remember { mutableStateOf(false) }
    var hasLoginInfo by remember { mutableStateOf(false) }
    var capturedCookieCount by remember { mutableStateOf(0) }

    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(this, true)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                userAgentString =
                    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            }
        }
    }

    // Geri tuşu desteği: WebView içinde gezinebilme
    BackHandler(enabled = webView.canGoBack()) {
        webView.goBack()
    }

    // Sadece arayüzdeki rozetleri güncellemek için durum okuması (Asla sayfayı otomatik kapatmaz)
    fun inspectCookieStatus(url: String) {
        val cookieManager = CookieManager.getInstance()
        val cookieStr = storageHelper.mergeCookieStrings(
            cookieManager.getCookie("https://music.youtube.com"),
            cookieManager.getCookie("https://www.youtube.com"),
            cookieManager.getCookie(url)
        ) ?: ""

        hasSapisid = cookieStr.contains("SAPISID=", ignoreCase = true) || cookieStr.contains("__Secure-3PAPISID=", ignoreCase = true)
        has3psid = cookieStr.contains("__Secure-3PSID=", ignoreCase = true) || cookieStr.contains("__Secure-3PAPISID=", ignoreCase = true)
        hasLoginInfo = cookieStr.contains("LOGIN_INFO=", ignoreCase = true)

        val count = if (cookieStr.isNotBlank()) cookieStr.split(";").size else 0
        capturedCookieCount = count
    }

    // Sadece kullanıcı "Çerezleri Kaydet ve Tamamla" butonuna bizzat bastığında çalışır
    fun saveAndFinishManually() {
        val cookieManager = CookieManager.getInstance()
        cookieManager.flush()
        val cookieStr = storageHelper.mergeCookieStrings(
            cookieManager.getCookie("https://music.youtube.com"),
            cookieManager.getCookie("https://www.youtube.com"),
            cookieManager.getCookie(currentUrl)
        ) ?: ""

        val hasValidSession = cookieStr.contains("SAPISID=", ignoreCase = true)
                || cookieStr.contains("__Secure-3PAPISID=", ignoreCase = true)
                || cookieStr.contains("__Secure-3PSID=", ignoreCase = true)

        if (!hasValidSession || cookieStr.isBlank()) {
            Toast.makeText(
                context,
                "Oturum çerezi (SAPISID) henüz bulunamadı. Lütfen önce Google hesabınızla giriş yapınız.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        storageHelper.saveCookies("https://music.youtube.com", cookieStr)
        Toast.makeText(context, "Oturum Çerezleri Başarıyla Kaydedildi", Toast.LENGTH_SHORT).show()
        onCookiesCaptured(cookieStr)
        onDismiss()
    }

    DisposableEffect(webView) {
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                isLoading = true
                currentUrl = url ?: currentUrl
                inspectCookieStatus(currentUrl)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                isLoading = false
                currentUrl = url ?: currentUrl
                webTitle = view?.title ?: "YouTube Music"
                inspectCookieStatus(currentUrl)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                inspectCookieStatus(url ?: currentUrl)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                progress = newProgress / 100f
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                if (!title.isNullOrBlank()) webTitle = title
            }
        }

        webView.loadUrl(currentUrl)

        onDispose {
            webView.stopLoading()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(theme.background)
    ) {
        // 1. YouTube Music Estetiğinde Üst Çubuk
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "YouTube Music Oturumu",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = theme.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentUrl,
                        style = MaterialTheme.typography.bodySmall,
                        color = theme.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            },
            navigationIcon = {
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Geri",
                        tint = theme.textPrimary
                    )
                }
            },
            actions = {
                IconButton(onClick = { webView.reload() }) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Yenile",
                        tint = theme.textPrimary
                    )
                }
                Button(
                    onClick = { saveAndFinishManually() },
                    colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .testTag("save_cookies_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Çerezleri Kaydet ve Tamamla", fontSize = 12.sp, color = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = theme.surface
            )
        )

        // 2. İlerleme Çubuğu
        if (isLoading) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = theme.primary,
                trackColor = Color.Transparent
            )
        }

        // 3. Canlı Algılanan Çerez Durum Bandı (Status Chips)
        Surface(
            color = theme.surfaceElevated,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CookieBadge(label = "SAPISID", isActive = hasSapisid)
                    CookieBadge(label = "LOGIN_INFO", isActive = hasLoginInfo)
                    CookieBadge(label = "3PSID", isActive = has3psid)
                }

                Text(
                    text = if (capturedCookieCount > 0) "$capturedCookieCount Çerez Kayıtlı" else "Oturum Bekleniyor",
                    color = if (hasSapisid || hasLoginInfo) TerminalGreen else theme.textSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 4. Gerçek WebView Bileşeni
        Box(modifier = Modifier.fillMaxSize()) {
            AndroidView(
                factory = { webView },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun CookieBadge(label: String, isActive: Boolean) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isActive) TerminalGreen.copy(alpha = 0.2f) else Color(0xFF333333))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(if (isActive) TerminalGreen else Color.Gray)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = if (isActive) TerminalGreen else Color.LightGray,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
