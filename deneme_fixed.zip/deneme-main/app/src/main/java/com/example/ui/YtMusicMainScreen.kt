package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CookieStorageHelper
import com.example.downloader.MediaMetadataManager
import com.example.downloader.MediaTrackInfo
import com.example.ui.navigation.YtBottomNavigation
import com.example.ui.player.MiniPlayer
import com.example.ui.player.NowPlayingScreen
import com.example.ui.screens.CookieInspectorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PlaylistDetailScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.YtDarkBackground
import com.example.viewmodel.CookieViewModel
import com.example.viewmodel.MusicPlayerViewModel
import com.example.viewmodel.YtMusicTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YtMusicMainScreen(
    musicViewModel: MusicPlayerViewModel,
    cookieViewModel: CookieViewModel,
    modifier: Modifier = Modifier
) {
    val musicUiState by musicViewModel.uiState.collectAsStateWithLifecycle()
    val playerState by musicViewModel.playerState.collectAsStateWithLifecycle()
    val cookieUiState by cookieViewModel.uiState.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var showCookieInspectorScreen by remember { mutableStateOf(false) }

    LaunchedEffect(musicUiState.snackbarMessage) {
        musicUiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            musicViewModel.clearSnackbar()
        }
    }

    LaunchedEffect(playerState.isPlaying) {
        if (playerState.isPlaying) {
            try {
                com.example.player.OfflinePlaybackService.startService(context)
            } catch (e: Exception) {
                // Ignore background start exceptions
            }
        }
    }

    val metadataManager = remember { MediaMetadataManager(context) }
    val downloadDirPath = remember { metadataManager.getTargetMusicDirectory().absolutePath }
    val currentTheme = com.example.ui.theme.LocalAppTheme.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(currentTheme.background)
    ) {
        // 1. Ana Ekran İskeleti (Sekmeler + Mini Oynatıcı + Alt Bar)
        Scaffold(
            containerColor = currentTheme.background,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Mini Oynatıcı (Eğer yüklü parça varsa alt çubuğun hemen üzerinde durur)
                    if (playerState.currentTrack != null) {
                        MiniPlayer(
                            playerState = playerState,
                            onClick = { musicViewModel.setNowPlayingExpanded(true) },
                            onTogglePlayPause = { musicViewModel.togglePlayPause() },
                            onPlayNext = { musicViewModel.playNext() }
                        )
                    }

                    // 4 Sekmeli YouTube Music Alt Gezinme Çubuğu
                    YtBottomNavigation(
                        selectedTab = musicUiState.selectedTab,
                        onTabSelected = { musicViewModel.selectTab(it) }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (musicUiState.selectedTab) {
                    YtMusicTab.HOME -> {
                        HomeScreen(
                            savedTracks = musicUiState.savedTracks,
                            onTrackSelected = { musicViewModel.playTrack(it) },
                            onNavigateToSearch = { musicViewModel.selectTab(YtMusicTab.SEARCH) },
                            onOpenCookieInspector = { showCookieInspectorScreen = true }
                        )
                    }

                    YtMusicTab.SEARCH -> {
                        SearchScreen(
                            searchQuery = musicUiState.searchQuery,
                            searchResults = musicUiState.searchResults,
                            resolvedTrack = musicUiState.resolvedUrlTrack,
                            resolvedPlaylistId = musicUiState.resolvedPlaylistId,
                            resolvedPlaylistTitle = musicUiState.resolvedPlaylistTitle,
                            isSearching = musicUiState.isSearching,
                            isResolving = musicUiState.isResolving,
                            selectedFilter = musicUiState.selectedFilter,
                            streamErrorDetail = musicUiState.streamErrorDetail,
                            onSearchQueryChanged = { musicViewModel.onSearchQueryChanged(it) },
                            onExecuteSearch = { musicViewModel.executeSearch(it) },
                            onFilterSelected = { musicViewModel.onFilterSelected(it) },
                            onTrackSelected = { musicViewModel.playTrack(it) },
                            onAddToQueue = { musicViewModel.addToQueueNext(it) },
                            onDownloadTriggered = { track ->
                                musicViewModel.triggerChunkedDownload(
                                    trackInfo = track,
                                    chunkCount = 4
                                )
                                musicViewModel.selectTab(YtMusicTab.LIBRARY)
                            },
                            onDismissError = { musicViewModel.clearStreamError() }
                        )
                    }

                    YtMusicTab.LIBRARY -> {
                        val activePlaylist = musicUiState.userPlaylists.firstOrNull {
                            it.id == musicUiState.activePlaylistDetailId
                        }
                        if (activePlaylist != null) {
                            PlaylistDetailScreen(
                                playlist = activePlaylist,
                                savedTracks = musicUiState.savedTracks,
                                isDownloading = musicUiState.isDownloading,
                                activeDownloadTitle = musicUiState.activeDownloadTitle,
                                downloadProgress = musicUiState.downloadProgress,
                                pendingQueueCount = musicUiState.pendingQueueCount,
                                onBack = { musicViewModel.openPlaylistDetail(null) },
                                onPlayPlaylist = { tracks, shuffle ->
                                    if (tracks.isNotEmpty()) {
                                        val playOrder = if (shuffle) tracks.shuffled() else tracks
                                        musicViewModel.playTrack(playOrder.first(), playOrder)
                                    }
                                },
                                onPlayTrack = { track ->
                                    musicViewModel.playTrack(track, activePlaylist.tracks)
                                },
                                onDownloadSingleTrack = { track ->
                                    musicViewModel.triggerChunkedDownload(
                                        trackInfo = track,
                                        chunkCount = 4
                                    )
                                },
                                onDownloadAllMissing = { missingTracks ->
                                    musicViewModel.downloadMissingPlaylistTracks(missingTracks)
                                },
                                onDeletePlaylist = { playlistId ->
                                    musicViewModel.deleteUserPlaylist(playlistId)
                                }
                            )
                        } else {
                            LibraryScreen(
                                savedTracks = musicUiState.savedTracks,
                                userPlaylists = musicUiState.userPlaylists,
                                onlineCandidateTracks = musicUiState.searchResults,
                                isDownloading = musicUiState.isDownloading,
                                activeDownloadTitle = musicUiState.activeDownloadTitle,
                                downloadProgress = musicUiState.downloadProgress,
                                downloadStatusText = musicUiState.downloadStatusText,
                                pendingQueueCount = musicUiState.pendingQueueCount,
                                onTrackSelected = { musicViewModel.playTrack(it) },
                                onAddToQueueNext = { musicViewModel.addToQueueNext(it) },
                                onDeleteTrack = { musicViewModel.deleteTrack(it) },
                                onOpenPlaylistDetail = { playlistId ->
                                    musicViewModel.openPlaylistDetail(playlistId)
                                },
                                onCreatePlaylist = { title, desc, isAutoCollage, uri, tracks ->
                                    musicViewModel.createNewPlaylist(
                                        title = title,
                                        description = desc,
                                        isAutoCollage = isAutoCollage,
                                        selectedGalleryUri = uri,
                                        selectedTracks = tracks
                                    )
                                },
                                onStartTestDownload = {
                                    val testTrack = MediaTrackInfo(
                                        videoId = "dQw4w9WgXcQ",
                                        title = "Rick Astley - Never Gonna Give You Up",
                                        artist = "Rick Astley",
                                        durationSeconds = 213
                                    )
                                    musicViewModel.triggerChunkedDownload(
                                        trackInfo = testTrack,
                                        chunkCount = 4
                                    )
                                },
                                onPauseDownload = { musicViewModel.pauseChunkedDownload() },
                                onResumeDownload = { musicViewModel.resumeChunkedDownload() },
                                onCancelDownload = { musicViewModel.cancelChunkedDownload() }
                            )
                        }
                    }

                    YtMusicTab.SETTINGS -> {
                        SettingsScreen(
                            downloadDirectoryPath = downloadDirPath,
                            currentTheme = musicUiState.currentTheme,
                            onThemeSelected = { musicViewModel.setTheme(it) },
                            isAutoDownloadLiked = musicUiState.isAutoDownloadLiked,
                            isWifiOnlyDownload = musicUiState.isWifiOnlyDownload,
                            onToggleAutoDownloadLiked = { musicViewModel.setAutoDownloadLiked(it) },
                            onToggleWifiOnlyDownload = { musicViewModel.setWifiOnlyDownload(it) },
                            onOpenCookieInspector = { showCookieInspectorScreen = true },
                            onClearCache = {
                                cookieViewModel.clearAllCookies()
                                musicViewModel.showSnackbar("Önbellek ve kayıtlı çerezler temizlendi.")
                            }
                        )
                    }
                }
            }
        }

        // 2. Tam Ekran Oynatıcı: Yaylanan (Spring / Bounce) Paylaşımlı Kayma Animasyonu
        AnimatedVisibility(
            visible = musicUiState.isNowPlayingExpanded && playerState.currentTrack != null,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = androidx.compose.animation.core.spring(
                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioLowBouncy,
                    stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = androidx.compose.animation.core.spring(
                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioNoBouncy,
                    stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
                )
            ) + fadeOut()
        ) {
            NowPlayingScreen(
                playerState = playerState,
                lyrics = musicUiState.currentLyrics,
                isLyricsLoading = musicUiState.isLyricsLoading,
                onCollapse = { musicViewModel.setNowPlayingExpanded(false) },
                onTogglePlayPause = { musicViewModel.togglePlayPause() },
                onSeekTo = { musicViewModel.seekTo(it) },
                onPlayNext = { musicViewModel.playNext() },
                onPlayPrevious = { musicViewModel.playPrevious() },
                onToggleShuffle = { musicViewModel.toggleShuffle() },
                onToggleRepeat = { musicViewModel.toggleRepeat() },
                onToggleLike = { musicViewModel.toggleLike() },
                onVolumeChanged = { musicViewModel.setVolume(it) },
                onBrightnessChanged = { musicViewModel.setBrightness(it) },
                onPlayTrackFromQueue = { musicViewModel.playTrack(it) }
            )
        }

        // 3. Tam Ekran Gerçek YouTube Music WebView Çerez Yakalayıcı (Cookie Inspector Screen)
        AnimatedVisibility(
            visible = showCookieInspectorScreen,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = androidx.compose.animation.core.spring(
                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioNoBouncy,
                    stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = androidx.compose.animation.core.spring(
                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioNoBouncy,
                    stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
                )
            ) + fadeOut()
        ) {
            CookieInspectorScreen(
                onDismiss = { showCookieInspectorScreen = false },
                onCookiesCaptured = { capturedMergedCookies ->
                    CookieStorageHelper.getInstance(context).saveCookies("https://music.youtube.com", capturedMergedCookies)
                    musicViewModel.showSnackbar("Oturum Çerezleri Başarıyla Kaydedildi!")
                }
            )
        }
    }
}
