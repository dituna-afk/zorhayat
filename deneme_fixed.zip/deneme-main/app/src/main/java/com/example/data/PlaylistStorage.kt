package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.util.Log
import androidx.compose.runtime.Immutable
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.downloader.MediaTrackInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Kullanıcı tarafından oluşturulan oynatma listesi modeli.
 * Hem yerel olarak indirilmiş parçaları hem de henüz indirilmemiş (bekleyen) parçaları barındırabilir.
 */
@Immutable
data class UserPlaylist(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val coverImagePath: String? = null,
    val isAutoCollage: Boolean = true,
    val tracks: List<MediaTrackInfo> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val coverImagePath: String?,
    val isAutoCollage: Boolean,
    val tracksJson: String,
    val createdAt: Long
)

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylistsFlow(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    suspend fun getAllPlaylistsOnce(): List<PlaylistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlaylist(playlist: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylistById(playlistId: String)
}

@Database(entities = [PlaylistEntity::class], version = 1, exportSchema = false)
abstract class PlaylistDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao

    companion object {
        @Volatile
        private var INSTANCE: PlaylistDatabase? = null

        fun getInstance(context: Context): PlaylistDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PlaylistDatabase::class.java,
                    "morphe_playlists.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

/**
 * Oynatma listelerini hem Room veritabanında hem de OfflineStorage (Music/Morphe/playlists_offline.json)
 * içinde senkronize tutan Repository katmanı.
 */
class OfflinePlaylistRepository private constructor(private val context: Context) {

    private val playlistDao = PlaylistDatabase.getInstance(context).playlistDao()

    val playlistsFlow: Flow<List<UserPlaylist>> = playlistDao.getAllPlaylistsFlow().map { entities ->
        entities.map { it.toDomainModel() }
    }

    private fun getOfflineStorageDir(): File {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Morphe")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getCoversDir(): File {
        val dir = File(getOfflineStorageDir(), "covers")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Galeriden seçilen görseli 1:1 kare (Center-Crop) olarak kırpıp yerel hafızaya kaydeder.
     */
    suspend fun saveCustomSquareCoverFromUri(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
            val original = BitmapFactory.decodeStream(inputStream)
            inputStream.close()
            if (original == null) return@withContext null

            val size = minOf(original.width, original.height)
            val xOffset = (original.width - size) / 2
            val yOffset = (original.height - size) / 2
            val squareBitmap = Bitmap.createBitmap(original, xOffset, yOffset, size, size)
            val scaledBitmap = if (size > 600) {
                Bitmap.createScaledBitmap(squareBitmap, 600, 600, true)
            } else {
                squareBitmap
            }

            val outFile = File(getCoversDir(), "playlist_cover_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { out ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                out.flush()
            }
            outFile.absolutePath
        } catch (e: Exception) {
            Log.e("OfflinePlaylistRepo", "Kapak görseli kaydedilemedi: ${e.message}", e)
            null
        }
    }

    suspend fun saveOrUpdatePlaylist(playlist: UserPlaylist) = withContext(Dispatchers.IO) {
        val entity = playlist.toEntity()
        playlistDao.upsertPlaylist(entity)
        syncOfflineBackupJson()
    }

    suspend fun deletePlaylist(playlistId: String) = withContext(Dispatchers.IO) {
        playlistDao.deletePlaylistById(playlistId)
        syncOfflineBackupJson()
    }

    private suspend fun syncOfflineBackupJson() {
        try {
            val all = playlistDao.getAllPlaylistsOnce().map { it.toDomainModel() }
            val rootArray = JSONArray()
            for (pl in all) {
                val obj = JSONObject().apply {
                    put("id", pl.id)
                    put("title", pl.title)
                    put("description", pl.description)
                    put("coverImagePath", pl.coverImagePath ?: "")
                    put("isAutoCollage", pl.isAutoCollage)
                    put("createdAt", pl.createdAt)
                    put("tracks", JSONArray(serializeTracksToJson(pl.tracks)))
                }
                rootArray.put(obj)
            }
            val backupFile = File(getOfflineStorageDir(), "playlists_offline.json")
            backupFile.writeText(rootArray.toString(2), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.w("OfflinePlaylistRepo", "Offline JSON yedekleme hatası: ${e.message}")
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: OfflinePlaylistRepository? = null

        fun getInstance(context: Context): OfflinePlaylistRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: OfflinePlaylistRepository(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun serializeTracksToJson(tracks: List<MediaTrackInfo>): String {
            val arr = JSONArray()
            for (t in tracks) {
                val obj = JSONObject().apply {
                    put("videoId", t.videoId)
                    put("title", t.title)
                    put("artist", t.artist)
                    put("durationSeconds", t.durationSeconds)
                    put("thumbnailUrl", t.thumbnailUrl ?: "")
                    put("sourceUrl", t.sourceUrl ?: "")
                    put("savedAtTimestamp", t.savedAtTimestamp)
                }
                arr.put(obj)
            }
            return arr.toString()
        }

        fun deserializeTracksFromJson(jsonStr: String): List<MediaTrackInfo> {
            if (jsonStr.isBlank()) return emptyList()
            val list = mutableListOf<MediaTrackInfo>()
            return try {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val videoId = obj.optString("videoId", "")
                    if (videoId.isBlank()) continue
                    list.add(
                        MediaTrackInfo(
                            videoId = videoId,
                            title = obj.optString("title", "Bilinmeyen Şarkı"),
                            artist = obj.optString("artist", "Bilinmeyen Sanatçı"),
                            durationSeconds = obj.optLong("durationSeconds", 200L),
                            thumbnailUrl = obj.optString("thumbnailUrl", "").takeIf { it.isNotBlank() },
                            sourceUrl = obj.optString("sourceUrl", "").takeIf { it.isNotBlank() },
                            savedAtTimestamp = obj.optLong("savedAtTimestamp", System.currentTimeMillis())
                        )
                    )
                }
                list
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}

private fun PlaylistEntity.toDomainModel(): UserPlaylist {
    return UserPlaylist(
        id = id,
        title = title,
        description = description,
        coverImagePath = coverImagePath,
        isAutoCollage = isAutoCollage,
        tracks = OfflinePlaylistRepository.deserializeTracksFromJson(tracksJson),
        createdAt = createdAt
    )
}

private fun UserPlaylist.toEntity(): PlaylistEntity {
    return PlaylistEntity(
        id = id,
        title = title,
        description = description,
        coverImagePath = coverImagePath,
        isAutoCollage = isAutoCollage,
        tracksJson = OfflinePlaylistRepository.serializeTracksToJson(tracks),
        createdAt = createdAt
    )
}
