package com.example.downloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Parçalı indirme işlemi sırasında Android bildirim çubuğunda
 * canlı yüzde ve hız (KB/s) gösteren yardımcı sınıf.
 */
class DownloadNotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "morphe_download_channel"
        const val CHANNEL_NAME = "Morphe İndirme Bildirimleri"
        const val NOTIFICATION_ID = 2001
    }

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Morphe 4 parçalı HTTP Range indirme ilerleme bildirimleri"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun showDownloadStarted(trackTitle: String, chunkCount: Int) {
        if (!hasNotificationPermission()) return

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("İndiriliyor: $trackTitle")
            .setContentText("4 parçalı HTTP Range motoru başlatıldı ($chunkCount paralel kanal)")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setProgress(100, 0, true)

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    fun updateProgress(trackTitle: String, progress: DownloadProgress) {
        if (!hasNotificationPermission()) return

        val percent = progress.progressPercent.toInt()
        val speedKb = progress.speedBytesPerSec / 1024
        val downloadedMb = String.format(Locale.US, "%.1f", progress.downloadedBytes / (1024f * 1024f))
        val totalMb = String.format(Locale.US, "%.1f", progress.totalBytes / (1024f * 1024f))

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(trackTitle)
            .setContentText("%$percent • $speedKb KB/s ($downloadedMb MB / $totalMb MB)")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setProgress(100, percent.coerceIn(0, 100), false)

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    fun showDownloadCompleted(trackTitle: String) {
        if (!hasNotificationPermission()) return

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("İndirme Tamamlandı")
            .setContentText("\"$trackTitle\" Morphe müzik klasörüne kaydedildi.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setOngoing(false)
            .setAutoCancel(true)

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    fun showDownloadError(trackTitle: String, error: String) {
        if (!hasNotificationPermission()) return

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("İndirme Hatası")
            .setContentText("\"$trackTitle\": $error")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setOngoing(false)
            .setAutoCancel(true)

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    fun cancelNotification() {
        notificationManager.cancel(NOTIFICATION_ID)
    }
}
