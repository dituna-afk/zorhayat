package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AddCookieDialog
import com.example.ui.components.ClearCookiesDialog
import com.example.ui.components.CookieInspectorPanel
import com.example.ui.components.WebViewComponent
import com.example.viewmodel.CookieViewModel

private data class PresetSite(val title: String, val url: String)

private val PRESET_SITES = listOf(
    PresetSite("🍪 HttpBin Cookies", "https://httpbin.org/cookies"),
    PresetSite("🔑 GitHub Giriş", "https://github.com/login"),
    PresetSite("🌐 Google", "https://www.google.com"),
    PresetSite("📖 Wikipedia", "https://en.m.wikipedia.org"),
    PresetSite("⚙️ HttpBin Set Cookie", "https://httpbin.org/cookies/set?test_user=ali_veli&session=xyz890")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CookieAppScreen(
    viewModel: CookieViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val focusManager = LocalFocusManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Split oranı: 0.5f varsayılan (üst %50 webview, alt %50 çerez paneli)
    // 0.7f webview ağırlıklı, 0.3f panel ağırlıklı
    var webViewWeight by remember { mutableFloatStateOf(0.52f) }

    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusMessage()
        }
    }

    if (uiState.showClearDialog) {
        ClearCookiesDialog(
            onConfirm = { viewModel.clearAllCookies() },
            onDismiss = { viewModel.setShowClearDialog(false) }
        )
    }

    if (uiState.showAddCookieDialog) {
        AddCookieDialog(
            currentUrl = uiState.currentUrl,
            onAddCookie = { name, value -> viewModel.setTestCookie(name, value) },
            onDismiss = { viewModel.setShowAddCookieDialog(false) }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Üst Bar: Navigasyon ve URL Çubuğu
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { /* WebView Back handled inside WebViewComponent or trigger */ },
                            enabled = uiState.canGoBack,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Geri",
                                tint = if (uiState.canGoBack) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.fetchCookiesFromManager(uiState.currentUrl, "Yenile Butonu") },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Yenile",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // URL Giriş Alanı
                        OutlinedTextField(
                            value = uiState.inputUrl,
                            onValueChange = { viewModel.onUrlInputChanged(it) },
                            singleLine = true,
                            placeholder = { Text("https://example.com") },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    focusManager.clearFocus()
                                    viewModel.navigateToUrl(uiState.inputUrl)
                                }
                            ),
                            trailingIcon = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (uiState.inputUrl.isNotEmpty()) {
                                        IconButton(
                                            onClick = { viewModel.onUrlInputChanged("") },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Temizle",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = {
                                            focusManager.clearFocus()
                                            viewModel.navigateToUrl(uiState.inputUrl)
                                        },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .testTag("go_url_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Search,
                                            contentDescription = "Git",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .padding(horizontal = 4.dp)
                        )
                    }

                    // Yükleme İlerleme Çubuğu
                    if (uiState.isLoading) {
                        LinearProgressIndicator(
                            progress = { uiState.progress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    } else {
                        Spacer(modifier = Modifier.height(3.dp))
                    }

                    // Hızlı Hazır Siteler Çubuğu
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Hızlı Git:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        PRESET_SITES.forEach { site ->
                            AssistChip(
                                onClick = {
                                    focusManager.clearFocus()
                                    viewModel.navigateToUrl(site.url)
                                },
                                label = { Text(site.title, fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = if (uiState.currentUrl == site.url)
                                        MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surface
                                )
                            )
                        }
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 1. Üst Bölüm: WebView
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(webViewWeight)
            ) {
                WebViewComponent(
                    url = uiState.currentUrl,
                    onPageStarted = { url -> viewModel.onPageStarted(url) },
                    onPageFinished = { url, title -> viewModel.onPageFinished(url, title) },
                    onProgressChanged = { progress -> viewModel.onPageProgress(progress) },
                    onNavigationStateChanged = { canBack, canForward ->
                        viewModel.updateNavigationState(canBack, canForward)
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // 2. Orta Bölüm: Boyutlandırma ve Kontrol Çubuğu (Split Handle)
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🔎 Ekran Düzeni:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(
                            onClick = { webViewWeight = 0.70f },
                            label = { Text("Web Öncelikli", fontSize = 10.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowUp,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        )

                        AssistChip(
                            onClick = { webViewWeight = 0.50f },
                            label = { Text("Eşit (50/50)", fontSize = 10.sp) }
                        )

                        AssistChip(
                            onClick = { webViewWeight = 0.28f },
                            label = { Text("Çerez Öncelikli", fontSize = 10.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        )
                    }
                }
            }

            // 3. Alt Bölüm: CookieManager Çerez Paneli (TextView + Parsed Chips + Logcat)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f - webViewWeight)
            ) {
                CookieInspectorPanel(
                    rawCookies = uiState.rawCookies,
                    parsedCookies = uiState.parsedCookies,
                    searchQuery = uiState.searchQuery,
                    lastUpdated = uiState.lastUpdated,
                    currentUrl = uiState.currentUrl,
                    logHistory = uiState.logHistory,
                    isEncryptedStorage = uiState.isEncryptedStorage,
                    isRestoredFromStorage = uiState.isRestoredFromStorage,
                    storageTimestamp = uiState.storageTimestamp,
                    downloadUrl = uiState.downloadUrl,
                    downloadChunkCount = uiState.downloadChunkCount,
                    downloadProgress = uiState.downloadProgress,
                    downloadStatus = uiState.downloadStatus,
                    isDownloaderActive = uiState.isDownloaderActive,
                    isDownloaderPaused = uiState.isDownloaderPaused,
                    downloadedFilePath = uiState.downloadedFilePath,
                    onDownloadUrlChanged = { viewModel.onDownloadUrlChanged(it) },
                    onDownloadChunkCountChanged = { viewModel.onDownloadChunkCountChanged(it) },
                    onStartOrResumeDownload = { viewModel.startOrResumeDownload() },
                    onPauseDownload = { viewModel.pauseDownload() },
                    onCancelDownload = { viewModel.cancelDownload() },
                    onSearchQueryChanged = { viewModel.onSearchQueryChanged(it) },
                    onRefreshClicked = { viewModel.fetchCookiesFromManager(uiState.currentUrl, "Panel Yenile") },
                    onClearCookiesClicked = { viewModel.setShowClearDialog(true) },
                    onAddTestCookieClicked = { viewModel.setShowAddCookieDialog(true) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
