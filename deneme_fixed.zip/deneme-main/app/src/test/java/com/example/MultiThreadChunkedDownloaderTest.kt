package com.example

import com.example.downloader.ChunkState
import com.example.downloader.DownloadProgress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MultiThreadChunkedDownloaderTest {

    @Test
    fun `chunk calculation divides bytes correctly`() {
        val totalBytes = 1000L
        val chunkCount = 4
        val chunkSize = totalBytes / chunkCount

        val chunks = mutableListOf<ChunkState>()
        for (i in 0 until chunkCount) {
            val start = i * chunkSize
            val end = if (i == chunkCount - 1) totalBytes - 1 else (start + chunkSize - 1)
            chunks.add(ChunkState(i, start, end, start))
        }

        assertEquals(4, chunks.size)
        assertEquals(0L, chunks[0].startByte)
        assertEquals(249L, chunks[0].endByte)
        assertEquals(250L, chunks[0].totalChunkBytes)

        assertEquals(250L, chunks[1].startByte)
        assertEquals(499L, chunks[1].endByte)

        assertEquals(500L, chunks[2].startByte)
        assertEquals(749L, chunks[2].endByte)

        assertEquals(750L, chunks[3].startByte)
        assertEquals(999L, chunks[3].endByte)

        val sumBytes = chunks.sumOf { it.totalChunkBytes }
        assertEquals(1000L, sumBytes)
    }

    @Test
    fun `chunk progress calculation works`() {
        val chunk = ChunkState(0, 0, 99, 50)
        assertEquals(100L, chunk.totalChunkBytes)
        assertEquals(50L, chunk.downloadedInChunk)
        assertEquals(50f, chunk.progressPercent, 0.01f)
    }

    @Test
    fun `download progress percent calculation`() {
        val progress = DownloadProgress(
            downloadedBytes = 500,
            totalBytes = 1000,
            progressPercent = 50f,
            speedBytesPerSec = 1024,
            activeChunks = 4
        )

        assertEquals(50f, progress.progressPercent, 0.01f)
        assertEquals(1024L, progress.speedBytesPerSec)
        assertEquals(4, progress.activeChunks)
    }
}
