package com.example

import com.example.downloader.YouTubeStreamResolver
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeStreamResolverTest {

    @Test
    fun `extractVideoId correctly extracts from various YouTube URLs`() {
        assertEquals("dQw4w9WgXcQ", YouTubeStreamResolver.extractVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeStreamResolver.extractVideoId("https://music.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeStreamResolver.extractVideoId("https://youtu.be/dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeStreamResolver.extractVideoId("dQw4w9WgXcQ"))
    }

    @Test
    fun `generateSapisidHash produces valid SHA-1 hash header`() {
        val cookies = "PREF=f4=4000000; SAPISID=test_sapisid_secret_123; __Secure-3PSID=psid_val"
        val hash = YouTubeStreamResolver.generateSapisidHash(cookies)

        assertNotNull(hash)
        assertTrue(hash!!.startsWith("SAPISIDHASH "))
        val parts = hash.removePrefix("SAPISIDHASH ").split("_")
        assertEquals(2, parts.size)
        assertTrue(parts[0].toLong() > 0L)
        assertEquals(40, parts[1].length) // SHA-1 hex length is 40 characters
    }

    @Test
    fun `generateSapisidHash with Secure-3PAPISID fallback`() {
        val cookies = "PREF=f4=4000000; __Secure-3PAPISID=another_secret_321; LOGIN_INFO=abc"
        val hash = YouTubeStreamResolver.generateSapisidHash(cookies)

        assertNotNull(hash)
        assertTrue(hash!!.startsWith("SAPISIDHASH "))
    }

    @Test
    fun `generateSapisidHash returns null if no SAPISID present`() {
        val cookies = "VISITOR_INFO1_LIVE=abc; YSC=123"
        val hash = YouTubeStreamResolver.generateSapisidHash(cookies)
        assertNull(hash)

        val nullHash = YouTubeStreamResolver.generateSapisidHash(null)
        assertNull(nullHash)
    }

    @Test
    fun `extractPlaylistId and isPlaylistUrl correctly parse playlist links including LM`() {
        assertTrue(YouTubeStreamResolver.isPlaylistUrl("https://music.youtube.com/playlist?list=LM"))
        assertEquals("LM", YouTubeStreamResolver.extractPlaylistId("https://music.youtube.com/playlist?list=LM"))
        assertEquals("VLLM", YouTubeStreamResolver.extractPlaylistId("https://music.youtube.com/playlist?list=VLLM"))
        assertEquals(
            "PL4fGSI1pDJn6puJdseH2Rt9sMvt9E2M4i",
            YouTubeStreamResolver.extractPlaylistId("https://www.youtube.com/playlist?list=PL4fGSI1pDJn6puJdseH2Rt9sMvt9E2M4i&si=abc")
        )
        // Pure playlist URL should not be extracted as a single video ID
        assertNull(YouTubeStreamResolver.extractVideoId("https://music.youtube.com/playlist?list=LM"))
    }
}
