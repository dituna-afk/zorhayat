package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.downloader.MediaMetadataManager
import com.example.downloader.MediaTrackInfo
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MediaMetadataManagerTest {

    private lateinit var context: Context
    private lateinit var metadataManager: MediaMetadataManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        metadataManager = MediaMetadataManager(context)
        val targetDir = metadataManager.getTargetMusicDirectory()
        targetDir.deleteRecursively()
    }

    @Test
    fun `processAndSaveMedia moves audio file and creates json metadata`() = runBlocking {
        val tempAudio = File(context.cacheDir, "test_temp_audio.bin")
        tempAudio.writeText("M4A_AUDIO_MOCK_DATA")

        val trackInfo = MediaTrackInfo(
            videoId = "dQw4w9WgXcQ",
            title = "Never Gonna Give You Up",
            artist = "Rick Astley",
            durationSeconds = 213,
            thumbnailUrl = null
        )

        val result = metadataManager.processAndSaveMedia(
            tempAudioFile = tempAudio,
            trackInfo = trackInfo
        )

        assertNotNull(result)
        assertTrue(result.audioFile.exists())
        assertEquals("dQw4w9WgXcQ.m4a", result.audioFile.name)

        assertTrue(result.metadataJsonFile.exists())
        assertEquals("dQw4w9WgXcQ.json", result.metadataJsonFile.name)

        // JSON içeriğini doğrula
        val jsonContent = JSONObject(result.metadataJsonFile.readText())
        assertEquals("dQw4w9WgXcQ", jsonContent.getString("videoId"))
        assertEquals("Never Gonna Give You Up", jsonContent.getString("title"))
        assertEquals("Rick Astley", jsonContent.getString("artist"))
        assertEquals(213L, jsonContent.getLong("durationSeconds"))

        // loadAllSavedTracks doğrula
        val allTracks = metadataManager.loadAllSavedTracks()
        assertEquals(1, allTracks.size)
        assertEquals("Rick Astley", allTracks[0].trackInfo.artist)
    }
}
