package com.example

import com.example.model.LrcParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcParserTest {

    @Test
    fun `parse empty or null returns empty list`() {
        assertTrue(LrcParser.parse(null).isEmpty())
        assertTrue(LrcParser.parse("").isEmpty())
        assertTrue(LrcParser.parse("   ").isEmpty())
    }

    @Test
    fun `parse standard LRC content parses lines and timestamps correctly`() {
        val lrc = """
            [00:05.50] First line of song
            [00:12.00] Second line of song
            [01:03.250] Chorus begins here
        """.trimIndent()

        val parsed = LrcParser.parse(lrc)
        assertEquals(3, parsed.size)

        assertEquals(5500L, parsed[0].timeMs)
        assertEquals("First line of song", parsed[0].text)

        assertEquals(12000L, parsed[1].timeMs)
        assertEquals("Second line of song", parsed[1].text)

        assertEquals(63250L, parsed[2].timeMs)
        assertEquals("Chorus begins here", parsed[2].text)
    }

    @Test
    fun `getActiveIndex finds current line correctly`() {
        val lrc = """
            [00:10.00] Line 1
            [00:20.00] Line 2
            [00:30.00] Line 3
        """.trimIndent()

        val parsed = LrcParser.parse(lrc)

        // 5 saniyede henüz ilk satır başlamamış
        assertEquals(-1, LrcParser.getActiveIndex(parsed, 5000L))

        // 12 saniyede 1. satır aktif
        assertEquals(0, LrcParser.getActiveIndex(parsed, 12000L))

        // 25 saniyede 2. satır aktif
        assertEquals(1, LrcParser.getActiveIndex(parsed, 25000L))

        // 40 saniyede 3. satır aktif
        assertEquals(2, LrcParser.getActiveIndex(parsed, 40000L))
    }
}
