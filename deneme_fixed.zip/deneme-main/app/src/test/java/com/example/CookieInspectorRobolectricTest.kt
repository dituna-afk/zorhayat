package com.example

import com.example.model.CookieParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CookieInspectorRobolectricTest {

    @Test
    fun `parseCookieString with empty returns empty list`() {
        val cookies = CookieParser.parse(null)
        assertTrue(cookies.isEmpty())

        val cookiesEmpty = CookieParser.parse("")
        assertTrue(cookiesEmpty.isEmpty())
    }

    @Test
    fun `parseCookieString with multiple cookies parses correctly`() {
        val raw = "session_id=abc12345; user_token=token999; theme=dark"
        val cookies = CookieParser.parse(raw)

        assertEquals(3, cookies.size)
        assertEquals("session_id", cookies[0].name)
        assertEquals("abc12345", cookies[0].value)

        assertEquals("user_token", cookies[1].name)
        assertEquals("token999", cookies[1].value)

        assertEquals("theme", cookies[2].name)
        assertEquals("dark", cookies[2].value)
    }

    @Test
    fun `parseCookieString with complex values preserves value`() {
        val raw = "data=a=b=c; flags=1"
        val cookies = CookieParser.parse(raw)

        assertEquals(2, cookies.size)
        assertEquals("data", cookies[0].name)
        assertEquals("a=b=c", cookies[0].value)
        assertEquals("flags", cookies[1].name)
        assertEquals("1", cookies[1].value)
    }
}
