package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CookieStorageHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CookieStorageHelperTest {

    private lateinit var storageHelper: CookieStorageHelper

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        storageHelper = CookieStorageHelper(context)
        storageHelper.clearAll()
    }

    @Test
    fun `save and retrieve cookies for url`() {
        val testUrl = "https://github.com/login"
        val cookieString = "user_session=abc123xyz; logged_in=yes; tz=Europe/Istanbul"

        storageHelper.saveCookies(testUrl, cookieString)

        val retrieved = storageHelper.getCookies(testUrl)
        assertEquals(cookieString, retrieved)

        val latest = storageHelper.getLatestCookies()
        assertEquals(cookieString, latest)

        val latestUrl = storageHelper.getLatestUrl()
        assertEquals(testUrl, latestUrl)
    }

    @Test
    fun `clearAll removes all saved cookies`() {
        storageHelper.saveCookies("https://site1.com", "cookie1=val1")
        storageHelper.saveCookies("https://site2.com", "cookie2=val2")

        assertNotNull(storageHelper.getCookies("https://site1.com"))

        storageHelper.clearAll()

        assertNull(storageHelper.getCookies("https://site1.com"))
        assertNull(storageHelper.getCookies("https://site2.com"))
        assertNull(storageHelper.getLatestCookies())
    }
}
